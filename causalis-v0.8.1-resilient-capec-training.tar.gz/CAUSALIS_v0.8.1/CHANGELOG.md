# Changelog

## v0.8.1

- Added persistent and recoverable CAPEC multiclass training.
- Added per-model checkpoints and skip-on-resume behavior.
- Added deterministic cleanup and garbage collection after every model.
- Added optional CPU, RAM and swap checkpoint telemetry through psutil.
- Updated CAPEC GUI execution to use the persistent Task Manager.

## 0.7.0 — 2026-07-25

### Fixed
- REST API dataset split naming and class separation.
- Service names containing underscores in split export.
- UTC handling for offset-less HTTP ISO timestamps.
- PostgreSQL evidence alias detection for `database` filenames.

### Added
- Automatic binary dataset discovery from one folder.
- Automatic CAPEC anomaly discovery from one folder.
- Dataset completeness validation before training.
- Sequential multi-service binary execution from discovered splits.

### Preserved
- v0.6.0 campaign, processing, correlation, ML, reporting and manual-input workflows.

## 0.8.0 - 2026-07-27
- Added persistent operations task manager for binary ML training.
- Added progress, elapsed time, ETA and current model visibility.
- Added safe pause, resume, cancellation and restart recovery.
- Added backend duplicate task protection and persistent uploaded task inputs.
