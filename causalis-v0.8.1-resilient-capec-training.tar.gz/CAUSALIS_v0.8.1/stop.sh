#!/usr/bin/env bash
set -euo pipefail
PORT="${CAUSALIS_PORT:-${ATG_PORT:-8080}}"
sudo fuser -k "${PORT}/tcp" || true
