# CAUSALIS 0.2.0 — Product Experience Preview

## Purpose

This release substantially redesigns the CAUSALIS GUI while preserving the validated experimentation core.

## Highlights

- Home is now the operational dashboard.
- Traffic has become Experiment Designer.
- Targets, Profiles, and Campaigns are organized as a left-to-right workflow.
- Intelligent Mode has become Guided Discovery.
- Data is now Data Engineering with an explicit staged workflow.
- Dataset split packaging has been removed from the global header and integrated into Data Engineering.
- Models is now Machine Learning with task-oriented views.
- Results is now Analytics & Reports.
- Official corrected CAUSALIS brand assets are included.
- README and architecture documentation have been rewritten for the new product experience.

## Compatibility

No destructive SQLite migration is introduced. The validated core APIs and `data/atg.db` path are preserved.

## Validation Required

Perform a complete regression cycle: campaign, logs, correlation, cleaning, dataset package, binary ML, CAPEC ML, analytics, HTML report, and PDF report.
