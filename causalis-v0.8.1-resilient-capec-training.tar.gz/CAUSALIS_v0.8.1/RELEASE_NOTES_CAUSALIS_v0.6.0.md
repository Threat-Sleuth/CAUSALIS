# CAUSALIS v0.6.0 — Full-Service Research Campaign

This release is designed to execute the first long-form thesis experiment against an authorized infrastructure containing eight paired service families while keeping CAUSALIS infrastructure-agnostic.

## Main additions

- Full-Service Research Campaign accelerator in the Traffic workspace.
- Automatic 8×2 reachability/readiness check before a long campaign.
- Reproducible generation of normal and CAPEC-labelled anomaly actions for HTTP, FTP, SSH, mail, PostgreSQL, REST API, SMB and WireGuard management traffic.
- Configurable action duration, rate, concurrency and repetitions.
- Long-running campaign preparation mode and explicit launch mode.
- Improved SMB generator that performs authentication, share enumeration, directory listing and controlled read/write operations when the share permits them.
- Batch evidence ZIP ingestion: automatic service/type identification from filenames, temporal correlation, duplicate removal and clean CSV generation.
- Reproducibility ZIP endpoint containing events, configuration, datasets, model artifacts and reports.
- Manual selectors now include REST API, IMAP and WireGuard UI.
- Product version and traffic user-agent updated to 0.6.0.

## Dataset and ML workflow

After the campaign:

1. collect logs from the paired containers;
2. package them in one ZIP using service and traffic-side names;
3. process the ZIP in Data Engineering;
4. export processed training/test splits;
5. use the existing Full ML profile to train every available classifier;
6. generate HTML/PDF reports and the reproducibility package.

## Important validation note

The package has passed static compilation and API regression smoke tests. Live traffic behavior must still be validated in the user's authorized laboratory, especially WireGuard tunnel semantics and service-specific credentials.
