# CAUSALIS v0.4.1 — Guided Discovery Wizard

## Purpose

Resolve the ambiguity in Step 2 of the Guided Experiment Wizard by embedding the former Intelligent Mode configuration directly in the environment selection flow.

## Changes

- Guided Discovery is labelled **Intelligent Mode** inside the wizard.
- Selecting it immediately reveals the authorized CIDR range, scan profile, ports, timeout, detection profile and controlled non-RFC1918 option.
- The wizard validates that a CIDR range has been provided before continuing.
- Discovery configuration is persisted in the experiment metadata and workflow configuration.
- After workspace creation, CAUSALIS opens Guided Discovery with the selected scope and ports preloaded.
- The scan never starts automatically; the researcher explicitly reviews and launches it.

## Unaffected modules

Traffic generation, scheduler, log correlation, dataset engineering, machine learning, reporting and SQLite compatibility are unchanged.

## Risk

Low. The change is restricted to the wizard, experiment metadata and Guided Discovery prefill.
