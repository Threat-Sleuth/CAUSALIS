#!/usr/bin/env bash
set -euo pipefail

APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$APP_DIR"

log(){ printf '[CAUSALIS][DEPLOY] %s\n' "$*"; }
fail(){ printf '[CAUSALIS][DEPLOY][ERROR] %s\n' "$*" >&2; exit 1; }

OWNER_USER="${SUDO_USER:-${USER:-$(id -un)}}"
OWNER_GROUP="$(id -gn "$OWNER_USER" 2>/dev/null || id -gn)"

log "Application directory: $APP_DIR"
log "Installation owner: $OWNER_USER:$OWNER_GROUP"

if ! command -v sudo >/dev/null 2>&1 && [[ ${EUID} -ne 0 ]]; then
  fail "sudo is required to install system dependencies."
fi

log "Installing required system packages..."
if [[ ${EUID} -eq 0 ]]; then
  apt-get update
  DEBIAN_FRONTEND=noninteractive apt-get install -y python3 python3-venv python3-pip
else
  sudo apt-get update
  sudo DEBIAN_FRONTEND=noninteractive apt-get install -y python3 python3-venv python3-pip
fi

create_venv_as_owner() {
  if [[ ${EUID} -eq 0 && "$OWNER_USER" != "root" ]]; then
    sudo -u "$OWNER_USER" -H python3 -m venv "$APP_DIR/.venv"
  else
    python3 -m venv "$APP_DIR/.venv"
  fi
}

if [[ ! -x "$APP_DIR/.venv/bin/python" ]]; then
  log "Creating persistent virtual environment at $APP_DIR/.venv..."
  rm -rf "$APP_DIR/.venv"
  create_venv_as_owner
else
  log "Existing virtual environment found; reusing it."
fi

VENV_PY="$APP_DIR/.venv/bin/python"
[[ -x "$VENV_PY" ]] || fail "Virtual environment creation failed: $VENV_PY was not created."

log "Installing Python dependencies inside the local virtual environment..."
if [[ ${EUID} -eq 0 && "$OWNER_USER" != "root" ]]; then
  sudo -u "$OWNER_USER" -H "$VENV_PY" -m pip install --upgrade pip
  sudo -u "$OWNER_USER" -H "$VENV_PY" -m pip install -r "$APP_DIR/requirements.txt"
else
  "$VENV_PY" -m pip install --upgrade pip
  "$VENV_PY" -m pip install -r "$APP_DIR/requirements.txt"
fi

log "Creating persistent data directories..."
mkdir -p data/logs data/exports data/config data/uploads data/models

if [[ ${EUID} -eq 0 ]]; then
  chown -R "$OWNER_USER:$OWNER_GROUP" "$APP_DIR/.venv" "$APP_DIR/data" 2>/dev/null || true
fi

[[ -x "$APP_DIR/.venv/bin/uvicorn" ]] || fail "uvicorn was not installed in the virtual environment."

cat > "$APP_DIR/.causalis-installation" <<MARKER
version=$(cat VERSION 2>/dev/null || echo unknown)
installed_at=$(date --iso-8601=seconds)
python=$($VENV_PY --version 2>&1)
venv=$APP_DIR/.venv
MARKER

if [[ ${EUID} -eq 0 ]]; then
  chown "$OWNER_USER:$OWNER_GROUP" "$APP_DIR/.causalis-installation" 2>/dev/null || true
fi

chmod +x deploy.sh run.sh stop.sh

log "Installation completed and verified successfully."
log "The virtual environment is persistent at: $APP_DIR/.venv"
log "Start CAUSALIS with: ./run.sh"
log "Default URL: http://<HOST_IP>:${CAUSALIS_PORT:-${ATG_PORT:-8080}}"
