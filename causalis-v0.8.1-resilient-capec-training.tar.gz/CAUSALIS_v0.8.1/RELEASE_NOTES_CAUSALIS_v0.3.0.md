# CAUSALIS v0.3.0 — Experiment Workspace

## Purpose

CAUSALIS v0.3.0 introduces the first persistent experiment-oriented layer above the validated v0.2.1 execution core.

## New capabilities

- Persistent Experiment Workspace stored in SQLite.
- Legacy Workspace automatically created for existing installations.
- Create, select, update, clone, and archive-ready experiments.
- Permanent product sidebar with current experiment context.
- Experiment library and detailed workspace overview.
- Readiness indicators for targets, profiles, traffic, datasets, ML, and reports.
- Editable workflow with ordered, enabled/disabled steps.
- Unified experiment activity timeline.
- Campaign groups automatically associated with the active experiment.
- ML experiments automatically associated with the active experiment.
- Generated reports recorded in experiment activity.
- Non-destructive SQLite migrations.

## Compatibility

The traffic engine, scheduler, Intelligent Mode, log correlation, data cleaning, dataset split generation, ML training, reporting, and existing APIs remain available.

Existing databases are upgraded additively. No validated table or artifact is removed.

## Validation focus

1. Deploy or upgrade with an existing `data/atg.db`.
2. Confirm Legacy Workspace is created.
3. Create and clone an experiment.
4. Run a complete campaign and ML workflow under the selected experiment.
5. Confirm activity, readiness, and associations update.
6. Confirm all v0.2.1 regression workflows remain functional.
