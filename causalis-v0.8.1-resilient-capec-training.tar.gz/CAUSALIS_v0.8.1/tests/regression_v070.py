import csv
import shutil
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from app import main  # noqa: E402


def test_rest_api_split_and_http_utc():
    test_root = ROOT / "data" / "test_v070"
    shutil.rmtree(test_root, ignore_errors=True)
    (test_root / "clean").mkdir(parents=True)
    (test_root / "split").mkdir()
    original_clean, original_split = main.CLEAN_DIR, main.SPLIT_DIR
    try:
        main.CLEAN_DIR = test_root / "clean"
        main.SPLIT_DIR = test_root / "split"
        fields = ["service", "mode", "label", "capec_category"]
        for kind, label in [("normal", "benign"), ("anomaly", "anomaly")]:
            path = main.CLEAN_DIR / f"clean_rest_api_{kind}_20260725_120000.csv"
            with path.open("w", newline="", encoding="utf-8") as handle:
                writer = csv.DictWriter(handle, fieldnames=fields)
                writer.writeheader()
                for _ in range(10):
                    writer.writerow({
                        "service": "rest_api",
                        "mode": kind,
                        "label": label,
                        "capec_category": "Normal Traffic" if kind == "normal" else "Injection",
                    })
        response = main.split(output_dir="data/test_v070/split")
        with zipfile.ZipFile(response.path) as archive:
            names = sorted(archive.namelist())
        expected = [
            "rest_api/rest_api_anomaly_test.csv",
            "rest_api/rest_api_anomaly_training.csv",
            "rest_api/rest_api_normal_test.csv",
            "rest_api/rest_api_normal_training.csv",
        ]
        assert names == expected

        line = '{"timestamp": "2026-07-24T06:04:20.145833", "x": 1}'
        actual = main.log_time(line)
        expected_epoch = datetime(2026, 7, 24, 6, 4, 20, 145833, tzinfo=timezone.utc).timestamp()
        assert abs(actual - expected_epoch) < 1e-6
    finally:
        main.CLEAN_DIR, main.SPLIT_DIR = original_clean, original_split
        shutil.rmtree(test_root, ignore_errors=True)


if __name__ == "__main__":
    test_rest_api_split_and_http_utc()
    print("CAUSALIS v0.7.0 regression tests: PASS")
