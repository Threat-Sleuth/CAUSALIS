# CAUSALIS Architecture

**Version:** 0.5.0  
**Release:** Guided Experimentation  
**Validated baseline:** CAUSALIS 0.3.0 Experiment Workspace / ThreatSleuth ATG 1.0.0 Core

## Architectural Principle

CAUSALIS evolves through additive product layers around a validated experimentation core. The traffic engine, scheduler, event registration, log correlation, data cleaning, model training, SQLite persistence, and reporting behavior are preserved unless a release explicitly declares a core change.

> **Do not break what already works.**

## Logical Architecture

```text
Browser GUI
   │
   ├── Guided Experiment Wizard
   ├── Professional Experiment Workspace
   ├── Live Home and Recommendations
   ├── Artifact Explorer
   ├── Analytics and Reporting
   └── Product Diagnostics
   │
   ▼
FastAPI Application
   ├── Experiment API
   ├── Guided Experiment Translator
   ├── Recommendation Engine
   ├── Workflow Model
   ├── Experiment Designer
   ├── Guided Discovery
   ├── Traffic Generation Engine
   ├── Campaign Scheduler
   ├── Event Registration
   ├── Log Correlation
   ├── Data Engineering
   ├── Machine Learning
   └── HTML/PDF Reporting
   │
   ├── SQLite
   └── File Artifact Storage
```

## One Internal Experiment Model

Assisted and professional workflows use the same experiment object. The wizard does not create a second implementation. It translates user choices into experiment metadata and a transparent workflow that can be inspected and edited.

```text
Guided Wizard ─────┐
                   ├── Experiment Object ── Workflow ── Validated Modules
Professional GUI ──┘
```

## Experiment Object

An experiment contains or references:

- Metadata, objective, tags, and lifecycle status
- Workflow steps and configuration
- Targets and traffic profiles
- Campaign executions and evidence
- Datasets and quality artifacts
- Machine-learning experiments and models
- Reports and exported artifacts
- Timeline and recommendations

## Guided Experiment Translator

The v0.4 guided endpoint converts the following user choices into an editable workspace:

- Objective
- Infrastructure mode
- Traffic strategy
- Dataset outputs
- Machine-learning profile
- Report formats

No traffic is executed automatically. The researcher retains explicit control before execution.

## Recommendation Engine

The recommendation engine evaluates experiment readiness and proposes the next logical action:

1. Configure targets
2. Create profiles
3. Run traffic
4. Engineer datasets
5. Train models
6. Generate reports

Recommendations are deterministic and transparent. They are not presented as artificial intelligence.

## Artifact Explorer

The v0.4 explorer provides a read-only view of validated filesystem artifacts, grouped into matched logs, clean datasets, dataset splits, ML datasets, models, reports, and uploads. Artifact ownership is currently workspace-compatible but global. Explicit per-experiment artifact ownership is deferred to a later storage migration.

## Persistence

SQLite remains the embedded persistence mechanism. Schema evolution is additive and non-destructive. The database remains at:

```text
data/atg.db
```

File artifacts remain under `data/exports`, `data/models`, and `data/uploads`.

## Compatibility

CAUSALIS 0.4 does not modify the validated implementations of:

- Traffic generation
- Campaign scheduling
- Intelligent Mode scanning
- Log correlation
- Dataset analysis and cleaning
- Binary and CAPEC model training
- HTML/PDF report generation

## Future Extension Points

The generic workflow step model already includes an optional `technique_id`. This prepares the architecture for MITRE ATT&CK techniques, APT scenarios, visual workflow editing, and graph-based ground truth without creating a separate execution engine.

## Generic Service Adapter Registry

Version 0.5.0 introduces a generic registry that maps discovered endpoints to service adapters. The registry is not tied to a particular laboratory deployment. Controlled cyber-range port pairs may be used as presets, but all generated objects remain editable.

Each adapter defines supported ports, normal interactions, CAPEC-oriented anomaly families, default laboratory parameters and execution behavior. The initial extended set covers HTTP/web, REST API, FTP, SSH, SMTP, IMAP, SMB, PostgreSQL and WireGuard management interfaces.

```text
Network Discovery
        ↓
Port-to-Service Identification
        ↓
Editable Target
        ↓
Service Adapter
        ↓
Normal Profiles + CAPEC Profiles
        ↓
Editable Campaign Proposal
```

The existing campaign engine, scheduler, event persistence and dataset pipeline remain unchanged.

