#!/usr/bin/env python3
import socket,sys
h=sys.argv[1] if len(sys.argv)>1 else "100.10.10.3"; p=int(sys.argv[2]) if len(sys.argv)>2 else 80; path=sys.argv[3] if len(sys.argv)>3 else "/atg-test"
req=f"GET {path} HTTP/1.1\r\nHost: {h}:{p}\r\nUser-Agent: ATG-v10-raw\r\nConnection: close\r\n\r\n".encode()
with socket.create_connection((h,p),timeout=5) as s:
    s.sendall(req)
    try: data=s.recv(512)
    except Exception: data=b""
print("Recibidos",len(data),"bytes")
print(data.decode(errors="ignore")[:300])
