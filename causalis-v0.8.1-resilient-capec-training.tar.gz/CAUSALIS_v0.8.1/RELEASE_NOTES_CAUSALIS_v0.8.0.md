# CAUSALIS v0.8.0 — Persistent Operations

## Critical operational improvements

- Persistent SQLite-backed task manager for long-running binary ML training.
- Live progress by model, current service/model, elapsed time and estimated remaining time.
- Safe pause at model boundaries, resume and controlled cancellation.
- Task state survives page reloads and application restarts.
- Uploaded datasets are copied to `data/tasks/<task_id>/` so interrupted jobs can be resumed.
- Backend duplicate-execution protection: only one active binary training task is permitted.
- Automatic recovery: tasks interrupted by shutdown are marked paused and offered for resume.
- Completed model artifacts and completed service experiments remain preserved.

## Resume semantics

- A pause request takes effect after the model currently being fitted reaches a safe checkpoint.
- After a normal pause, execution continues with the next pending model.
- After a full application or machine restart, the interrupted service is restarted safely from its beginning because scikit-learn estimators do not provide generic mid-fit checkpoints. Previously completed service experiments remain stored.

## Compatibility

- Preserves the validated v0.7.0 research pipeline and existing endpoints.
- Existing campaign, evidence processing, dataset engineering, CAPEC training and reporting functionality remains available.
