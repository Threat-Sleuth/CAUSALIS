# CAUSALIS v0.5.0 — Extended Service Campaign Generation

## Purpose

Extend generic discovery and automatic campaign generation to cover at least eight service families while preserving the validated CAUSALIS workflow.

## Added

- Generic service-adapter registry.
- Extended discovery preset for controlled laboratories.
- Port recognition for paired normal/anomaly endpoints.
- Real traffic generators for REST API, IMAP, SMB, PostgreSQL and WireGuard management UI.
- Expanded SMTP behavior and CAUSALIS traffic headers.
- CAPEC-family profile generation per detected service.
- Service catalog API endpoint.
- Optional dependencies: psycopg2-binary and pysmb.

## Supported extended set

HTTP/web, REST API, FTP, SSH, SMTP, IMAP, SMB, PostgreSQL and WireGuard management UI. SMTP and IMAP form the logical mail service family.

## Generality

The implementation is infrastructure-agnostic. The extended port preset is only a convenience. Targets, services, profiles, credentials, CAPEC families and campaign actions remain reviewable and editable.

## Known limitations

- Discovery is TCP connect and port based; banner fingerprinting is not yet implemented.
- WireGuard UDP tunnel ports are not scanned; only TCP management interfaces are exercised.
- New service-specific log feature extractors are outside this release; the existing tolerant temporal correlation remains available.

## Unchanged modules

Scheduler, manual campaign design, experiment workspace, dataset cleaning, ML training, analytics and report generation.
