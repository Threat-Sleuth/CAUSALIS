# CAUSALIS v0.2.1 — Deployment Reliability Fix

This maintenance release preserves the CAUSALIS v0.2.0 Product Experience Preview and fixes deployment/startup reliability.

## Fixed

- The deployment script no longer creates the application virtual environment as root and then retrofits ownership.
- The persistent `.venv` is created as the original desktop user whenever deployment is launched through `sudo`.
- Deployment now verifies both Python and Uvicorn before reporting success.
- A `.causalis-installation` marker records the installed version, time, Python version and environment path.
- `run.sh` validates `.venv` and legacy `venv` locations and provides a precise diagnostic when the application directory was replaced after deployment.
- Startup now invokes Uvicorn directly from the validated environment, without depending on shell activation.
- Official corrected CAUSALIS brand assets supplied by the project owner replace previous generated assets.
- `README.md` is now pure GitHub Flavored Markdown with no embedded HTML tags.

## Preserved

No traffic-generation, scheduling, correlation, dataset-cleaning, machine-learning or SQLite behavior was changed.
