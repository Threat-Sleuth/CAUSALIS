# CAUSALIS v0.4.0 — Guided Experimentation

## Added

- Six-step Guided Experiment wizard
- Single internal experiment model for assisted and professional workflows
- Live experiment completion indicator on Home
- Deterministic next-action recommendations
- Read-only Artifact Explorer
- About and diagnostics panel
- Guided experiment metadata and workflow configuration

## Modified Modules

- GUI and product experience
- Experiment Workspace API
- Experiment summary and recommendation logic
- Documentation and version metadata

## Unaffected Validated Modules

- Traffic generation engine
- Scheduler
- Guided Discovery TCP scanner
- Event persistence
- Log correlation
- Dataset analysis and cleaning
- Binary and CAPEC machine learning
- HTML/PDF reporting

## Database Migration

No destructive migration. Existing experiment tables and metadata JSON are reused.

## Validation Performed

- Python compilation
- FastAPI import and route registration
- JavaScript syntax validation
- Bash syntax validation
- HTML identifier uniqueness
- Guided experiment creation smoke test
- Recommendation generation smoke test
- Artifact Explorer smoke test
- About/diagnostics smoke test

## Known Limitation

Artifact Explorer currently displays a global read-only inventory compatible with the active workspace. Explicit artifact ownership by experiment will be introduced in a future storage migration.
