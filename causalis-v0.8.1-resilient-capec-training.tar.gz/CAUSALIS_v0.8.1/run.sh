#!/usr/bin/env bash
set -euo pipefail

APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$APP_DIR"

VENV_DIR=""
for candidate in "$APP_DIR/.venv" "$APP_DIR/venv"; do
  if [[ -x "$candidate/bin/python" && -x "$candidate/bin/uvicorn" ]]; then
    VENV_DIR="$candidate"
    break
  fi
done

if [[ -z "$VENV_DIR" ]]; then
  echo "[CAUSALIS][START][ERROR] A valid local virtual environment was not found." >&2
  echo "Expected: $APP_DIR/.venv/bin/python and $APP_DIR/.venv/bin/uvicorn" >&2
  if [[ -f "$APP_DIR/.causalis-installation" ]]; then
    echo "An installation marker exists, but the environment is missing or incomplete." >&2
    echo "This usually means the application directory was replaced after deployment." >&2
  fi
  echo "Connect this VM to the Internet and run ./deploy.sh once. Wait for the final" >&2
  echo "'Installation completed and verified successfully' message before shutting down." >&2
  exit 1
fi

PORT="${CAUSALIS_PORT:-${ATG_PORT:-8080}}"
HOST="${CAUSALIS_HOST:-0.0.0.0}"

echo "[CAUSALIS][START] Version $(cat VERSION 2>/dev/null || echo unknown)"
echo "[CAUSALIS][START] Environment: $VENV_DIR"
echo "[CAUSALIS][START] Listening on http://$HOST:$PORT"

exec "$VENV_DIR/bin/uvicorn" app.main:app --host "$HOST" --port "$PORT"
