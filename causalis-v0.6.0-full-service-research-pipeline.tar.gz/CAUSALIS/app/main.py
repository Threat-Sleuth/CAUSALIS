"""CAUSALIS application server.

CAUSALIS is a controlled cyber experimentation and dataset engineering platform built on the validated ThreatSleuth ATG 1.0.0 research core. Product-oriented changes preserve the experimentally validated traffic, processing, scheduling, and machine-learning behavior.
"""


from fastapi import FastAPI, HTTPException, UploadFile, File, Form
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from typing import Optional, Literal, List, Dict, Any
from pathlib import Path
from datetime import datetime
import json,csv,uuid,time,threading,socket,random,re,zipfile,ftplib,smtplib,imaplib,requests,math,statistics,io,sqlite3,os,pickle,ipaddress,concurrent.futures,base64,html,platform,sys,shutil,tempfile
try:
    import dns.resolver
except Exception:
    dns=None
try:
    import paramiko
except Exception:
    paramiko=None
try:
    import psycopg2
except Exception:
    psycopg2=None
try:
    from smb.SMBConnection import SMBConnection
except Exception:
    SMBConnection=None

APP=Path(__file__).resolve().parent
ROOT=APP.parent
DATA=ROOT/"data"; LOGS=DATA/"logs"; EXP=DATA/"exports"; CFG=DATA/"config"; UPLOADS=DATA/"uploads"; MODELS_DIR=DATA/"models"
MATCHED_DIR=EXP/"matched_logs"; CLEAN_DIR=EXP/"clean_datasets"; SPLIT_DIR=EXP/"dataset_splits"; ML_DATASETS_DIR=EXP/"ml_datasets"; ML_REPORTS_DIR=EXP/"ml_reports"; EXPERIMENTS_DIR=DATA/"experiments"
for p in [LOGS,EXP,CFG,UPLOADS,MODELS_DIR,MATCHED_DIR,CLEAN_DIR,SPLIT_DIR,ML_DATASETS_DIR,ML_REPORTS_DIR,EXPERIMENTS_DIR]: p.mkdir(parents=True,exist_ok=True)
DB_PATH=DATA/"atg.db"

PRODUCT_NAME="CAUSALIS"
PRODUCT_VERSION="0.6.0"
PRODUCT_DESCRIPTOR="Controlled Cyber Experimentation"
PRODUCT_TAGLINE="From controlled action to measurable evidence."
BASELINE_NAME="Validated ThreatSleuth ATG 1.0.0 Core"
BRAND_DIR=APP/"static"/"brand"
BRAND_LOGO=BRAND_DIR/"causalis_logo_horizontal.png"
BRAND_ISOTYPE=BRAND_DIR/"causalis_isotype.png"
EVENTS=LOGS/"events.jsonl"; TARGETS=CFG/"targets.json"; PROFILES=CFG/"profiles.json"; CAMPAIGN_HISTORY=CFG/"campaign_history.json"

# Global lock used to prevent concurrent ML/report jobs from corrupting state or exhausting RAM.
ML_JOB_LOCK = threading.Lock()

SERVICES=["http","https","rest_api","ftp","ssh","dns","smtp","imap","smb","postgresql","wireguard_ui","tcp","ldap","rdp","mysql"]
CAPEC={
"abuse_of_functionality":{"capec_id":"CAPEC-117","capec_category":"Abuse of Functionality"},
"resource_depletion":{"capec_id":"CAPEC-130","capec_category":"Resource Depletion"},
"data_leakage":{"capec_id":"CAPEC-118","capec_category":"Data Leakage"},
"subverting_authentication":{"capec_id":"CAPEC-115","capec_category":"Subverting Authentication"},
"probabilistic_techniques":{"capec_id":"CAPEC-49","capec_category":"Probabilistic Techniques"},
"injection":{"capec_id":"CAPEC-66","capec_category":"Injection"},
"time_and_state":{"capec_id":"CAPEC-29","capec_category":"Time and State"},
"spoofing":{"capec_id":"CAPEC-111","capec_category":"Spoofing"},
"benign":{"capec_id":"","capec_category":"Normal Traffic"}}

class Target(BaseModel):
    id:str=Field(default_factory=lambda:str(uuid.uuid4()))
    name:str; host:str; port:int=80; service:str="http"; notes:str=""
class Campaign(BaseModel):
    target_name:str="manual"; host:str; port:int=80; service:str="http"
    mode:Literal["normal","anomaly"]="normal"; attack_category:Optional[str]="abuse_of_functionality"
    duration_seconds:int=30; rate_per_second:float=1.0; concurrency:int=1
    path:str="/"; username:str=""; password:str=""; dns_query:str="example.com"; payload:str=""
    profile_name:str=""; scheduled_start:str=""; scheduled_start_epoch:Optional[float]=None
class CampaignAction(BaseModel):
    target_name:str="manual"; host:str; port:int=80; service:str="http"
    mode:Literal["normal","anomaly"]="normal"; attack_category:Optional[str]="abuse_of_functionality"
    duration_seconds:int=30; rate_per_second:float=1.0; concurrency:int=1
    path:str="/"; username:str=""; password:str=""; dns_query:str="example.com"; payload:str=""
    profile_name:str=""

class CampaignGroup(BaseModel):
    name:str
    actions:List[CampaignAction]
    execute_now:bool=True
    scheduled_start:str=""
    scheduled_start_epoch:Optional[float]=None
    notes:str=""
class Profile(BaseModel):
    name:str; service:str; mode:str; attack_category:Optional[str]="abuse_of_functionality"; port:int
    duration_seconds:int=30; rate_per_second:float=1; concurrency:int=1
    path:str="/"; username:str=""; password:str=""; dns_query:str="example.com"; payload:str=""; description:str=""
class ResearchCampaignReq(BaseModel):
    name: str = "Thesis Full-Service Research Campaign"
    host: str = "100.10.10.3"
    normal_duration_seconds: int = 1800
    anomaly_duration_seconds: int = 1200
    normal_rate_per_second: float = 2.0
    anomaly_rate_per_second: float = 2.0
    concurrency: int = 2
    repetitions: int = 2
    launch: bool = False
    require_complete_coverage: bool = True
    include_capec_categories: List[str] = []

class ResearchEvidenceReq(BaseModel):
    window_seconds: int = 8
    remove_unmatched: bool = False
    drop_duplicates: bool = True

class MatchReq(BaseModel):
    service:str; log_text:str; window_seconds:int=5; dataset_kind:str="all"
class CleanReq(BaseModel):
    upload_id:str
    service:str="unknown"
    dataset_kind:str="all"
    drop_columns:List[str]=[]
    drop_outlier_rows:bool=False
    drop_duplicate_rows:bool=False
    normalize_text:bool=False

class MLTrainReq(BaseModel):
    upload_id:str
    target_column:str
    service_column:str="service"
    test_size:float=0.25
    random_seed:int=42
    experiment_name:str=""
    group_by_service:bool=True

class MLBinaryTrainReq(BaseModel):
    service:str
    experiment_name:str=""
    random_seed:int=42

class MLMultiServiceReq(BaseModel):
    services: List[str] = []
    experiment_name: str = ""
    random_seed: int = 42

class IntelligentScanReq(BaseModel):
    """Input model for Intelligent Mode network discovery.

    The scanner is intentionally limited to private laboratory networks by
    default. It uses TCP connect checks only and never executes external shell
    commands, which keeps the discovery step deterministic and reduces command
    injection risk.
    """
    ip_range: str
    ports: str = "80,81,2121,2122,2222,2223,25,2525,587,1587,143,1143,993,1993,445,1445,5433,5434,8000,8001,51821,51823"
    timeout_seconds: float = 0.35
    save_generated: bool = False
    allow_non_private: bool = False
    campaign_objective: str = "research_dataset"
    detection_profile: str = "generic_extended_services"
    max_workers: int = 48

class IntelligentApplyReq(BaseModel):
    targets: List[Dict[str, Any]] = []
    profiles: List[Dict[str, Any]] = []
    campaign_name: str = "Intelligent Campaign Proposal"
    actions: List[Dict[str, Any]] = []
    notes: str = "Generated by Intelligent Mode"

class ExperimentCreateReq(BaseModel):
    name: str
    description: str = ""
    objective: str = "dataset_generation"
    tags: List[str] = []


class GuidedExperimentReq(BaseModel):
    name: str
    description: str = ""
    objective: str = "dataset_generation"
    tags: List[str] = []
    infrastructure_mode: str = "existing_lab"
    traffic_profile: str = "quick"
    dataset_outputs: List[str] = ["binary"]
    ml_profile: str = "fast"
    report_formats: List[str] = ["html"]
    include_ml: bool = True
    include_report: bool = True
    discovery: Optional[Dict[str, Any]] = None

class ExperimentUpdateReq(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    objective: Optional[str] = None
    status: Optional[str] = None
    tags: Optional[List[str]] = None

class WorkflowStepReq(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    step_type: str
    name: str
    enabled: bool = True
    order: int = 0
    technique_id: Optional[str] = None
    configuration: Dict[str, Any] = {}

class WorkflowUpdateReq(BaseModel):
    steps: List[WorkflowStepReq] = []

def now(): return datetime.now().astimezone().isoformat(timespec="seconds")
def epoch(): return int(datetime.now().timestamp())
def load(path,default):
    try: return json.loads(path.read_text(encoding="utf-8"))
    except Exception: return default
def save(path,obj): path.write_text(json.dumps(obj,indent=2,ensure_ascii=False),encoding="utf-8")


# ---------------------------------------------------------------------------
# Input validation and security helpers
# ---------------------------------------------------------------------------
# The application is intended for controlled laboratory environments, but every
# user-controlled value is still treated as untrusted. These helpers protect the
# UI/API boundary against common mistakes and injection-style payloads before
# values are stored in SQLite or used to build file names.
SAFE_TEXT_RE = re.compile(r"^[\w\s\.\-:@/,+()#=]*$", re.UNICODE)
SAFE_TOKEN_RE = re.compile(r"^[A-Za-z0-9_.-]+$")
DANGEROUS_PATTERNS = re.compile(r"(<\s*script|</|;\s*drop\s+table|\$\(|`|\.\./|\x00)", re.IGNORECASE)


def _reject_dangerous(value: Any, field_name: str, max_len: int = 512) -> str:
    """Validate a user-controlled string without silently executing or expanding it."""
    if value is None:
        return ""
    text = str(value).strip()
    if len(text) > max_len:
        raise HTTPException(400, f"{field_name} is too long")
    if DANGEROUS_PATTERNS.search(text):
        raise HTTPException(400, f"{field_name} contains unsafe characters or patterns")
    if not SAFE_TEXT_RE.match(text):
        raise HTTPException(400, f"{field_name} contains unsupported characters")
    return text


def _safe_token(value: Any, field_name: str, default: str = "unknown") -> str:
    """Return a conservative token suitable for service names and file names."""
    text = str(value or default).strip().lower()
    text = re.sub(r"[^a-zA-Z0-9_-]+", "_", text).strip("_") or default
    if not SAFE_TOKEN_RE.match(text):
        raise HTTPException(400, f"{field_name} is not valid")
    return text


def _positive_int(value: Any, field_name: str, minimum: int = 1, maximum: int = 86400) -> int:
    try:
        n = int(value)
    except Exception:
        raise HTTPException(400, f"{field_name} must be an integer")
    if n < minimum or n > maximum:
        raise HTTPException(400, f"{field_name} must be between {minimum} and {maximum}")
    return n


def _positive_float(value: Any, field_name: str, minimum: float = 0.01, maximum: float = 10000.0) -> float:
    try:
        n = float(value)
    except Exception:
        raise HTTPException(400, f"{field_name} must be numeric")
    if n < minimum or n > maximum:
        raise HTTPException(400, f"{field_name} must be between {minimum} and {maximum}")
    return n


def _validate_target_payload(d: Dict[str, Any]) -> Dict[str, Any]:
    """Validate target data before saving it to SQLite."""
    d = dict(d)
    d["name"] = _reject_dangerous(d.get("name"), "target name", 120)
    d["host"] = _reject_dangerous(d.get("host"), "host", 255)
    d["service"] = _safe_token(d.get("service"), "service")
    d["port"] = _positive_int(d.get("port", 80), "port", 1, 65535)
    d["notes"] = _reject_dangerous(d.get("notes", ""), "notes", 500)
    return d


def _validate_profile_payload(d: Dict[str, Any]) -> Dict[str, Any]:
    """Validate reusable traffic profile data, including credentials and timing."""
    d = dict(d)
    d["name"] = _reject_dangerous(d.get("name"), "profile name", 120)
    d["service"] = _safe_token(d.get("service"), "service")
    d["mode"] = "anomaly" if str(d.get("mode", "normal")).lower() == "anomaly" else "normal"
    d["attack_category"] = _safe_token(d.get("attack_category") or "benign", "attack category")
    d["port"] = _positive_int(d.get("port", 80), "port", 1, 65535)
    d["duration_seconds"] = _positive_int(d.get("duration_seconds", 30), "duration", 1, 86400)
    d["rate_per_second"] = _positive_float(d.get("rate_per_second", 1), "rate", 0.01, 10000)
    d["concurrency"] = _positive_int(d.get("concurrency", 1), "concurrency", 1, 1000)
    for k in ["path", "username", "password", "dns_query", "payload", "description"]:
        d[k] = _reject_dangerous(d.get(k, ""), k, 1000)
    return d


def _validate_campaign_payload(d: Dict[str, Any]) -> Dict[str, Any]:
    """Validate a one-off traffic request or a campaign action."""
    d = dict(d)
    d["target_name"] = _reject_dangerous(d.get("target_name", "manual"), "target name", 120)
    d["host"] = _reject_dangerous(d.get("host"), "host", 255)
    d["service"] = _safe_token(d.get("service"), "service")
    d["mode"] = "anomaly" if str(d.get("mode", "normal")).lower() == "anomaly" else "normal"
    d["attack_category"] = _safe_token(d.get("attack_category") or "benign", "attack category")
    d["port"] = _positive_int(d.get("port", 80), "port", 1, 65535)
    d["duration_seconds"] = _positive_int(d.get("duration_seconds", 30), "duration", 1, 86400)
    d["rate_per_second"] = _positive_float(d.get("rate_per_second", 1), "rate", 0.01, 10000)
    d["concurrency"] = _positive_int(d.get("concurrency", 1), "concurrency", 1, 1000)
    for k in ["path", "username", "password", "dns_query", "payload", "profile_name", "scheduled_start"]:
        d[k] = _reject_dangerous(d.get(k, ""), k, 1000)
    return d


def _safe_output_dir(value: Optional[str], default_dir: Path) -> Path:
    """Resolve an export directory while preventing path traversal outside ATG_ROOT."""
    if not value:
        default_dir.mkdir(parents=True, exist_ok=True)
        return default_dir
    raw = _reject_dangerous(value, "output directory", 500)
    candidate = Path(raw).expanduser()
    if not candidate.is_absolute():
        candidate = ROOT / candidate
    candidate = candidate.resolve()
    root = ROOT.resolve()
    try:
        candidate.relative_to(root)
    except ValueError:
        raise HTTPException(400, "Output directory must be inside the ATG application directory")
    candidate.mkdir(parents=True, exist_ok=True)
    return candidate


_db_lock=threading.RLock()
_scheduler_started=False

def db_conn():
    con=sqlite3.connect(str(DB_PATH), check_same_thread=False)
    con.row_factory=sqlite3.Row
    return con

def init_db():
    with _db_lock, db_conn() as con:
        con.executescript("""
        PRAGMA journal_mode=WAL;
        CREATE TABLE IF NOT EXISTS targets(
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            host TEXT NOT NULL,
            port INTEGER NOT NULL,
            service TEXT NOT NULL,
            notes TEXT,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS profiles(
            name TEXT PRIMARY KEY,
            service TEXT NOT NULL,
            mode TEXT NOT NULL,
            attack_category TEXT,
            port INTEGER NOT NULL,
            duration_seconds INTEGER,
            rate_per_second REAL,
            concurrency INTEGER,
            path TEXT,
            username TEXT,
            password TEXT,
            dns_query TEXT,
            payload TEXT,
            description TEXT,
            updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS campaign_groups(
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            status TEXT NOT NULL,
            created_at TEXT NOT NULL,
            started_at TEXT,
            finished_at TEXT,
            scheduled_start TEXT,
            scheduled_start_epoch REAL,
            execute_now INTEGER NOT NULL,
            notes TEXT,
            actions_total INTEGER NOT NULL,
            actions_finished INTEGER NOT NULL DEFAULT 0,
            child_campaigns TEXT NOT NULL DEFAULT '[]',
            progress_pct REAL NOT NULL DEFAULT 0,
            group_json TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS events(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT,
            timestamp_epoch INTEGER,
            campaign_id TEXT,
            target_name TEXT,
            host TEXT,
            port INTEGER,
            service TEXT,
            mode TEXT,
            label TEXT,
            attack_category_key TEXT,
            capec_id TEXT,
            capec_category TEXT,
            action TEXT,
            status TEXT,
            latency_ms REAL,
            detail TEXT,
            profile_name TEXT,
            matched INTEGER DEFAULT 0,
            matched_log_line TEXT,
            raw_json TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS app_settings(key TEXT PRIMARY KEY, value TEXT, updated_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS experiments(
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            description TEXT,
            objective TEXT NOT NULL DEFAULT 'dataset_generation',
            status TEXT NOT NULL DEFAULT 'draft',
            tags_json TEXT NOT NULL DEFAULT '[]',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            cloned_from TEXT,
            archived INTEGER NOT NULL DEFAULT 0,
            metadata_json TEXT NOT NULL DEFAULT '{}'
        );
        CREATE TABLE IF NOT EXISTS experiment_workflows(
            experiment_id TEXT PRIMARY KEY,
            steps_json TEXT NOT NULL DEFAULT '[]',
            updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS experiment_activities(
            id TEXT PRIMARY KEY,
            experiment_id TEXT,
            activity_type TEXT NOT NULL,
            status TEXT NOT NULL,
            summary TEXT NOT NULL,
            created_at TEXT NOT NULL,
            metadata_json TEXT NOT NULL DEFAULT '{}'
        );
        CREATE TABLE IF NOT EXISTS ml_experiments(
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            dataset_filename TEXT,
            target_column TEXT NOT NULL,
            service_column TEXT,
            rows_total INTEGER,
            columns_total INTEGER,
            test_size REAL,
            random_seed INTEGER,
            created_at TEXT NOT NULL,
            best_model TEXT,
            best_service_summary TEXT,
            config_json TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS ml_results(
            id TEXT PRIMARY KEY,
            experiment_id TEXT NOT NULL,
            service TEXT NOT NULL,
            model_name TEXT NOT NULL,
            accuracy REAL,
            precision_macro REAL,
            recall_macro REAL,
            f1_macro REAL,
            f1_weighted REAL,
            mcc REAL,
            roc_auc REAL,
            train_seconds REAL,
            artifact_path TEXT,
            confusion_matrix_json TEXT,
            report_json TEXT,
            created_at TEXT NOT NULL
        );
        """)
        # Migraciones no destructivas para instalaciones existentes.
        cols=[r[1] for r in con.execute("PRAGMA table_info(campaign_groups)").fetchall()]
        if "scheduled_start_epoch" not in cols:
            con.execute("ALTER TABLE campaign_groups ADD COLUMN scheduled_start_epoch REAL")
        if "experiment_id" not in cols:
            con.execute("ALTER TABLE campaign_groups ADD COLUMN experiment_id TEXT")
        ml_cols=[r[1] for r in con.execute("PRAGMA table_info(ml_experiments)").fetchall()]
        if "workspace_experiment_id" not in ml_cols:
            con.execute("ALTER TABLE ml_experiments ADD COLUMN workspace_experiment_id TEXT")
        con.commit()
        _ensure_default_experiment(con)
    migrate_json_to_db()

def _ensure_default_experiment(con=None):
    owns=False
    if con is None:
        con=db_conn(); owns=True
    count=con.execute("SELECT COUNT(*) FROM experiments WHERE archived=0").fetchone()[0]
    if count==0:
        eid="legacy-workspace"
        ts=now()
        con.execute("""INSERT OR IGNORE INTO experiments(id,name,description,objective,status,tags_json,created_at,updated_at,cloned_from,archived,metadata_json)
                     VALUES(?,?,?,?,?,?,?,?,?,?,?)""",(eid,"Legacy Workspace","Existing CAUSALIS artifacts imported from the validated v0.2.x baseline.","legacy","active","[]",ts,ts,None,0,"{}"))
        con.execute("INSERT OR REPLACE INTO app_settings(key,value,updated_at) VALUES('current_experiment_id',?,?)",(eid,ts))
        con.execute("INSERT OR IGNORE INTO experiment_workflows(experiment_id,steps_json,updated_at) VALUES(?,?,?)",(eid,json.dumps(_default_workflow()),ts))
        con.commit()
    # Associate pre-v0.3 records with the non-destructive Legacy Workspace.
    con.execute("UPDATE campaign_groups SET experiment_id='legacy-workspace' WHERE experiment_id IS NULL OR experiment_id='' ")
    con.execute("UPDATE ml_experiments SET workspace_experiment_id='legacy-workspace' WHERE workspace_experiment_id IS NULL OR workspace_experiment_id='' ")
    con.commit()
    if owns: con.close()

def _default_workflow():
    return [
        {"id":str(uuid.uuid4()),"step_type":"traffic","name":"Generate controlled traffic","enabled":True,"order":1,"technique_id":None,"configuration":{}},
        {"id":str(uuid.uuid4()),"step_type":"correlation","name":"Correlate service logs","enabled":True,"order":2,"technique_id":None,"configuration":{}},
        {"id":str(uuid.uuid4()),"step_type":"dataset","name":"Build clean dataset","enabled":True,"order":3,"technique_id":None,"configuration":{}},
        {"id":str(uuid.uuid4()),"step_type":"machine_learning","name":"Train and evaluate models","enabled":True,"order":4,"technique_id":None,"configuration":{}},
        {"id":str(uuid.uuid4()),"step_type":"report","name":"Generate experiment report","enabled":True,"order":5,"technique_id":None,"configuration":{}}
    ]

def current_experiment_id():
    with _db_lock, db_conn() as con:
        _ensure_default_experiment(con)
        row=con.execute("SELECT value FROM app_settings WHERE key='current_experiment_id'").fetchone()
        if row and row['value']:
            exists=con.execute("SELECT 1 FROM experiments WHERE id=? AND archived=0",(row['value'],)).fetchone()
            if exists: return row['value']
        row=con.execute("SELECT id FROM experiments WHERE archived=0 ORDER BY updated_at DESC LIMIT 1").fetchone()
        return row['id'] if row else 'legacy-workspace'

def set_current_experiment(eid):
    with _db_lock, db_conn() as con:
        if not con.execute("SELECT 1 FROM experiments WHERE id=? AND archived=0",(eid,)).fetchone():
            raise HTTPException(404,"Experiment not found")
        con.execute("INSERT OR REPLACE INTO app_settings(key,value,updated_at) VALUES('current_experiment_id',?,?)",(eid,now()))
        con.commit()

def record_experiment_activity(activity_type,status,summary,experiment_id=None,metadata=None):
    eid=experiment_id or current_experiment_id()
    with _db_lock, db_conn() as con:
        con.execute("""INSERT INTO experiment_activities(id,experiment_id,activity_type,status,summary,created_at,metadata_json)
                     VALUES(?,?,?,?,?,?,?)""",(str(uuid.uuid4()),eid,activity_type,status,summary,now(),json.dumps(metadata or {},ensure_ascii=False)))
        con.execute("UPDATE experiments SET updated_at=? WHERE id=?",(now(),eid))
        con.commit()

def _experiment_dict(row, con=None):
    d=dict(row)
    try:d['tags']=json.loads(d.pop('tags_json') or '[]')
    except Exception:d['tags']=[]
    try:d['metadata']=json.loads(d.pop('metadata_json') or '{}')
    except Exception:d['metadata']={}
    return d

def _experiment_summary(eid):
    with _db_lock, db_conn() as con:
        row=con.execute("SELECT * FROM experiments WHERE id=?",(eid,)).fetchone()
        if not row: raise HTTPException(404,"Experiment not found")
        exp=_experiment_dict(row)
        campaigns=con.execute("SELECT COUNT(*) c, SUM(CASE WHEN status='finished' THEN 1 ELSE 0 END) done FROM campaign_groups WHERE experiment_id=?",(eid,)).fetchone()
        ml=con.execute("SELECT COUNT(*) c FROM ml_experiments WHERE workspace_experiment_id=?",(eid,)).fetchone()
        reports=0
        activities=con.execute("SELECT * FROM experiment_activities WHERE experiment_id=? ORDER BY created_at DESC LIMIT 25",(eid,)).fetchall()
        wf=con.execute("SELECT steps_json FROM experiment_workflows WHERE experiment_id=?",(eid,)).fetchone()
        try:steps=json.loads(wf['steps_json']) if wf else _default_workflow()
        except Exception:steps=_default_workflow()
        # Filesystem counts are global until the artifact model is introduced.
        datasets=len(list(CLEAN_DIR.glob('clean_*.csv')))
        reports=len(list(ML_REPORTS_DIR.glob('causalis_report_*')))
        exp.update({
            'campaigns_total':int(campaigns['c'] or 0),'campaigns_completed':int(campaigns['done'] or 0),
            'ml_experiments':int(ml['c'] or 0),'datasets_available':datasets,'reports_available':reports,
            'workflow':steps,'activities':[dict(a) for a in activities],
            'readiness':{
                'targets':len(db_targets())>0,'profiles':len(db_profiles())>0,
                'traffic':int(campaigns['done'] or 0)>0,'dataset':datasets>0,
                'machine_learning':int(ml['c'] or 0)>0,'report':reports>0
            }
        })
        completed=sum(1 for v in exp['readiness'].values() if v)
        exp['progress_pct']=round((completed/len(exp['readiness']))*100) if exp['readiness'] else 0
        exp['recommendation']=_experiment_recommendation(exp)
        return exp

def _artifact_inventory():
    groups = {
        "matched_logs": MATCHED_DIR,
        "clean_datasets": CLEAN_DIR,
        "dataset_splits": SPLIT_DIR,
        "ml_datasets": ML_DATASETS_DIR,
        "models": MODELS_DIR,
        "reports": ML_REPORTS_DIR,
        "uploads": UPLOADS,
    }
    inventory=[]
    for category, directory in groups.items():
        if not directory.exists():
            continue
        for p in sorted((x for x in directory.rglob('*') if x.is_file()), key=lambda x:x.stat().st_mtime, reverse=True)[:80]:
            st=p.stat()
            inventory.append({
                "category":category, "name":p.name,
                "relative_path":str(p.relative_to(ROOT)),
                "size_bytes":st.st_size,
                "modified_at":datetime.fromtimestamp(st.st_mtime).astimezone().isoformat(timespec="seconds"),
                "download":f"/api/download/{p.parent.name}/{p.name}" if p.parent.parent==EXP else None
            })
    return sorted(inventory,key=lambda x:x["modified_at"],reverse=True)

def _experiment_recommendation(exp):
    r=exp.get("readiness") or {}
    if not r.get("targets"):
        return {"stage":"environment","title":"Configure the target environment","detail":"Define targets manually or use Guided Discovery.","tab":"trafficTab","action":"Open Experiment Designer"}
    if not r.get("profiles"):
        return {"stage":"profiles","title":"Create traffic profiles","detail":"Define normal and anomaly behaviour for the selected services.","tab":"trafficTab","action":"Configure Profiles"}
    if not r.get("traffic"):
        return {"stage":"traffic","title":"Run a controlled campaign","detail":"Targets and profiles are ready. Assemble and execute a campaign.","tab":"trafficTab","action":"Design Campaign"}
    if not r.get("dataset"):
        return {"stage":"data","title":"Engineer the experiment dataset","detail":"Import service logs, correlate evidence and generate a clean dataset.","tab":"logsTab","action":"Open Data Engineering"}
    if not r.get("machine_learning"):
        return {"stage":"ml","title":"Evaluate machine-learning models","detail":"Clean datasets are available and ready for model training.","tab":"mlTab","action":"Open Machine Learning"}
    if not r.get("report"):
        return {"stage":"report","title":"Generate the experiment report","detail":"The experiment has results and is ready to document.","tab":"resultsTab","action":"Open Analytics"}
    return {"stage":"complete","title":"Experiment workflow completed","detail":"Review analytics, inspect artifacts or clone the experiment for a new variation.","tab":"resultsTab","action":"Review Results"}

def _row_to_dict(row):
    return dict(row) if row else None

def migrate_json_to_db():
    with _db_lock, db_conn() as con:
        if TARGETS.exists():
            for t in load(TARGETS,[]):
                con.execute("""INSERT OR IGNORE INTO targets(id,name,host,port,service,notes,created_at)
                             VALUES(?,?,?,?,?,?,?)""",(t.get('id') or str(uuid.uuid4()),t.get('name',''),t.get('host',''),int(t.get('port') or 80),t.get('service','http'),t.get('notes',''),now()))
        profs = load(PROFILES, []) if PROFILES.exists() else []
        for p in profs:
            con.execute("""INSERT OR IGNORE INTO profiles(name,service,mode,attack_category,port,duration_seconds,rate_per_second,concurrency,path,username,password,dns_query,payload,description,updated_at)
                         VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",(p.get('name',''),p.get('service','http'),p.get('mode','normal'),p.get('attack_category','benign'),int(p.get('port') or 80),int(p.get('duration_seconds') or 30),float(p.get('rate_per_second') or 1),int(p.get('concurrency') or 1),p.get('path','/'),p.get('username',''),p.get('password',''),p.get('dns_query','example.com'),p.get('payload',''),p.get('description',''),now()))
        if os.environ.get("ATG_MIGRATE_OLD_JSON","0")=="1" and CAMPAIGN_HISTORY.exists():
            for h in load(CAMPAIGN_HISTORY,[]):
                gid=h.get('id') or str(uuid.uuid4())
                group_json=json.dumps(h,ensure_ascii=False)
                con.execute("""INSERT OR IGNORE INTO campaign_groups(id,name,status,created_at,started_at,finished_at,scheduled_start,scheduled_start_epoch,execute_now,notes,actions_total,actions_finished,child_campaigns,progress_pct,group_json)
                             VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",(gid,h.get('name',gid),h.get('status','created'),h.get('created_at',now()),h.get('started_at'),h.get('finished_at'),h.get('scheduled_start',''),h.get('scheduled_start_epoch'),1 if h.get('execute_now',True) else 0,h.get('notes',''),int(h.get('actions_total') or 0),int(h.get('actions_finished') or 0),json.dumps(h.get('child_campaigns',[]),ensure_ascii=False),float(h.get('progress_pct') or 0),group_json))
        # Migración inicial de eventos existentes: solo si la tabla está vacía.
        event_count=con.execute("SELECT COUNT(*) AS c FROM events").fetchone()["c"]
        if event_count==0 and EVENTS.exists():
            for line in EVENTS.read_text(encoding="utf-8",errors="ignore").splitlines():
                try:
                    ev=json.loads(line)
                    fields=["timestamp","timestamp_epoch","campaign_id","target_name","host","port","service","mode","label","attack_category_key","capec_id","capec_category","action","status","latency_ms","detail","profile_name","matched","matched_log_line"]
                    vals=[ev.get(k) for k in fields]+[json.dumps(ev,ensure_ascii=False)]
                    con.execute("""INSERT INTO events(timestamp,timestamp_epoch,campaign_id,target_name,host,port,service,mode,label,attack_category_key,capec_id,capec_category,action,status,latency_ms,detail,profile_name,matched,matched_log_line,raw_json)
                                 VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",vals)
                except Exception:
                    pass
        con.commit()

def db_targets():
    with _db_lock, db_conn() as con:
        return [dict(r) for r in con.execute("SELECT id,name,host,port,service,notes FROM targets ORDER BY name").fetchall()]

def db_add_target(t):
    # Validate target fields before persisting user-controlled input.
    d=_validate_target_payload(t if isinstance(t, dict) else t.model_dump())
    with _db_lock, db_conn() as con:
        con.execute("INSERT OR REPLACE INTO targets(id,name,host,port,service,notes,created_at) VALUES(?,?,?,?,?,?,?)",(d['id'],d['name'],d['host'],d['port'],d['service'],d.get('notes',''),now()))
        con.commit()

def db_delete_target(tid):
    with _db_lock, db_conn() as con:
        cur=con.execute("DELETE FROM targets WHERE id=?",(tid,)); con.commit(); return cur.rowcount

def db_profiles():
    with _db_lock, db_conn() as con:
        return [dict(r) for r in con.execute("SELECT name,service,mode,attack_category,port,duration_seconds,rate_per_second,concurrency,path,username,password,dns_query,payload,description FROM profiles ORDER BY name").fetchall()]

def db_add_profile(p):
    # Validate profile fields before persisting user-controlled input.
    d=_validate_profile_payload(p if isinstance(p, dict) else p.model_dump())
    with _db_lock, db_conn() as con:
        con.execute("""INSERT OR REPLACE INTO profiles(name,service,mode,attack_category,port,duration_seconds,rate_per_second,concurrency,path,username,password,dns_query,payload,description,updated_at)
                     VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",(d['name'],d['service'],d['mode'],d.get('attack_category'),d['port'],d['duration_seconds'],d['rate_per_second'],d['concurrency'],d.get('path','/'),d.get('username',''),d.get('password',''),d.get('dns_query','example.com'),d.get('payload',''),d.get('description',''),now()))
        con.commit()

def db_append_event(ev):
    fields=["timestamp","timestamp_epoch","campaign_id","target_name","host","port","service","mode","label","attack_category_key","capec_id","capec_category","action","status","latency_ms","detail","profile_name","matched","matched_log_line"]
    vals=[ev.get(k) for k in fields]
    vals.append(json.dumps(ev,ensure_ascii=False))
    with _db_lock, db_conn() as con:
        con.execute("""INSERT INTO events(timestamp,timestamp_epoch,campaign_id,target_name,host,port,service,mode,label,attack_category_key,capec_id,capec_category,action,status,latency_ms,detail,profile_name,matched,matched_log_line,raw_json)
                     VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""", vals)
        con.commit()

def db_all_events(limit=None):
    sql="SELECT raw_json FROM events ORDER BY id" + (" LIMIT ?" if limit else "")
    args=(limit,) if limit else ()
    with _db_lock, db_conn() as con:
        rows=con.execute(sql,args).fetchall()
    out=[]
    for r in rows:
        try: out.append(json.loads(r['raw_json']))
        except Exception: pass
    if out:
        return out
    return []

def campaign_history():
    with _db_lock, db_conn() as con:
        rows=con.execute("SELECT * FROM campaign_groups ORDER BY created_at ASC LIMIT 500").fetchall()
    out=[]
    for r in rows:
        d=dict(r)
        try:
            raw=json.loads(d.get('group_json') or '{}')
        except Exception:
            raw={}
        raw.update({
            'id':d['id'],'name':d['name'],'status':d['status'],'created_at':d['created_at'],
            'started_at':d.get('started_at'),'finished_at':d.get('finished_at'),'scheduled_start':d.get('scheduled_start') or '',
            'execute_now':bool(d.get('execute_now')),'notes':d.get('notes') or '',
            'actions_total':d.get('actions_total') or 0,'actions_finished':d.get('actions_finished') or 0,
            'child_campaigns':json.loads(d.get('child_campaigns') or '[]'),'progress_pct':d.get('progress_pct') or 0,'experiment_id':d.get('experiment_id')
        })
        out.append(raw)
    return out

def save_campaign_history(items):
    for item in items[-500:]:
        history_upsert(item)

def history_upsert(item):
    gid=item.get('id') or str(uuid.uuid4())
    item['id']=gid
    with _db_lock, db_conn() as con:
        con.execute("""INSERT OR REPLACE INTO campaign_groups(id,name,status,created_at,started_at,finished_at,scheduled_start,scheduled_start_epoch,execute_now,notes,actions_total,actions_finished,child_campaigns,progress_pct,group_json,experiment_id)
                     VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",(
            gid,item.get('name',gid),item.get('status','created'),item.get('created_at') or now(),item.get('started_at'),item.get('finished_at'),item.get('scheduled_start',''),item.get('scheduled_start_epoch'),1 if item.get('execute_now',True) else 0,item.get('notes',''),int(item.get('actions_total') or 0),int(item.get('actions_finished') or 0),json.dumps(item.get('child_campaigns',[]),ensure_ascii=False),float(item.get('progress_pct') or 0),json.dumps(item,ensure_ascii=False),item.get('experiment_id') or current_experiment_id()))
        con.commit()

def _parse_local_datetime(value:str):
    """Parsea valores procedentes de controles HTML date/time/datetime-local como hora local del servidor.
    No devuelve nunca una fecha con zona horaria mezclada para evitar errores de comparación.
    """
    if not value:
        return None
    v=str(value).strip()
    try:
        # datetime-local suele llegar como YYYY-MM-DDTHH:MM o YYYY-MM-DDTHH:MM:SS
        return datetime.fromisoformat(v).replace(tzinfo=None)
    except Exception:
        pass
    for fmt in ("%Y-%m-%dT%H:%M", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d %H:%M:%S", "%d/%m/%Y %H:%M"):
        try:
            return datetime.strptime(v, fmt)
        except Exception:
            continue
    return None
def _coerce_epoch(value):
    if value is None or value == "":
        return None
    try:
        return float(value)
    except Exception:
        return None

def _schedule_epoch_from_payload(payload):
    """Fuente única de verdad para planificación.
    La UI envía scheduled_start_epoch calculado por el navegador en epoch Unix.
    Eso evita mezclar UTC/localtime y evita comparar strings de fecha.
    Solo si falta ese valor, se usa scheduled_start como compatibilidad.
    """
    if hasattr(payload, 'scheduled_start_epoch'):
        ep=_coerce_epoch(getattr(payload,'scheduled_start_epoch'))
        if ep is not None:
            return ep
    if isinstance(payload, dict):
        ep=_coerce_epoch(payload.get('scheduled_start_epoch'))
        if ep is not None:
            return ep
        txt=payload.get('scheduled_start')
    else:
        txt=getattr(payload,'scheduled_start','')
    dt=_parse_local_datetime(txt)
    return dt.timestamp() if dt else None

def _schedule_delay_from_payload(payload):
    ep=_schedule_epoch_from_payload(payload)
    if ep is None:
        return 0
    return max(0, ep-time.time())

def _schedule_display_from_epoch(ep):
    ep=_coerce_epoch(ep)
    if ep is None:
        return ""
    return datetime.fromtimestamp(ep).isoformat(timespec="minutes")

def db_due_campaign_groups():
    # Se compara por epoch Unix, no por texto ni por datetime naive/aware.
    current=time.time()
    with _db_lock, db_conn() as con:
        rows=con.execute("SELECT id,scheduled_start,scheduled_start_epoch,group_json FROM campaign_groups WHERE status='scheduled' ORDER BY created_at").fetchall()
    groups=[]
    for r in rows:
        due_epoch=_coerce_epoch(r['scheduled_start_epoch'])
        if due_epoch is None:
            try:
                raw=json.loads(r['group_json'] or '{}')
            except Exception:
                raw={}
            due_epoch=_schedule_epoch_from_payload(raw)
        if due_epoch is None:
            print(f"CAUSALIS scheduler: invalid scheduled date for campaign {r['id']}: {r['scheduled_start']}", flush=True)
            continue
        if due_epoch<=current:
            try: groups.append(json.loads(r['group_json']))
            except Exception as e: print('CAUSALIS scheduler: could not read scheduled campaign', r['id'], repr(e), flush=True)
    return groups

def category(req):
    if req.mode=="normal": return "benign"
    k=(req.attack_category or "abuse_of_functionality").strip().lower().replace(" ","_").replace("-","_")
    return k if k in CAPEC else "abuse_of_functionality"
def enrich(ev,req):
    k=category(req); ev["attack_category_key"]=k; ev.update(CAPEC[k]); ev["label"]="benign" if k=="benign" else "anomaly"; return ev
def append(ev):
    ev.setdefault("timestamp",now()); ev.setdefault("timestamp_epoch",epoch())
    db_append_event(ev)
    # Compatibilidad de exportación/diagnóstico: se mantiene el JSONL como copia de seguridad,
    # pero la persistencia estructurada principal es SQLite en data/atg.db.
    with EVENTS.open("a",encoding="utf-8") as f: f.write(json.dumps(ev,ensure_ascii=False)+"\n")
def all_events():
    rows=db_all_events()
    if rows: return rows
    if not EVENTS.exists(): return []
    out=[]
    for l in EVENTS.read_text(encoding="utf-8",errors="ignore").splitlines():
        try: out.append(json.loads(l))
        except: pass
    return out
def parse_schedule_delay(iso_text:str):
    # Compatibilidad antigua. Para nuevas programaciones se usa scheduled_start_epoch.
    dt=_parse_local_datetime(iso_text)
    if not dt:
        return 0
    return max(0, dt.timestamp()-time.time())
def profiles_default():
    return [
    {"name":"http_normal_80","service":"http","mode":"normal","attack_category":"benign","port":80,"duration_seconds":60,"rate_per_second":1,"concurrency":1,"path":"/","description":"Web normal"},
    {"name":"http_anomaly_auth_81","service":"http","mode":"anomaly","attack_category":"subverting_authentication","port":81,"duration_seconds":60,"rate_per_second":1,"concurrency":1,"path":"/login","description":"Web authentication anomaly"},
    {"name":"http_injection_81","service":"http","mode":"anomaly","attack_category":"injection","port":81,"duration_seconds":60,"rate_per_second":1,"concurrency":1,"path":"/search","description":"Injection probes"},
    {"name":"ftp_normal","service":"ftp","mode":"normal","attack_category":"benign","port":21,"duration_seconds":60,"rate_per_second":0.5,"concurrency":1,"username":"anonymous","password":"anonymous@","description":"FTP normal"},
    {"name":"ssh_bruteforce","service":"ssh","mode":"anomaly","attack_category":"probabilistic_techniques","port":22,"duration_seconds":60,"rate_per_second":0.5,"concurrency":1,"username":"root","password":"password","description":"Probabilistic SSH"},
    {"name":"dns_leakage","service":"dns","mode":"anomaly","attack_category":"data_leakage","port":53,"duration_seconds":60,"rate_per_second":1,"concurrency":1,"dns_query":"example.com","description":"DNS data leakage"}]
def get_profiles():
    return db_profiles()

HTTP_NORMAL=["/","/index.html","/login","/about","/favicon.ico"]
HTTP_ANOM={
"abuse_of_functionality":["/admin","/phpmyadmin/","/server-status","/backup.zip"],
"subverting_authentication":["/login","/wp-login.php","/administrator","/login?user=admin"],
"probabilistic_techniques":["/login?user=admin","/login?user=root","/wp-login.php"],
"injection":["/login?id=1%27","/search?q=%27%20OR%20%271%27=%271"],
"data_leakage":["/.env","/config.php.bak","/../../etc/passwd"],
"resource_depletion":["/","/index.html","/search?q="+"A"*100],
"time_and_state":["/checkout/confirm","/transfer/confirm"],
"spoofing":["/admin","/login"]}

def raw_http(req):
    k=category(req)
    path=req.path if req.mode=="normal" and req.path!="/" else random.choice(HTTP_NORMAL if req.mode=="normal" else HTTP_ANOM.get(k,HTTP_ANOM["abuse_of_functionality"]))
    method="GET" if req.mode=="normal" else random.choice(["GET","GET","HEAD","POST"])
    body="username=admin&password=password" if method=="POST" else ""
    extra=f"Content-Length: {len(body)}\r\nContent-Type: application/x-www-form-urlencoded\r\n" if body else ""
    xff=f"X-Forwarded-For: 10.0.{random.randint(0,255)}.{random.randint(1,254)}\r\n" if k=="spoofing" else ""
    payload=(f"{method} {path} HTTP/1.1\r\nHost: {req.host}:{req.port}\r\nUser-Agent: CAUSALIS-v0.6.0\r\nX-CAUSALIS-Category: {k}\r\n{xff}{extra}Connection: close\r\n\r\n{body}").encode()
    t=time.time()
    with socket.create_connection((req.host,req.port),timeout=5) as s:
        s.sendall(payload)
        try: data=s.recv(256)
        except: data=b""
    first=data.splitlines()[0].decode(errors="ignore") if data else "no-response"
    return {"action":f"HTTP {method} {path}","status":"sent","latency_ms":round((time.time()-t)*1000,2),"detail":f"{first}; recv={len(data)}"}

def tcp_probe(req,label):
    t=time.time()
    with socket.create_connection((req.host,req.port),timeout=5) as s:
        if req.mode=="anomaly":
            try: s.sendall((req.payload or f"ATG {label} probe").encode())
            except: pass
        try: data=s.recv(128)
        except: data=b""
    return {"action":f"{label} TCP probe","status":"connected","latency_ms":round((time.time()-t)*1000,2),"detail":f"recv={len(data)}"}

def _is_normal_port(service:str, port:int)->bool:
    return HONEynet_TRAFFIC_KIND_BY_PORT.get(int(port), 'unknown') == 'normal'


def run_imap(req):
    """Generate real IMAP interactions using the standard library.

    Normal profiles authenticate, list mailboxes and select INBOX. Anomalous
    profiles generate controlled failed authentication or aggressive mailbox
    enumeration patterns while preserving the configured CAPEC ground truth.
    """
    t=time.time(); ssl_port=int(req.port) in (993,1993)
    client=(imaplib.IMAP4_SSL(req.host,req.port,timeout=5) if ssl_port else imaplib.IMAP4(req.host,req.port,timeout=5))
    try:
        if req.mode=='normal':
            domain='normalidad.tics' if _is_normal_port('imap',req.port) else 'pentesting.tics'
            user=req.username or f'usuario1@{domain}'; pwd=req.password or 'password'
            client.login(user,pwd); typ,boxes=client.list(); client.select('INBOX',readonly=True)
            return {'action':f'IMAP login/list {user}','status':'ok','latency_ms':round((time.time()-t)*1000,2),'detail':f'mailboxes={len(boxes or [])}'}
        user=req.username or random.choice(['admin','root','usuario1'])
        pwd=req.password or random.choice(['password1','123456','invalid'])
        try:
            client.login(user,pwd)
            typ,boxes=client.list()
            return {'action':f'IMAP anomalous enumeration {user}','status':str(typ),'latency_ms':round((time.time()-t)*1000,2),'detail':f'mailboxes={len(boxes or [])}'}
        except Exception as exc:
            return {'action':f'IMAP failed authentication {user}','status':'rejected','latency_ms':round((time.time()-t)*1000,2),'detail':repr(exc)}
    finally:
        try: client.logout()
        except Exception: pass


def run_postgresql(req):
    """Generate safe PostgreSQL traffic with explicit normal/anomaly behavior."""
    if psycopg2 is None: raise RuntimeError('psycopg2-binary is not installed')
    t=time.time(); cat=category(req)
    user=req.username or 'myuser'; pwd=req.password or 'mypassword'; db='mydatabase'
    if req.mode=='anomaly' and cat in ('subverting_authentication','probabilistic_techniques'):
        pwd=req.password or random.choice(['password','admin','invalid'])
    conn=psycopg2.connect(host=req.host,port=req.port,user=user,password=pwd,dbname=db,connect_timeout=5)
    try:
        conn.autocommit=True
        with conn.cursor() as cur:
            if req.mode=='normal':
                cur.execute('SELECT 1 AS causalis_healthcheck'); rows=cur.fetchall(); action='PostgreSQL SELECT 1'
            elif cat=='injection':
                cur.execute("SELECT 1 WHERE '1'='1' /* CAUSALIS controlled injection pattern */"); rows=cur.fetchall(); action='PostgreSQL injection-pattern query'
            elif cat=='data_leakage':
                cur.execute("SELECT table_name FROM information_schema.tables WHERE table_schema='public' LIMIT 10"); rows=cur.fetchall(); action='PostgreSQL metadata enumeration'
            else:
                cur.execute('SELECT current_user, current_database()'); rows=cur.fetchall(); action='PostgreSQL anomalous session probe'
        return {'action':action,'status':'ok','latency_ms':round((time.time()-t)*1000,2),'detail':f'rows={len(rows)}'}
    finally: conn.close()


def run_smb(req):
    """Generate SMB authentication and share-enumeration traffic via pysmb."""
    if SMBConnection is None: raise RuntimeError('pysmb is not installed')
    t=time.time(); normal=req.mode=='normal'
    user=req.username or ('user' if normal else random.choice(['administrator','admin','guest']))
    pwd=req.password or ('password' if normal else random.choice(['Password1','123456','invalid']))
    conn=SMBConnection(user,pwd,'causalis-client','causalis-server',use_ntlm_v2=True,is_direct_tcp=True)
    ok=conn.connect(req.host,req.port,timeout=5)
    if not ok:
        return {'action':f'SMB authentication {user}','status':'rejected','latency_ms':round((time.time()-t)*1000,2),'detail':'authentication failed'}
    try:
        shares=conn.listShares(timeout=5)
        share_names=[getattr(x,'name','') for x in shares if getattr(x,'name','') and not getattr(x,'isSpecial',False)]
        operations=['authenticate','list_shares']
        detail_parts=[f"shares={len(shares)}"]
        # Exercise a real share when available so Samba audit logging records more than authentication.
        if share_names:
            share=share_names[0]
            try:
                entries=conn.listPath(share,'/',timeout=5)
                operations.append('list_directory'); detail_parts.append(f"entries={len(entries)}")
                candidates=[getattr(e,'filename','') for e in entries if getattr(e,'filename','') not in ('','.','..') and not getattr(e,'isDirectory',False)]
                if normal and candidates:
                    buf=io.BytesIO(); conn.retrieveFile(share,candidates[0],buf,timeout=5)
                    operations.append('read_file'); detail_parts.append(f"read_bytes={len(buf.getvalue())}")
                if normal:
                    payload=(f"CAUSALIS controlled SMB write {now()}\n").encode('utf-8')
                    conn.storeFile(share,'causalis_probe.txt',io.BytesIO(payload),timeout=5)
                    operations.append('write_file'); detail_parts.append(f"write_bytes={len(payload)}")
            except Exception as op_exc:
                detail_parts.append('share_operation='+repr(op_exc))
        return {'action':('SMB '+','.join(operations) if normal else 'SMB anomalous share enumeration'),'status':'ok','latency_ms':round((time.time()-t)*1000,2),'detail':'; '.join(detail_parts)}
    finally:
        try: conn.close()
        except Exception: pass


def run_rest_api(req):
    """Generate real HTTP API traffic against arbitrary REST services."""
    t=time.time(); base=f'http://{req.host}:{req.port}'; cat=category(req)
    if req.mode=='normal':
        path=req.path if req.path and req.path!='/' else random.choice(['/','/users/?limit=5','/projects/?limit=5','/tasks/?limit=5','/docs'])
        r=requests.get(base+path,timeout=5)
        return {'action':f'REST GET {path}','status':str(r.status_code),'latency_ms':round((time.time()-t)*1000,2),'detail':f'{len(r.content)} bytes'}
    if cat=='subverting_authentication':
        r=requests.post(base+'/token',data={'username':'admin','password':'invalid'},timeout=5)
        action='REST invalid authentication'
    elif cat=='injection':
        path="/users/?username=' OR '1'='1&limit=100"; r=requests.get(base+path,timeout=5); action='REST injection-pattern query'
    elif cat=='data_leakage':
        path='/users/?limit=100'; r=requests.get(base+path,timeout=5); action='REST broad resource enumeration'
    elif cat=='resource_depletion':
        path='/tasks/?limit=100'; r=requests.get(base+path,timeout=5); action='REST high-volume query'
    else:
        path='/projects/999999'; r=requests.get(base+path,timeout=5); action='REST anomalous endpoint access'
    return {'action':action,'status':str(r.status_code),'latency_ms':round((time.time()-t)*1000,2),'detail':f'{len(r.content)} bytes'}


def run_wireguard_ui(req):
    """Exercise the WireGuard management web surface without touching UDP tunnels."""
    t=time.time(); base=f'http://{req.host}:{req.port}'
    if req.mode=='normal':
        r=requests.get(base+'/',timeout=5); action='WireGuard UI landing page'
    else:
        cat=category(req)
        if cat=='subverting_authentication':
            r=requests.post(base+'/api/session',json={'password':'invalid'},timeout=5); action='WireGuard UI invalid authentication'
        elif cat=='resource_depletion':
            r=requests.get(base+'/?refresh=1',timeout=5); action='WireGuard UI repeated status request'
        else:
            r=requests.get(base+'/api/wireguard/client',timeout=5); action='WireGuard UI protected endpoint probe'
    return {'action':action,'status':str(r.status_code),'latency_ms':round((time.time()-t)*1000,2),'detail':f'{len(r.content)} bytes'}

def run_once(req):
    t=time.time()
    try:
        if req.service=="http": return raw_http(req)
        if req.service=="https":
            r=requests.get(f"https://{req.host}:{req.port}{req.path or '/'}",timeout=5,verify=False)
            return {"action":"HTTPS GET","status":str(r.status_code),"latency_ms":round((time.time()-t)*1000,2),"detail":f"{len(r.content)} bytes"}
        if req.service=="ftp":
            user=req.username or ("anonymous" if req.mode=="normal" else random.choice(["admin","root","backup"]))
            pwd=req.password or ("anonymous@" if req.mode=="normal" else random.choice(["password","123456","admin"]))
            ftp=ftplib.FTP(); ftp.connect(req.host,req.port,timeout=5); ftp.login(user,pwd); files=ftp.nlst(); ftp.quit()
            return {"action":f"FTP login/list {user}","status":"ok","latency_ms":round((time.time()-t)*1000,2),"detail":f"{len(files)} entries"}
        if req.service=="ssh":
            if paramiko is None:
                raise RuntimeError("paramiko is not installed")
            user=req.username or ("kali" if req.mode=="normal" else random.choice(["root","admin","test"]))
            pwd=req.password or ("kali" if req.mode=="normal" else random.choice(["password","123456","toor"]))
            c=paramiko.SSHClient(); c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            c.connect(req.host,port=req.port,username=user,password=pwd,timeout=5,banner_timeout=5,auth_timeout=5,look_for_keys=False,allow_agent=False); c.close()
            return {"action":f"SSH login {user}","status":"ok","latency_ms":round((time.time()-t)*1000,2),"detail":"authenticated"}
        if req.service=="dns":
            if dns is None:
                raise RuntimeError("dnspython is not installed")
            q=req.dns_query or "example.com"
            if req.mode=="anomaly" and category(req)=="data_leakage": q="exfil-"+"x"*random.randint(20,60)+".lab.example"
            r=dns.resolver.Resolver(); r.nameservers=[req.host]; r.port=req.port; r.lifetime=4; ans=r.resolve(q,"A")
            return {"action":f"DNS A {q}","status":"answered","latency_ms":round((time.time()-t)*1000,2),"detail":",".join(a.to_text() for a in ans)}
        if req.service=="smtp":
            domain='normalidad.tics' if _is_normal_port('smtp',req.port) else 'pentesting.tics'
            sender=f'usuario1@{domain}'; recipient=f'usuario2@{domain}'
            subject='CAUSALIS normal message' if req.mode=='normal' else f'CAUSALIS controlled {category(req)} event'
            msg=f"From: {sender}\r\nTo: {recipient}\r\nSubject: {subject}\r\nX-CAUSALIS-Category: {category(req)}\r\n\r\ncontrolled laboratory message\r\n"
            with smtplib.SMTP(req.host,req.port,timeout=5) as smtp:
                if req.username:
                    try: smtp.login(req.username,req.password or 'password')
                    except Exception:
                        if req.mode=='normal': raise
                smtp.sendmail(sender,[recipient],msg)
            return {"action":"SMTP sendmail","status":"ok","latency_ms":round((time.time()-t)*1000,2),"detail":f"{len(msg)} bytes"}
        if req.service=="imap": return run_imap(req)
        if req.service=="postgresql": return run_postgresql(req)
        if req.service=="smb": return run_smb(req)
        if req.service=="rest_api": return run_rest_api(req)
        if req.service=="wireguard_ui": return run_wireguard_ui(req)
        return tcp_probe(req,req.service.upper())
    except Exception as e:
        return {"action":f"{req.service.upper()} attempt","status":"error","latency_ms":round((time.time()-t)*1000,2),"detail":repr(e)}

campaigns={}; stops={}
def base_event(cid,req):
    return enrich({"campaign_id":cid,"target_name":req.target_name,"host":req.host,"port":req.port,"service":req.service,"mode":req.mode,"profile_name":req.profile_name},req)
def worker(cid,req):
    ev=base_event(cid,req); ev.update(run_once(req)); append(ev); campaigns[cid]["events"]+=1
def loop(cid,req):
    d=_schedule_delay_from_payload(req)
    if d>0:
        campaigns[cid]["status"]="scheduled"
        campaigns[cid]["scheduled_start_epoch"]=_schedule_epoch_from_payload(req)
        time.sleep(d)
    campaigns[cid]["status"]="running"; start=time.time(); interval=1/max(req.rate_per_second,0.01)
    append({**base_event(cid,req),"action":"campaign_start","status":"running","latency_ms":0,"detail":""})
    while not stops[cid].is_set() and time.time()-start<req.duration_seconds:
        campaigns[cid]["progress_pct"]=min(100,round(((time.time()-start)/max(req.duration_seconds,1))*100,1))
        th=[threading.Thread(target=worker,args=(cid,req),daemon=True) for _ in range(req.concurrency)]
        [x.start() for x in th]; [x.join(10) for x in th]
        time.sleep(max(.05,interval))
    campaigns[cid]["status"]="finished"; campaigns[cid]["finished_at"]=now(); campaigns[cid]["progress_pct"]=100
    append({**base_event(cid,req),"action":"campaign_end","status":"finished","latency_ms":0,"detail":f"events={campaigns[cid]['events']}"})

def group_worker(group_id:str, group:CampaignGroup):
    existing=[h for h in campaign_history() if h.get("id")==group_id]
    hist=existing[0] if existing else {"id":group_id,"name":group.name,"status":"scheduled" if (not group.execute_now and group.scheduled_start) else "running","created_at":now(),"started_at":None,"finished_at":None,"scheduled_start":group.scheduled_start,"scheduled_start_epoch":_schedule_epoch_from_payload(group),"execute_now":group.execute_now,"notes":group.notes,"actions_total":len(group.actions),"actions_finished":0,"child_campaigns":[],"progress_pct":0,"group_payload":group.model_dump()}
    hist.update({"name":group.name,"scheduled_start":group.scheduled_start,"scheduled_start_epoch":_schedule_epoch_from_payload(group),"execute_now":group.execute_now,"notes":group.notes,"actions_total":len(group.actions),"group_payload":group.model_dump()})
    history_upsert(hist)
    d=0 if group.execute_now else _schedule_delay_from_payload(group)
    if d>0:
        time.sleep(d)
    hist["status"]="running"; hist["started_at"]=now(); history_upsert(hist)
    for idx,a in enumerate(group.actions):
        req=Campaign(**a.model_dump(), scheduled_start="")
        cid=f"{group_id[:8]}-{idx+1}"
        campaigns[cid]={"id":cid,"group_id":group_id,"group_name":group.name,"status":"created","started_at":now(),"started_epoch":epoch(),"finished_at":None,"request":req.model_dump(),"events":0,"duration_seconds":req.duration_seconds,"progress_pct":0}
        stops[cid]=threading.Event()
        hist["child_campaigns"].append(cid); history_upsert(hist)
        loop(cid,req)
        hist["actions_finished"]=idx+1
        hist["progress_pct"]=round((hist["actions_finished"]/max(hist["actions_total"],1))*100,1)
        history_upsert(hist)
    hist["status"]="finished"; hist["finished_at"]=now(); hist["progress_pct"]=100; history_upsert(hist)
    record_experiment_activity("campaign","completed",f"Campaign {group.name} completed",hist.get("experiment_id"),{"campaign_group_id":group_id,"actions":len(group.actions)})


def scheduler_loop():
    print('CAUSALIS scheduler: started', flush=True)
    while True:
        try:
            for h in db_due_campaign_groups():
                gid=h.get('id')
                payload=h.get('group_payload') or h
                try:
                    g=CampaignGroup(**payload)
                except Exception as e:
                    print('CAUSALIS scheduler: invalid payload', gid, repr(e), flush=True)
                    h['status']='error'; h['notes']=(h.get('notes','')+' | scheduler error: invalid payload').strip(); history_upsert(h)
                    continue
                # Cambio atómico de scheduled -> starting para evitar dobles lanzamientos si el polling coincide.
                with _db_lock, db_conn() as con:
                    cur=con.execute("UPDATE campaign_groups SET status='starting', group_json=? WHERE id=? AND status='scheduled'", (json.dumps({**h,'status':'starting'},ensure_ascii=False), gid))
                    con.commit()
                    if cur.rowcount!=1:
                        continue
                print(f'CAUSALIS scheduler: launching scheduled campaign {gid} ({g.name})', flush=True)
                g.execute_now=True
                threading.Thread(target=group_worker,args=(gid,g),daemon=True).start()
        except Exception as e:
            print('CAUSALIS scheduler error:',repr(e),flush=True)
        time.sleep(2)

def ensure_scheduler_started():
    global _scheduler_started
    if not _scheduler_started:
        _scheduler_started=True
        threading.Thread(target=scheduler_loop,daemon=True).start()


def export_file(service="all",kind="all",fmt="csv"):
    rows=all_events()
    if service!="all": rows=[r for r in rows if r.get("service")==service]
    if kind=="normal": rows=[r for r in rows if r.get("label")=="benign"]
    if kind=="anomaly": rows=[r for r in rows if r.get("label")=="anomaly"]
    out=EXP/f"dataset_{service}_{kind}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.{fmt if fmt!='parquet' else 'csv'}"
    fields=["timestamp","timestamp_epoch","campaign_id","target_name","host","port","service","mode","label","attack_category_key","capec_id","capec_category","action","status","latency_ms","detail","profile_name","matched","matched_log_line"]
    if fmt=="jsonl":
        out=out.with_suffix(".jsonl"); out.write_text("\n".join(json.dumps(r,ensure_ascii=False) for r in rows),encoding="utf-8")
    else:
        with out.open("w",newline="",encoding="utf-8") as f:
            w=csv.DictWriter(f,fieldnames=fields); w.writeheader()
            for r in rows: w.writerow({k:r.get(k,"") for k in fields})
    return out

def metrics():
    rows=all_events(); bs={}; bl={}; bc={}
    for r in rows:
        bs[r.get("service","?")]=bs.get(r.get("service","?"),0)+1
        bl[r.get("label","?")]=bl.get(r.get("label","?"),0)+1
        bc[r.get("capec_category","?")]=bc.get(r.get("capec_category","?"),0)+1
    return {"total_events":len(rows),"by_service":bs,"by_label":bl,"by_capec":bc,"last_events":rows[-10:]}

def log_time(line):
    """Extract a timestamp from common service log formats.

    This parser is intentionally tolerant because the honeynet generates logs
    from different services and containers. It supports Apache/Nginx style
    timestamps, ISO-8601 timestamps, syslog-like timestamps and simple epoch
    values. Returning None is valid when a line has no timestamp.
    """
    line=str(line or "")
    # Apache/Nginx: [02/Jun/2026:13:03:01 +0200]
    m=re.search(r"\[(\d{1,2}/[A-Za-z]{3}/\d{4}:\d{2}:\d{2}:\d{2}) ([+-]\d{4})\]", line)
    if m:
        try:
            return datetime.strptime(m.group(1)+" "+m.group(2), "%d/%b/%Y:%H:%M:%S %z").timestamp()
        except Exception:
            pass
    # ISO-8601: 2026-06-02T13:03:01Z or 2026-06-02 13:03:01+02:00
    m=re.search(r"(\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:?\d{2})?)", line)
    if m:
        raw=m.group(1).replace('Z','+00:00')
        try:
            return datetime.fromisoformat(raw).timestamp()
        except Exception:
            pass
    # Syslog: Jun  2 13:03:01 ... (year is not present, use current year)
    m=re.search(r"\b([A-Z][a-z]{2}\s+\d{1,2}\s+\d{2}:\d{2}:\d{2})\b", line)
    if m:
        try:
            dt=datetime.strptime(f"{datetime.now().year} {m.group(1)}", "%Y %b %d %H:%M:%S")
            return dt.timestamp()
        except Exception:
            pass
    # Epoch seconds or milliseconds. Avoid matching ports or IDs by requiring 10+ digits.
    m=re.search(r"\b(\d{10})(?:\.\d+)?\b", line)
    if m:
        try:
            return float(m.group(0))
        except Exception:
            pass
    m=re.search(r"\b(\d{13})\b", line)
    if m:
        try:
            return float(m.group(1))/1000.0
        except Exception:
            pass
    return None


def _system_time_status():
    """Return host time diagnostics for the UI without changing scheduler behavior."""
    local_now=datetime.now().astimezone()
    utc_now=datetime.utcnow().replace(microsecond=0).isoformat()+"Z"
    tz=str(local_now.astimezone().tzinfo)
    ntp="unknown"
    timezone_name=os.environ.get('TZ','')
    try:
        import subprocess
        out=subprocess.run(['timedatectl'],capture_output=True,text=True,timeout=2).stdout
        for line in out.splitlines():
            if 'Time zone:' in line:
                timezone_name=line.split('Time zone:',1)[1].strip()
            if 'NTP service:' in line:
                ntp=line.split('NTP service:',1)[1].strip()
            if 'System clock synchronized:' in line and ntp=='unknown':
                ntp=line.split(':',1)[1].strip()
    except Exception:
        pass
    return {"local_time":local_now.isoformat(timespec='seconds'),"utc_time":utc_now,"timezone":timezone_name or tz,"ntp":ntp}

init_db()
ensure_scheduler_started()
app=FastAPI(title=PRODUCT_NAME, description=PRODUCT_DESCRIPTOR, version=PRODUCT_VERSION)
@app.on_event("startup")
def _startup():
    ensure_scheduler_started()
app.mount("/static",StaticFiles(directory=str(APP/"static")),name="static")
@app.get("/",response_class=HTMLResponse)
def index(): return (APP/"templates"/"index.html").read_text(encoding="utf-8")



@app.get("/api/studio/home")
def studio_home():
    """Read-only product dashboard summary for CAUSALIS.

    This endpoint intentionally consumes the existing ATG 1.0.0 SQLite schema
    and does not modify the validated execution, processing or ML workflows.
    """
    def _count(con, table):
        try:
            return int(con.execute(f"SELECT COUNT(*) AS c FROM {table}").fetchone()["c"] or 0)
        except Exception:
            return 0
    with _db_lock, db_conn() as con:
        targets=_count(con,"targets")
        profiles=_count(con,"profiles")
        events=_count(con,"events")
        campaigns=_count(con,"campaign_groups")
        ml_exps=_count(con,"ml_experiments")
        running=[dict(r) for r in con.execute("SELECT id,name,status,progress_pct,actions_total,actions_finished,started_at FROM campaign_groups WHERE status='running' ORDER BY started_at DESC LIMIT 5").fetchall()]
        recent_campaigns=[dict(r) for r in con.execute("SELECT id,name,status,created_at,started_at,finished_at,progress_pct FROM campaign_groups ORDER BY created_at DESC LIMIT 6").fetchall()]
        recent_ml=[dict(r) for r in con.execute("SELECT id,name,created_at,target_column,rows_total,best_model,best_service_summary FROM ml_experiments ORDER BY created_at DESC LIMIT 8").fetchall()]
        best_models=[dict(r) for r in con.execute("""
            SELECT r.experiment_id,e.name AS experiment_name,r.service,r.model_name,r.accuracy,r.f1_macro,r.mcc,r.roc_auc,r.created_at
            FROM ml_results r JOIN ml_experiments e ON e.id=r.experiment_id
            WHERE r.mcc IS NOT NULL
            ORDER BY r.mcc DESC, r.f1_macro DESC LIMIT 5
        """).fetchall()]
        service_rows=[dict(r) for r in con.execute("SELECT service,COUNT(*) AS count FROM events GROUP BY service ORDER BY count DESC LIMIT 12").fetchall()]
        mode_rows=[dict(r) for r in con.execute("SELECT mode,COUNT(*) AS count FROM events GROUP BY mode ORDER BY count DESC").fetchall()]
    artifact_counts={
        "matched_logs": len(list(MATCHED_DIR.glob("*.csv"))),
        "clean_datasets": len(list(CLEAN_DIR.glob("*.csv"))),
        "dataset_splits": len(list(SPLIT_DIR.glob("*"))),
        "ml_datasets": len(list(ML_DATASETS_DIR.glob("*.csv"))),
        "ml_reports": len(list(ML_REPORTS_DIR.glob("*.html"))) + len(list(ML_REPORTS_DIR.glob("*.pdf"))),
        "models": len(list(MODELS_DIR.glob("*"))),
    }
    activities=[]
    for c in recent_campaigns:
        ts=c.get("finished_at") or c.get("started_at") or c.get("created_at") or ""
        activities.append({"type":"campaign","title":c.get("name") or c.get("id"),"status":c.get("status") or "unknown","timestamp":ts,"detail":f"Traffic campaign · {c.get('progress_pct') or 0}%"})
    for m in recent_ml:
        activities.append({"type":"ml","title":m.get("name") or m.get("id"),"status":"completed","timestamp":m.get("created_at") or "","detail":f"ML experiment · best model: {m.get('best_model') or 'n/a'}"})
    for rp in sorted(list(ML_REPORTS_DIR.glob("causalis_report_*")), key=lambda x:x.stat().st_mtime, reverse=True)[:6]:
        ts=datetime.fromtimestamp(rp.stat().st_mtime).astimezone().isoformat(timespec="seconds")
        activities.append({"type":"report","title":rp.name,"status":"generated","timestamp":ts,"detail":f"{rp.suffix[1:].upper()} report generated"})
    activities=sorted(activities,key=lambda x:x.get("timestamp") or "",reverse=True)[:12]
    return {
        "product":{"name":PRODUCT_NAME,"descriptor":PRODUCT_DESCRIPTOR,"tagline":PRODUCT_TAGLINE,"baseline":BASELINE_NAME,"version":PRODUCT_VERSION},
        "counts":{"targets":targets,"profiles":profiles,"events":events,"campaigns":campaigns,"ml_experiments":ml_exps},
        "artifacts":artifact_counts,
        "running_campaigns":running,
        "recent_campaigns":recent_campaigns,
        "recent_ml_experiments":recent_ml,
        "recent_activity":activities,
        "best_models":best_models,
        "events_by_service":service_rows,
        "events_by_mode":mode_rows,
    }

@app.get("/api/studio/ml-dashboard")
def studio_ml_dashboard(limit:int=25):
    """Read-only ML dashboard data backed by existing ml_experiments/ml_results tables."""
    limit=max(1,min(int(limit or 25),100))
    with _db_lock, db_conn() as con:
        experiments=[dict(r) for r in con.execute("SELECT id,name,created_at,target_column,rows_total,columns_total,best_model,best_service_summary FROM ml_experiments ORDER BY created_at DESC LIMIT ?",(limit,)).fetchall()]
        top_results=[dict(r) for r in con.execute("""
            SELECT r.experiment_id,e.name AS experiment_name,r.service,r.model_name,r.accuracy,r.precision_macro,r.recall_macro,r.f1_macro,r.f1_weighted,r.mcc,r.roc_auc,r.train_seconds,r.created_at
            FROM ml_results r JOIN ml_experiments e ON e.id=r.experiment_id
            WHERE r.mcc IS NOT NULL
            ORDER BY r.mcc DESC, r.f1_macro DESC, r.accuracy DESC LIMIT 30
        """).fetchall()]
        latest_id=experiments[0]["id"] if experiments else None
        latest_results=[]
        if latest_id:
            latest_results=[dict(r) for r in con.execute("SELECT service,model_name,accuracy,precision_macro,recall_macro,f1_macro,f1_weighted,mcc,roc_auc,train_seconds,confusion_matrix_json,report_json FROM ml_results WHERE experiment_id=? ORDER BY service,mcc DESC,f1_macro DESC",(latest_id,)).fetchall()]
    return {"experiments":experiments,"top_results":top_results,"latest_experiment_id":latest_id,"latest_results":latest_results}

@app.get("/api/studio/ml-experiments/{experiment_id}")
def studio_ml_experiment_detail(experiment_id:str):
    experiment_id=_reject_dangerous(experiment_id,"experiment id",80)
    with _db_lock, db_conn() as con:
        exp=con.execute("SELECT * FROM ml_experiments WHERE id=?",(experiment_id,)).fetchone()
        if not exp:
            raise HTTPException(404,"Experiment not found")
        results=[dict(r) for r in con.execute("SELECT * FROM ml_results WHERE experiment_id=? ORDER BY service,mcc DESC,f1_macro DESC",(experiment_id,)).fetchall()]
    e=dict(exp)
    try:
        e["config"]=json.loads(e.get("config_json") or "{}")
    except Exception:
        e["config"]={}
    for r in results:
        for k in ["confusion_matrix_json","report_json"]:
            try:
                r[k.replace("_json","")]=json.loads(r.get(k) or ("[]" if k.startswith("confusion") else "{}"))
            except Exception:
                r[k.replace("_json","")]=[] if k.startswith("confusion") else {}
    return {"experiment":e,"results":results}

# ---------------------------------------------------------------------------
# Experiment Workspace API (CAUSALIS v0.3)
# ---------------------------------------------------------------------------
@app.get("/api/experiments")
def list_experiments(include_archived: bool=False):
    with _db_lock, db_conn() as con:
        _ensure_default_experiment(con)
        sql="SELECT * FROM experiments" + ("" if include_archived else " WHERE archived=0") + " ORDER BY updated_at DESC"
        rows=con.execute(sql).fetchall()
    current=current_experiment_id()
    return {"current_experiment_id":current,"experiments":[_experiment_dict(r) for r in rows]}

@app.post("/api/experiments")
def create_experiment(req: ExperimentCreateReq):
    name=_reject_dangerous(req.name,"experiment name",160)
    if not name: raise HTTPException(400,"Experiment name is required")
    eid=str(uuid.uuid4())
    ts=now()
    objective=_safe_token(req.objective,"objective")
    tags=[_reject_dangerous(x,"tag",50) for x in req.tags[:20]]
    with _db_lock, db_conn() as con:
        con.execute("""INSERT INTO experiments(id,name,description,objective,status,tags_json,created_at,updated_at,cloned_from,archived,metadata_json)
                     VALUES(?,?,?,?,?,?,?,?,?,?,?)""",(eid,name,_reject_dangerous(req.description,"description",2000),objective,"draft",json.dumps(tags),ts,ts,None,0,"{}"))
        con.execute("INSERT INTO experiment_workflows(experiment_id,steps_json,updated_at) VALUES(?,?,?)",(eid,json.dumps(_default_workflow()),ts))
        con.commit()
    set_current_experiment(eid)
    record_experiment_activity("experiment","created",f"Experiment {name} created",eid)
    return _experiment_summary(eid)

@app.get("/api/experiments/current")
def get_current_experiment():
    return _experiment_summary(current_experiment_id())

@app.post("/api/experiments/{eid}/select")
def select_experiment(eid:str):
    set_current_experiment(eid)
    return _experiment_summary(eid)

@app.get("/api/experiments/{eid}")
def get_experiment(eid:str):
    return _experiment_summary(eid)

@app.patch("/api/experiments/{eid}")
def update_experiment(eid:str, req:ExperimentUpdateReq):
    allowed_status={"draft","active","completed","failed","archived"}
    with _db_lock, db_conn() as con:
        row=con.execute("SELECT * FROM experiments WHERE id=?",(eid,)).fetchone()
        if not row: raise HTTPException(404,"Experiment not found")
        d=_experiment_dict(row)
        name=_reject_dangerous(req.name if req.name is not None else d['name'],"experiment name",160)
        desc=_reject_dangerous(req.description if req.description is not None else d.get('description',''),"description",2000)
        objective=_safe_token(req.objective if req.objective is not None else d.get('objective','dataset_generation'),"objective")
        status=req.status if req.status is not None else d.get('status','draft')
        if status not in allowed_status: raise HTTPException(400,"Invalid experiment status")
        tags=req.tags if req.tags is not None else d.get('tags',[])
        tags=[_reject_dangerous(x,"tag",50) for x in tags[:20]]
        con.execute("UPDATE experiments SET name=?,description=?,objective=?,status=?,tags_json=?,updated_at=?,archived=? WHERE id=?",(name,desc,objective,status,json.dumps(tags),now(),1 if status=='archived' else 0,eid))
        con.commit()
    record_experiment_activity("experiment","updated",f"Experiment {name} updated",eid)
    return _experiment_summary(eid)

@app.post("/api/experiments/{eid}/clone")
def clone_experiment(eid:str):
    with _db_lock, db_conn() as con:
        row=con.execute("SELECT * FROM experiments WHERE id=?",(eid,)).fetchone()
        if not row: raise HTTPException(404,"Experiment not found")
        src=_experiment_dict(row); nid=str(uuid.uuid4()); ts=now(); name=f"{src['name']} (Copy)"
        con.execute("""INSERT INTO experiments(id,name,description,objective,status,tags_json,created_at,updated_at,cloned_from,archived,metadata_json)
                     VALUES(?,?,?,?,?,?,?,?,?,?,?)""",(nid,name,src.get('description',''),src.get('objective','dataset_generation'),'draft',json.dumps(src.get('tags',[])),ts,ts,eid,0,json.dumps(src.get('metadata',{}))))
        wf=con.execute("SELECT steps_json FROM experiment_workflows WHERE experiment_id=?",(eid,)).fetchone()
        con.execute("INSERT INTO experiment_workflows(experiment_id,steps_json,updated_at) VALUES(?,?,?)",(nid,wf['steps_json'] if wf else json.dumps(_default_workflow()),ts))
        con.commit()
    set_current_experiment(nid)
    record_experiment_activity("experiment","cloned",f"Experiment cloned from {src['name']}",nid,{"source_experiment_id":eid})
    return _experiment_summary(nid)

@app.get("/api/experiments/{eid}/workflow")
def get_experiment_workflow(eid:str):
    with _db_lock, db_conn() as con:
        if not con.execute("SELECT 1 FROM experiments WHERE id=?",(eid,)).fetchone(): raise HTTPException(404,"Experiment not found")
        row=con.execute("SELECT steps_json,updated_at FROM experiment_workflows WHERE experiment_id=?",(eid,)).fetchone()
    return {"experiment_id":eid,"steps":json.loads(row['steps_json']) if row else _default_workflow(),"updated_at":row['updated_at'] if row else None}

@app.put("/api/experiments/{eid}/workflow")
def update_experiment_workflow(eid:str, req:WorkflowUpdateReq):
    steps=[]
    for i,s in enumerate(req.steps):
        steps.append({"id":s.id,"step_type":_safe_token(s.step_type,"step type"),"name":_reject_dangerous(s.name,"step name",160),"enabled":bool(s.enabled),"order":i+1,"technique_id":_reject_dangerous(s.technique_id or "","technique id",40) or None,"configuration":s.configuration})
    with _db_lock, db_conn() as con:
        if not con.execute("SELECT 1 FROM experiments WHERE id=?",(eid,)).fetchone(): raise HTTPException(404,"Experiment not found")
        con.execute("INSERT OR REPLACE INTO experiment_workflows(experiment_id,steps_json,updated_at) VALUES(?,?,?)",(eid,json.dumps(steps,ensure_ascii=False),now()))
        con.execute("UPDATE experiments SET updated_at=? WHERE id=?",(now(),eid)); con.commit()
    record_experiment_activity("workflow","updated","Experiment workflow updated",eid,{"steps":len(steps)})
    return {"experiment_id":eid,"steps":steps}

@app.get("/api/studio/about")
def studio_about():
    marker=ROOT/".causalis-installation"
    installation={}
    if marker.exists():
        for line in marker.read_text(encoding="utf-8",errors="ignore").splitlines():
            if "=" in line:
                k,v=line.split("=",1); installation[k.strip()]=v.strip()
    return {
        "product":PRODUCT_NAME,"version":PRODUCT_VERSION,"descriptor":PRODUCT_DESCRIPTOR,"tagline":PRODUCT_TAGLINE,
        "baseline":BASELINE_NAME,"python":sys.version.split()[0],"platform":platform.platform(),
        "sqlite":sqlite3.sqlite_version,"fastapi":getattr(__import__('fastapi'),'__version__','unknown'),
        "database":str(DB_PATH.relative_to(ROOT)),"installation":installation,
        "paths":{"data":str(DATA.relative_to(ROOT)),"exports":str(EXP.relative_to(ROOT)),"models":str(MODELS_DIR.relative_to(ROOT))}
    }

@app.get("/api/experiments/{eid}/artifacts")
def experiment_artifacts(eid:str):
    # Artifact ownership becomes explicit in a later storage migration. In v0.4
    # the explorer is intentionally read-only and displays validated global artifacts.
    _experiment_summary(eid)
    items=_artifact_inventory()
    counts={}
    for item in items: counts[item['category']]=counts.get(item['category'],0)+1
    return {"experiment_id":eid,"scope":"workspace-compatible global artifact inventory","counts":counts,"items":items[:160]}

@app.post("/api/experiments/guided-create")
def guided_create_experiment(req:GuidedExperimentReq):
    name=_reject_dangerous(req.name,"experiment name",160)
    if not name: raise HTTPException(400,"Experiment name is required")
    objective=_safe_token(req.objective,"objective")
    infra=_safe_token(req.infrastructure_mode,"infrastructure mode")
    traffic=_safe_token(req.traffic_profile,"traffic profile")
    ml_profile=_safe_token(req.ml_profile,"ML profile")
    outputs=[_safe_token(x,"dataset output") for x in req.dataset_outputs[:5]]
    report_formats=[_safe_token(x,"report format") for x in req.report_formats[:3]]
    discovery=None
    if infra=="intelligent_discovery":
        raw=req.discovery or {}
        discovery={
            "ip_range":_reject_dangerous(str(raw.get("ip_range", "")),"discovery range",120),
            "scan_profile":_safe_token(str(raw.get("scan_profile", "quick")),"scan profile"),
            "ports":_reject_dangerous(str(raw.get("ports", "")),"discovery ports",500),
            "timeout_seconds":max(0.05,min(3.0,float(raw.get("timeout_seconds",0.35)))),
            "detection_profile":_safe_token(str(raw.get("detection_profile","atg_honeynet")),"detection profile"),
            "allow_non_private":bool(raw.get("allow_non_private",False)),
        }
        if not discovery["ip_range"]: raise HTTPException(400,"Authorized laboratory CIDR range is required for Intelligent Mode")
    metadata={"guided":True,"infrastructure_mode":infra,"traffic_profile":traffic,"dataset_outputs":outputs,"ml_profile":ml_profile,"report_formats":report_formats,"discovery":discovery}
    eid=str(uuid.uuid4()); ts=now(); tags=[_reject_dangerous(x,"tag",50) for x in req.tags[:20]]
    steps=_default_workflow()
    config_by_type={
        "traffic":{"profile":traffic,"infrastructure_mode":infra},
        "dataset":{"outputs":outputs},
        "machine_learning":{"profile":ml_profile},
        "report":{"formats":report_formats},
    }
    for step in steps:
        step["configuration"].update(config_by_type.get(step["step_type"],{}))
        if step["step_type"]=="machine_learning": step["enabled"]=bool(req.include_ml)
        if step["step_type"]=="report": step["enabled"]=bool(req.include_report)
    with _db_lock, db_conn() as con:
        con.execute("""INSERT INTO experiments(id,name,description,objective,status,tags_json,created_at,updated_at,cloned_from,archived,metadata_json) VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
                    (eid,name,_reject_dangerous(req.description,"description",2000),objective,"active",json.dumps(tags),ts,ts,None,0,json.dumps(metadata)))
        con.execute("INSERT INTO experiment_workflows(experiment_id,steps_json,updated_at) VALUES(?,?,?)",(eid,json.dumps(steps),ts)); con.commit()
    set_current_experiment(eid)
    record_experiment_activity("guided_setup","completed",f"Guided experiment {name} created",eid,metadata)
    return _experiment_summary(eid)

@app.get("/api/health")
def health():
    return {"status":"ok","product":PRODUCT_NAME,"version":PRODUCT_VERSION,"core":"threatsleuth-atg-1.0.0","time":now(),"services":SERVICES}

@app.get("/api/system/status")
def system_status():
    return _system_time_status()

@app.get("/api/taxonomy")
def tax(): return CAPEC
@app.get("/api/services")
def services(): return SERVICES
@app.get("/api/service-catalog")
def service_catalog():
    return {"services":SERVICE_CATALOG,"port_map":SERVICE_BY_PORT,"traffic_kind_by_port":HONEynet_TRAFFIC_KIND_BY_PORT,"capec_taxonomy":CAPEC}
@app.get("/api/targets")
def targets(): return db_targets()
@app.post("/api/targets")
def add_target(t:Target):
    db_add_target(t)
    return {"saved": True, "target": _validate_target_payload(t.model_dump())}
@app.delete("/api/targets/{tid}")
def delete_target(tid:str):
    return {"deleted":db_delete_target(tid)}
@app.get("/api/profiles")
def profiles(): return get_profiles()
@app.post("/api/profiles")
def add_profile(p:Profile):
    db_add_profile(p); return p
@app.post("/api/campaigns")
def start(c:Campaign):
    c=Campaign(**_validate_campaign_payload(c.model_dump()))
    cid=str(uuid.uuid4()); campaigns[cid]={"id":cid,"status":"created","started_at":now(),"started_epoch":epoch(),"finished_at":None,"request":c.model_dump(),"events":0,"duration_seconds":c.duration_seconds,"progress_pct":0}; stops[cid]=threading.Event()
    threading.Thread(target=loop,args=(cid,c),daemon=True).start(); return {"campaign_id":cid}
@app.post("/api/campaign-groups")
def start_campaign_group(g:CampaignGroup):
    ensure_scheduler_started()
    if not g.name.strip():
        raise HTTPException(400,"Campaign name is required")
    if not g.actions:
        raise HTTPException(400,"Campaign needs at least one target + profile action")
    if not g.execute_now:
        if _schedule_epoch_from_payload(g) is None:
            raise HTTPException(400,"Select a valid scheduled date and time")
    gid=str(uuid.uuid4())
    status="running" if g.execute_now else "scheduled"
    experiment_id=current_experiment_id()
    hist={"id":gid,"name":g.name,"status":status,"created_at":now(),"started_at":None,"finished_at":None,"scheduled_start":g.scheduled_start,"scheduled_start_epoch":_schedule_epoch_from_payload(g),"execute_now":g.execute_now,"notes":g.notes,"actions_total":len(g.actions),"actions_finished":0,"child_campaigns":[],"progress_pct":0,"group_payload":g.model_dump(),"experiment_id":experiment_id}
    history_upsert(hist)
    record_experiment_activity("campaign","started" if g.execute_now else "scheduled",f"Campaign {g.name} {status}",experiment_id,{"campaign_group_id":gid})
    if g.execute_now:
        threading.Thread(target=group_worker,args=(gid,g),daemon=True).start()
    return {"campaign_group_id":gid,"status":status}

@app.get("/api/campaign-history")
def get_campaign_history():
    runtime={c.get("group_id"):c for c in campaigns.values() if c.get("group_id")}
    return list(reversed(campaign_history()))
@app.post("/api/test-once")
def test(c:Campaign):
    c=Campaign(**_validate_campaign_payload(c.model_dump()))
    cid="test-"+str(uuid.uuid4())[:8]; campaigns[cid]={"id":cid,"status":"test","started_at":now(),"started_epoch":epoch(),"finished_at":now(),"request":c.model_dump(),"events":0,"duration_seconds":1,"progress_pct":100}; stops[cid]=threading.Event(); worker(cid,c); return all_events()[-1]
@app.get("/api/campaigns")
def camps(): return list(campaigns.values())
@app.post("/api/campaigns/{cid}/stop")
def stop(cid:str):
    if cid in stops: stops[cid].set(); return {"stopping":True}
    raise HTTPException(404,"not found")
@app.get("/api/events")
def events(limit:int=200): return all_events()[-limit:]
@app.get("/api/metrics")
def met(): return metrics()
@app.get("/api/export")
def export(service:str="all",kind:str="all",fmt:str="csv"):
    p=export_file(service,kind,fmt); return FileResponse(str(p),filename=p.name)
@app.get("/api/export/split")
def split(fmt:str="csv", output_dir: str = ""):
    """Export fully processed clean datasets split into training/test CSV files.
    This function only uses files from exports/clean_datasets so the ZIP contains
    data after matching + cleaning, not raw ATG events.
    """
    clean_files=sorted(CLEAN_DIR.glob("clean_*.csv"))
    if not clean_files:
        raise HTTPException(404,"No clean datasets found. Generate clean CSV files before exporting the split ZIP.")
    out_dir=_safe_output_dir(output_dir, SPLIT_DIR)
    z=out_dir/f"processed_dataset_splits_{datetime.now().strftime('%Y%m%d_%H%M%S')}.zip"
    with zipfile.ZipFile(z,"w",zipfile.ZIP_DEFLATED) as zz:
        for src in clean_files:
            text=src.read_text(encoding="utf-8",errors="ignore")
            rows,fields,dialect=_read_csv_text(text)
            if not fields:
                continue
            # Expected name: clean_<service>_<kind>_<timestamp>.csv
            parts=src.stem.split('_')
            service=parts[1] if len(parts)>2 else 'unknown'
            kind=parts[2] if len(parts)>3 else 'all'
            cut=max(1,int(len(rows)*0.8)) if rows else 0
            sets=[('training',rows[:cut]),('test',rows[cut:])]
            for split_name,split_rows in sets:
                buf=io.StringIO()
                w=csv.DictWriter(buf,fieldnames=fields)
                w.writeheader()
                for r in split_rows:
                    w.writerow({k:r.get(k,'') for k in fields})
                arc=f"{service}/{service}_{kind}_{split_name}.csv"
                zz.writestr(arc,buf.getvalue())
    return FileResponse(str(z),filename=z.name)



def _csv_dialect(text:str):
    sample=text[:8192]
    try: return csv.Sniffer().sniff(sample,delimiters=",;\t|")
    except Exception: return csv.excel

def _read_csv_text(text:str):
    dialect=_csv_dialect(text)
    reader=csv.DictReader(io.StringIO(text),dialect=dialect)
    rows=[dict(r) for r in reader]
    return rows, (reader.fieldnames or []), dialect

def _is_float(v):
    if v is None: return False
    v=str(v).strip().replace(",",".")
    if v=="": return False
    try:
        x=float(v)
        return math.isfinite(x)
    except Exception:
        return False

def _to_float(v): return float(str(v).strip().replace(",","."))

def _quantile(vals,q):
    if not vals: return None
    vals=sorted(vals); pos=(len(vals)-1)*q; lo=math.floor(pos); hi=math.ceil(pos)
    if lo==hi: return vals[int(pos)]
    return vals[lo]*(hi-pos)+vals[hi]*(pos-lo)

def _missing(v):
    if v is None: return True
    return str(v).strip() in ("","NaN","nan","None","null","NULL","N/A","n/a")

def _looks_datetime(v):
    v=str(v).strip()
    if not v: return False
    for fmt in ("%Y-%m-%d","%Y-%m-%d %H:%M:%S","%Y-%m-%dT%H:%M:%S","%d/%m/%Y","%d/%m/%Y %H:%M:%S","%d/%b/%Y:%H:%M:%S %z"):
        try: datetime.strptime(v[:len(v)],fmt); return True
        except Exception: pass
    try:
        datetime.fromisoformat(v.replace("Z","+00:00")); return True
    except Exception:
        return False

def _norm_text(v):
    return re.sub(r"\s+"," ",str(v or "").strip()).lower()

def analyze_rows(rows,fields):
    total=len(rows)
    columns=[]; numeric_values={}; categorical_values={}; date_cols=[]
    missing_report=[]; type_report=[]; text_report=[]; domain_report=[]
    for col in fields:
        raw_vals=[r.get(col) for r in rows]
        vals=["" if v is None else str(v) for v in raw_vals]
        non_empty=[v.strip() for v in vals if not _missing(v)]
        miss=total-len(non_empty)
        miss_ratio=(miss/total) if total else 0
        counts={}
        for v in non_empty: counts[v]=counts.get(v,0)+1
        unique=len(counts)
        entropy=0.0
        if non_empty:
            for c in counts.values():
                p=c/len(non_empty); entropy-=p*math.log2(p)
        max_entropy=math.log2(unique) if unique>1 else 0.0
        norm=(entropy/max_entropy) if max_entropy else 0.0
        dominant=(max(counts.values())/len(non_empty)) if non_empty and counts else 0.0
        nums=[_to_float(v) for v in non_empty if _is_float(v)]
        num_ratio=(len(nums)/len(non_empty)) if non_empty else 0
        date_hits=sum(1 for v in non_empty if _looks_datetime(v))
        date_ratio=(date_hits/len(non_empty)) if non_empty else 0
        if num_ratio>=0.85:
            inferred="numeric"; numeric_values[col]=nums
        elif date_ratio>=0.85:
            inferred="datetime"; date_cols.append(col)
        else:
            inferred="categorical"; categorical_values[col]=non_empty
        std=statistics.pstdev(nums) if len(nums)>1 else 0.0
        mean=statistics.fmean(nums) if nums else None
        mark=(unique<=1) or (norm<=0.02) or (dominant>=0.98) or (inferred=="numeric" and std==0)
        reason=[]
        if unique<=1: reason.append("zero variability")
        if norm<=0.02 and unique>1: reason.append("near-zero entropy")
        if dominant>=0.98 and unique>1: reason.append("dominant value >=98%")
        if inferred=="numeric" and std==0 and unique>1: reason.append("standard deviation 0")
        columns.append({"name":col,"type":inferred,"non_empty":len(non_empty),"missing":miss,"missing_ratio":round(miss_ratio,6),"unique":unique,"entropy":round(entropy,6),"normalized_entropy":round(norm,6),"dominant_ratio":round(dominant,6),"mean":round(mean,6) if mean is not None else None,"std":round(std,6) if inferred=="numeric" else None,"mark_low_variability":bool(mark),"reason":"; ".join(reason) if reason else ""})
        missing_cause="no missing values"
        action="no action"
        if miss:
            empty_rows=[i for i,v in enumerate(vals) if _missing(v)]
            first=max(1,int(total*.1)); last=max(1,int(total*.9))
            early=sum(1 for i in empty_rows if i<first); late=sum(1 for i in empty_rows if i>=last)
            if early/miss>0.7 or late/miss>0.7: missing_cause="possible systematic absence by time/ingestion block"
            elif len(empty_rows)>3 and all((b-a)<=2 for a,b in zip(empty_rows,empty_rows[1:])): missing_cause="possible consecutive missing-values block"
            else: missing_cause="apparently random"
            if miss_ratio>0.4: action="consider dropping the column"
            elif inferred=="numeric": action="impute with median/mean or review the source"
            else: action="impute with mode/unknown category or review the source"
        missing_report.append({"column":col,"missing":miss,"missing_ratio":round(miss_ratio,4),"cause":missing_cause,"suggested_action":action})
        type_issues=[]
        if inferred=="numeric" and num_ratio<1: type_issues.append(f"{round((1-num_ratio)*100,2)}% non-numeric")
        if inferred=="datetime" and date_ratio<1: type_issues.append(f"{round((1-date_ratio)*100,2)}% non-date")
        suggested_type={"numeric":"float","datetime":"datetime","categorical":"string/category"}[inferred]
        type_report.append({"column":col,"inferred_type":inferred,"suggested_type":suggested_type,"issues":"; ".join(type_issues)})
        if inferred=="categorical" and non_empty:
            normalized={}
            weird=0; with_spaces=0
            for v in non_empty:
                if v!=v.strip(): with_spaces+=1
                if "�" in v or "\\x" in v: weird+=1
                normalized.setdefault(_norm_text(v),set()).add(v)
            variants=[{"normalized":k,"variants":sorted(list(v))[:8],"count":len(v)} for k,v in normalized.items() if len(v)>1]
            if variants or weird or with_spaces:
                text_report.append({"column":col,"space_issues":with_spaces,"encoding_suspicions":weird,"variant_groups":variants[:10],"suggested_action":"trim, normalize case and review UTF-8 encoding"})
        cname=col.lower()
        if inferred=="numeric" and nums:
            neg=sum(1 for x in nums if x<0)
            if any(k in cname for k in ["age","edad","count","num","total","duration","duracion","latency","latencia","port","puerto"]) and neg:
                domain_report.append({"column":col,"issue":"negative values in a field that should normally be non-negative","count":neg})
            if any(k in cname for k in ["port","puerto"]):
                bad=sum(1 for x in nums if x<0 or x>65535)
                if bad: domain_report.append({"column":col,"issue":"ports out of range 0-65535","count":bad})
    # duplicates
    seen={}; duplicate_rows=[]
    for i,r in enumerate(rows):
        key=tuple((r.get(f) or "") for f in fields)
        if key in seen: duplicate_rows.append({"row":i+2,"first_row":seen[key]+2})
        else: seen[key]=i
    duplicate_report={"exact_duplicates":len(duplicate_rows),"examples":duplicate_rows[:50],"suggested_action":"remove exact duplicates and review partial duplicates by ID/timestamp" if duplicate_rows else "no action"}
    partial=[]
    id_candidates=[f for f in fields if f.lower() in ("id","event_id","eventid","uuid","session_id") or f.lower().endswith("_id")]
    for idc in id_candidates[:5]:
        vals={}
        for i,r in enumerate(rows):
            v=(r.get(idc) or "").strip()
            if v: vals.setdefault(v,[]).append(i+2)
        reps=[{"value":k,"rows":v[:10],"count":len(v)} for k,v in vals.items() if len(v)>1]
        if reps: partial.append({"column":idc,"repeated_ids":reps[:20]})
    duplicate_report["partial_duplicates"]=partial
    # outliers
    outlier_rows={}; outlier_columns=[]
    for col,vals_all in numeric_values.items():
        vals=[]; idxs=[]
        for i,r in enumerate(rows):
            v=(r.get(col) or "").strip()
            if _is_float(v): vals.append(_to_float(v)); idxs.append(i)
        if len(vals)<4: continue
        q1=_quantile(vals,.25); q3=_quantile(vals,.75); iqr=(q3-q1) if q1 is not None and q3 is not None else 0
        if iqr==0:
            if len(set(vals))<=1: continue
            med=_quantile(vals,.5); low=med; high=med
        else:
            low=q1-1.5*iqr; high=q3+1.5*iqr
        hits=[]
        for i,x in zip(idxs,vals):
            if x<low or x>high:
                hits.append({"row":i+2,"value":x})
                outlier_rows.setdefault(i,[]).append(col)
        if hits:
            outlier_columns.append({"column":col,"count":len(hits),"low":round(low,6),"high":round(high,6),"examples":hits[:10],"suggested_action":"review context; remove if it is an error, transform if it is a valid extreme value"})
    ranked=sorted([{"row":i+2,"columns":cols,"count":len(cols)} for i,cols in outlier_rows.items()],key=lambda x:x["count"],reverse=True)
    # correlations
    correlations=[]
    ncols=list(numeric_values.keys())[:60]
    def pearson(a,b):
        n=min(len(a),len(b))
        if n<3: return None
        a=a[:n]; b=b[:n]; ma=statistics.fmean(a); mb=statistics.fmean(b)
        da=[x-ma for x in a]; db=[y-mb for y in b]
        va=sum(x*x for x in da); vb=sum(y*y for y in db)
        if va==0 or vb==0: return None
        return sum(x*y for x,y in zip(da,db))/math.sqrt(va*vb)
    for i,c1 in enumerate(ncols):
        for c2 in ncols[i+1:]:
            r=pearson(numeric_values[c1],numeric_values[c2])
            if r is not None and abs(r)>=0.95:
                correlations.append({"column_a":c1,"column_b":c2,"correlation":round(r,6),"suggested_action":"possible redundancy/multicollinearity; keep only one if they provide the same information"})
    # class balance heuristic
    class_candidates=[f for f in fields if f.lower() in ("label","class","target","y","categoria","category","attack_category","capec_category")]
    balance=[]
    for c in class_candidates[:5]:
        vals=[(r.get(c) or "").strip() for r in rows if not _missing(r.get(c))]
        cnt={}
        for v in vals: cnt[v]=cnt.get(v,0)+1
        if len(cnt)>1:
            totalv=sum(cnt.values()); dist={k:round(v/totalv,4) for k,v in sorted(cnt.items(),key=lambda x:x[1],reverse=True)}
            minr=min(dist.values()); maxr=max(dist.values())
            balance.append({"column":c,"classes":cnt,"distribution":dist,"imbalance_ratio":round(maxr/max(minr,1e-9),3),"suggested_action":"review class balance; consider stratification, weighting or resampling" if maxr/max(minr,1e-9)>3 else "acceptable balance"})
    return {"rows":total,"columns_count":len(fields),"columns":columns,"low_variability_columns":[c for c in columns if c["mark_low_variability"]],"missing_report":missing_report,"duplicate_report":duplicate_report,"type_report":type_report,"text_quality_report":text_report,"domain_logic_report":domain_report,"correlation_report":correlations[:100],"class_balance_report":balance,"outlier_columns":outlier_columns,"outlier_rows":ranked[:500],"outlier_row_count":len(ranked)}

def build_match(service:str,dataset_kind:str,window_seconds:int,log_text:str):
    # Keep matching deterministic and safe: service/kind are tokens and the time window is bounded.
    service=_safe_token(service,"service")
    dataset_kind=_safe_token(dataset_kind or "all","dataset kind")
    if dataset_kind not in {"all","normal","anomaly"}:
        raise HTTPException(400,"dataset_kind must be all, normal or anomaly")
    window_seconds=_positive_int(window_seconds,"matching window",1,3600)
    log_text=str(log_text or "")
    if len(log_text) > 120_000_000:
        raise HTTPException(400,"log text is too large; maximum supported size is 120 MB")
    events=[e for e in all_events() if e.get("service")==service and (dataset_kind=="all" or (dataset_kind=="normal" and e.get("label")=="benign") or (dataset_kind=="anomaly" and e.get("label")=="anomaly"))]
    logs=[{"line":l,"ts":log_time(l)} for l in log_text.splitlines()]
    rows=[]
    for e in events:
        best=""
        for l in logs:
            if l["ts"] and abs(float(e.get("timestamp_epoch",0))-l["ts"])<=window_seconds:
                best=l["line"]; break
        r=dict(e); r["matched"]=bool(best); r["matched_log_line"]=best; rows.append(r)
    out=MATCHED_DIR/f"matched_{service}_{dataset_kind}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
    fields=["timestamp","timestamp_epoch","campaign_id","service","mode","label","attack_category_key","capec_id","capec_category","action","status","detail","matched","matched_log_line"]
    with out.open("w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader()
        for r in rows: w.writerow({k:r.get(k,"") for k in fields})
    return {"file":out.name,"folder":"matched_logs","download":f"/api/download/matched_logs/{out.name}","events":len(events),"log_lines":len(logs),"matched":sum(1 for r in rows if r.get("matched"))}
@app.post("/api/match")
def match(m:MatchReq):
    return build_match(m.service,m.dataset_kind,m.window_seconds,m.log_text)

@app.post("/api/match-file")
async def match_file(service:str=Form(...), dataset_kind:str=Form("all"), window_seconds:int=Form(5), log_file:UploadFile=File(...)):
    if not (log_file.filename or "").lower().endswith((".log",".txt",".json",".jsonl",".csv")):
        raise HTTPException(400,"Unsupported log file extension")
    raw=await log_file.read()
    if len(raw) > 120_000_000:
        raise HTTPException(400,"The log file is too large; maximum supported size is 120 MB")
    if not raw:
        raise HTTPException(400,"The log file is empty")
    text=raw.decode("utf-8",errors="ignore")
    return build_match(service,dataset_kind,window_seconds,text)


@app.post("/api/dataset/analyze-file")
async def analyze_dataset_file(dataset_file:UploadFile=File(...)):
    if not (dataset_file.filename or "").lower().endswith(".csv"):
        raise HTTPException(400,"Only CSV dataset files are allowed")
    raw=await dataset_file.read()
    if not raw:
        raise HTTPException(400,"The CSV is empty")
    text=raw.decode("utf-8-sig",errors="ignore")
    rows,fields,dialect=_read_csv_text(text)
    if not fields:
        raise HTTPException(400,"CSV headers were not detected")
    upload_id=str(uuid.uuid4())
    stored=UPLOADS/f"dataset_{upload_id}.csv"
    stored.write_text(text,encoding="utf-8")
    report=analyze_rows(rows,fields)
    report.update({"upload_id":upload_id,"filename":dataset_file.filename or stored.name})
    return report

@app.post("/api/dataset/clean")
def clean_dataset(req:CleanReq):
    src=UPLOADS/f"dataset_{req.upload_id}.csv"
    if not src.exists():
        raise HTTPException(404,"Dataset not found. Upload the CSV again")
    text=src.read_text(encoding="utf-8",errors="ignore")
    rows,fields,dialect=_read_csv_text(text)
    report=analyze_rows(rows,fields)
    outlier_set=set()
    if req.drop_outlier_rows:
        outlier_set={int(r["row"])-2 for r in report.get("outlier_rows",[])}
    keep=[f for f in fields if f not in set(req.drop_columns or [])]
    svc=_safe_token(req.service or "unknown","service")
    kind=_safe_token(req.dataset_kind or "all","dataset kind")
    out=CLEAN_DIR/f"clean_{svc}_{kind}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
    seen=set(); dropped_duplicates=0
    with out.open("w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=keep); w.writeheader()
        written=0
        for i,r in enumerate(rows):
            if i in outlier_set: continue
            rr={k:r.get(k,"") for k in keep}
            if req.normalize_text:
                rr={k:(_norm_text(v) if isinstance(v,str) else v) for k,v in rr.items()}
            key=tuple(rr.get(k,"") for k in keep)
            if req.drop_duplicate_rows and key in seen:
                dropped_duplicates+=1; continue
            seen.add(key)
            w.writerow(rr); written+=1
    result={"file":out.name,"folder":"clean_datasets","download":f"/api/download/clean_datasets/{out.name}","original_rows":len(rows),"rows":written,"dropped_rows":len(rows)-written,"dropped_duplicates":dropped_duplicates,"dropped_columns":req.drop_columns}
    record_experiment_activity("dataset","completed",f"Clean {svc} {kind} dataset generated",metadata={"file":out.name,"rows":written})
    return result



def _read_uploaded_dataset(upload_id:str):
    src=UPLOADS/f"dataset_{upload_id}.csv"
    if not src.exists():
        raise HTTPException(404,"Dataset not found. Upload it first in Log Processing / Datasets")
    text=src.read_text(encoding="utf-8",errors="ignore")
    rows,fields,dialect=_read_csv_text(text)
    return src,rows,fields

def _safe_float(x):
    try:
        return None if x is None or (isinstance(x,float) and math.isnan(x)) else float(x)
    except Exception:
        return None

def _store_ml_experiment(exp, results):
    with _db_lock, db_conn() as con:
        workspace_id=exp.get('workspace_experiment_id') or current_experiment_id()
        exp['workspace_experiment_id']=workspace_id
        con.execute("""INSERT OR REPLACE INTO ml_experiments(id,name,dataset_filename,target_column,service_column,rows_total,columns_total,test_size,random_seed,created_at,best_model,best_service_summary,config_json,workspace_experiment_id)
                     VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",(
            exp['id'],exp['name'],exp.get('dataset_filename',''),exp['target_column'],exp.get('service_column',''),exp.get('rows_total',0),exp.get('columns_total',0),exp.get('test_size',0),exp.get('random_seed',42),exp['created_at'],exp.get('best_model',''),json.dumps(exp.get('best_by_service',{}),ensure_ascii=False),json.dumps(exp,ensure_ascii=False),workspace_id))
        for r in results:
            con.execute("""INSERT OR REPLACE INTO ml_results(id,experiment_id,service,model_name,accuracy,precision_macro,recall_macro,f1_macro,f1_weighted,mcc,roc_auc,train_seconds,artifact_path,confusion_matrix_json,report_json,created_at)
                         VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",(
                r['id'],exp['id'],r.get('service','ALL'),r['model_name'],r.get('accuracy'),r.get('precision_macro'),r.get('recall_macro'),r.get('f1_macro'),r.get('f1_weighted'),r.get('mcc'),r.get('roc_auc'),r.get('train_seconds'),r.get('artifact_path',''),json.dumps(r.get('confusion_matrix',[]),ensure_ascii=False),json.dumps(r,ensure_ascii=False),now()))
        con.commit()
    record_experiment_activity("machine_learning","completed",f"ML experiment {exp.get('name') or exp.get('id')} completed",exp.get('workspace_experiment_id'),{"ml_experiment_id":exp.get('id'),"best_model":exp.get('best_model')})

@app.get("/api/scheduler/status")
def scheduler_status():
    due=db_due_campaign_groups()
    return {"started":_scheduler_started,"time":now(),"due_now":len(due),"scheduled":[{"id":x.get('id'),"name":x.get('name'),"scheduled_start":x.get('scheduled_start'),"status":x.get('status')} for x in campaign_history() if x.get('status')=='scheduled']}

@app.post("/api/scheduler/tick")
def scheduler_tick():
    # Endpoint diagnóstico: fuerza una pasada del planificador sin esperar al polling.
    launched=[]
    for h in db_due_campaign_groups():
        gid=h.get('id')
        payload=h.get('group_payload') or h
        g=CampaignGroup(**payload)
        with _db_lock, db_conn() as con:
            cur=con.execute("UPDATE campaign_groups SET status='starting', group_json=? WHERE id=? AND status='scheduled'", (json.dumps({**h,'status':'starting'},ensure_ascii=False), gid))
            con.commit()
            if cur.rowcount!=1: continue
        threading.Thread(target=group_worker,args=(gid,g),daemon=True).start()
        launched.append(gid)
    return {"launched":launched}



def _write_rows_csv(path, fields, rows):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=fields)
        w.writeheader()
        for r in rows:
            w.writerow({k:r.get(k,'') for k in fields})

def _load_uploaded_csv_bytes(raw:bytes):
    text=raw.decode('utf-8-sig',errors='ignore')
    rows,fields,dialect=_read_csv_text(text)
    if not fields:
        raise HTTPException(400,'CSV headers were not detected')
    return rows,fields

def _sanitize_token(value, default='unknown'):
    return re.sub(r'[^a-zA-Z0-9_-]+','_',str(value or default).lower()).strip('_') or default

async def _read_ml_upload(file:UploadFile):
    """Read a user-uploaded CSV as data only.

    Remote URLs, path traversal sequences and unsupported extensions are rejected
    to reduce RFI/path traversal risks. Uploaded content is never executed.
    """
    filename = file.filename or "CSV"
    lower = filename.lower().strip()
    if any(x in lower for x in ("../", "..\\", "http://", "https://", "ftp://", "file://")):
        raise HTTPException(400, "Unsafe file name or remote path rejected")
    if not lower.endswith(".csv"):
        raise HTTPException(400,"Only CSV ML datasets are allowed")
    raw=await file.read()
    if not raw:
        raise HTTPException(400,f'{filename} is empty')
    if len(raw) > 200_000_000:
        raise HTTPException(400, "CSV is too large for interactive ML processing; maximum is 200 MB")
    return _load_uploaded_csv_bytes(raw)


def _normalize_experiment_name(value, default):
    """Normalize experiment/batch names instead of crashing on harmless characters."""
    raw = _reject_dangerous(value or default, "experiment name", 160)
    safe = re.sub(r"[^a-zA-Z0-9_-]+", "_", raw).strip("_")
    return safe or default


def _binary_extra_metrics(y_true, y_pred):
    """Return binary classification rates useful for security evaluation."""
    labels=sorted(list(set(y_true)|set(y_pred)))
    if len(labels)!=2:
        return {"specificity":None,"fpr":None,"fnr":None}
    try:
        tn, fp, fn, tp = __import__('sklearn.metrics').metrics.confusion_matrix(y_true,y_pred,labels=labels).ravel()
        specificity = tn/(tn+fp) if (tn+fp) else 0
        fpr = fp/(fp+tn) if (fp+tn) else 0
        fnr = fn/(fn+tp) if (fn+tp) else 0
        return {"specificity":round(specificity,6),"fpr":round(fpr,6),"fnr":round(fnr,6)}
    except Exception:
        return {"specificity":None,"fpr":None,"fnr":None}

def _dataset_summary_from_files(service, nt, at, nv, av, fields, feature_fields=None, excluded_fields=None):
    """Create a compact dataset report stored inside the experiment config."""
    feature_fields = feature_fields or [f for f in fields if f != "attack_flag"]
    excluded_fields = excluded_fields or []
    return {
        "service": service,
        "training": {"normal_rows": len(nt), "anomaly_rows": len(at), "total_rows": len(nt)+len(at)},
        "test": {"normal_rows": len(nv), "anomaly_rows": len(av), "total_rows": len(nv)+len(av)},
        "columns_total": len(fields),
        "features_count": len(feature_fields),
        "target_column": "attack_flag",
        "features_used": feature_fields,
        "features_excluded": excluded_fields,
        "class_distribution": {"training": {"normal": len(nt), "attack": len(at)}, "test": {"normal": len(nv), "attack": len(av)}}
    }

# Columns that must not be used as predictors for binary attack detection.
# They either contain the target itself or encode the answer indirectly, causing data leakage.
ML_BINARY_LEAKAGE_COLUMNS = {
    "attack_flag", "capec_id", "capec_category", "attack_category_key",
    "label", "mode", "dataset_kind", "dataset_type", "traffic_type", "is_attack"
}

# Metadata fields are useful for traceability and reports, but should not drive the classifier.
ML_BINARY_METADATA_EXCLUDE = {
    "campaign_id", "campaign_name", "event_id", "id", "timestamp", "timestamp_iso", "timestamp_epoch"
}

# Columns excluded when the target is CAPEC category/classification.  The target
# itself and alternate CAPEC identifiers are removed to avoid target leakage.
ML_CAPEC_LEAKAGE_COLUMNS = {
    "capec_id", "capec_category", "attack_category_key", "label", "attack_flag",
    "mode", "dataset_kind", "dataset_type", "traffic_type", "is_attack"
}

ML_CAPEC_METADATA_EXCLUDE = {
    "campaign_id", "campaign_name", "event_id", "id", "timestamp", "timestamp_iso", "timestamp_epoch"
}

def _binary_feature_fields(fields):
    """Return safe feature columns for binary classification and the excluded columns.

    The function is intentionally conservative: CAPEC labels and attack labels are
    removed from X so binary models learn behavior, not the answer embedded in
    metadata.
    """
    excluded=[]; features=[]
    for f in fields:
        fl=str(f).strip().lower()
        if fl in ML_BINARY_LEAKAGE_COLUMNS or fl in ML_BINARY_METADATA_EXCLUDE:
            excluded.append(f)
        else:
            features.append(f)
    return features, excluded


def _capec_feature_fields(fields, target_column='capec_category'):
    """Return leakage-safe features for multiclass CAPEC attribution.

    Only attack/anomaly records should be passed to the CAPEC pipeline.  The
    target column plus alternate CAPEC labels are excluded from predictors so the
    model learns behavioral/log features rather than reading the answer from
    another label column.
    """
    excluded=[]; features=[]
    target_l=str(target_column or 'capec_category').strip().lower()
    for f in fields:
        fl=str(f).strip().lower()
        if fl == target_l or fl in ML_CAPEC_LEAKAGE_COLUMNS or fl in ML_CAPEC_METADATA_EXCLUDE:
            excluded.append(f)
        else:
            features.append(f)
    return features, excluded


def _capec_distribution(rows, target_column='capec_category'):
    by_cat={}; by_service={}; by_service_cat={}
    for r in rows:
        cat=(r.get(target_column) or '').strip() or 'UNKNOWN'
        svc=(r.get('service') or 'unknown').strip() or 'unknown'
        by_cat[cat]=by_cat.get(cat,0)+1
        by_service[svc]=by_service.get(svc,0)+1
        by_service_cat.setdefault(svc,{})[cat]=by_service_cat.setdefault(svc,{}).get(cat,0)+1
    return {
        'target_column': target_column,
        'total_rows': len(rows),
        'by_category': dict(sorted(by_cat.items(), key=lambda kv: (-kv[1], kv[0]))),
        'by_service': dict(sorted(by_service.items(), key=lambda kv: (-kv[1], kv[0]))),
        'by_service_category': {k: dict(sorted(v.items(), key=lambda kv: (-kv[1], kv[0]))) for k,v in sorted(by_service_cat.items())}
    }


ML_KEYWORDS = [
    'get','post','head','put','delete','404','500','admin','login',
    'user','pass','list','retr','stor','failed','failure','auth','root','sudo','command','shell',
    'helo','ehlo','mail from','rcpt to','vrfy','expn','select','union','drop','sleep','script'
]

def _text_stats(prefix, value):
    """Create lightweight numeric features from free-text log fields."""
    text = str(value or '')
    lowered = text.lower()
    data = {
        f'{prefix}_length': len(text),
        f'{prefix}_word_count': len(re.findall(r'\w+', text)),
        f'{prefix}_digit_count': sum(ch.isdigit() for ch in text),
        f'{prefix}_special_count': sum((not ch.isalnum()) and (not ch.isspace()) for ch in text),
        f'{prefix}_upper_count': sum(ch.isupper() for ch in text),
        f'{prefix}_contains_ip': 1 if re.search(r'\b(?:\d{1,3}\.){3}\d{1,3}\b', text) else 0,
        f'{prefix}_contains_path': 1 if '/' in text else 0,
    }
    for kw in ML_KEYWORDS:
        key=f'{prefix}_contains_' + re.sub(r'[^a-z0-9]+','_',kw).strip('_')
        data[key] = 1 if kw in lowered else 0
    return data

def _augment_ml_features(base_item, row):
    """Add protocol-aware derived features used by leakage-safe ML experiments."""
    item = dict(base_item)
    detail = row.get('detail','')
    matched_line = row.get('matched_log_line','')
    item.update(_text_stats('detail', detail))
    item.update(_text_stats('logline', matched_line))
    combined = (str(detail or '') + ' ' + str(matched_line or '')).lower()
    item['combined_contains_error'] = 1 if any(x in combined for x in ['error','fail','failed','denied','invalid','unauthorized']) else 0
    item['combined_contains_auth'] = 1 if any(x in combined for x in ['auth','login','user','pass','password','root']) else 0
    item['combined_contains_scan'] = 1 if any(x in combined for x in ['scan','probe','nmap','enumerat','vrfy','expn']) else 0
    item['combined_contains_injection'] = 1 if any(x in combined for x in ['select','union','drop','sleep','script','../',' or ']) else 0
    return item

def _engineered_feature_names(feature_fields):
    """Return raw + derived feature names for reporting."""
    names=list(feature_fields)
    sample=_augment_ml_features({}, {'detail':'GET /login failed USER root 404', 'matched_log_line':'auth failed pass root'})
    for k in sample:
        if k not in names:
            names.append(k)
    return names

def _top_model_features(pipe, limit=20):
    """Extract top feature importances from models that expose them."""
    try:
        vec=pipe.named_steps.get('vec')
        model=pipe.named_steps.get('model')
        names=list(vec.get_feature_names_out()) if hasattr(vec,'get_feature_names_out') else list(vec.feature_names_)
        vals=None
        if hasattr(model,'feature_importances_'):
            vals=list(model.feature_importances_)
        elif hasattr(model,'coef_'):
            coefs=getattr(model,'coef_')
            try:
                import numpy as np
                vals=list(np.abs(coefs).mean(axis=0) if getattr(coefs,'ndim',1)>1 else np.abs(coefs))
            except Exception:
                vals=[abs(float(x)) for x in coefs[0]] if coefs is not None and len(coefs) else None
        if vals is None:
            return []
        pairs=sorted(zip(names, vals), key=lambda x: float(x[1] or 0), reverse=True)[:limit]
        return [{'feature':str(k),'importance':round(float(v),6)} for k,v in pairs]
    except Exception:
        return []

def _selected_model_names(profile='fast', selected_models_json=''):
    """Resolve requested model names from UI profile/manual selection."""
    fast=['Decision Tree','Random Forest','Extra Trees','Logistic Regression','Naive Bayes']
    balanced=fast+['KNN','Gradient Boosting','AdaBoost']
    full=balanced+['Hist Gradient Boosting','SVM','MLP']
    try:
        manual=json.loads(selected_models_json) if selected_models_json else []
        if isinstance(manual,list) and manual:
            return [str(x) for x in manual]
    except Exception:
        pass
    profile=str(profile or 'fast').lower()
    if profile=='full': return full
    if profile=='balanced': return balanced
    return fast

def _model_suite(random_seed):
    """Return the classifier suite used by CAUSALIS experiments."""
    from sklearn.tree import DecisionTreeClassifier
    from sklearn.ensemble import RandomForestClassifier, ExtraTreesClassifier, GradientBoostingClassifier, AdaBoostClassifier, HistGradientBoostingClassifier
    from sklearn.neighbors import KNeighborsClassifier
    from sklearn.naive_bayes import GaussianNB
    from sklearn.linear_model import LogisticRegression
    from sklearn.svm import SVC
    from sklearn.neural_network import MLPClassifier
    return {
        'Decision Tree':DecisionTreeClassifier(random_state=random_seed),
        'Random Forest':RandomForestClassifier(n_estimators=160,random_state=random_seed,n_jobs=-1,class_weight='balanced'),
        'Extra Trees':ExtraTreesClassifier(n_estimators=160,random_state=random_seed,n_jobs=-1,class_weight='balanced'),
        'Gradient Boosting':GradientBoostingClassifier(random_state=random_seed),
        'AdaBoost':AdaBoostClassifier(random_state=random_seed),
        'Hist Gradient Boosting':HistGradientBoostingClassifier(random_state=random_seed),
        'KNN':KNeighborsClassifier(n_neighbors=5),
        'Naive Bayes':GaussianNB(),
        'Logistic Regression':LogisticRegression(max_iter=1200,class_weight='balanced'),
        'SVM':SVC(kernel='rbf',class_weight='balanced',probability=True),
        'MLP':MLPClassifier(hidden_layer_sizes=(64,32),max_iter=300,random_state=random_seed)
    }

@app.post('/api/ml/binary-train')
async def ml_binary_train(
    service:str=Form(...),
    experiment_name:str=Form(''),
    random_seed:int=Form(42),
    model_profile:str=Form('fast'),
    selected_models_json:str=Form(''),
    normal_training_file:UploadFile=File(...),
    anomaly_training_file:UploadFile=File(...),
    normal_test_file:UploadFile=File(...),
    anomaly_test_file:UploadFile=File(...)
):
    """Train supervised binary classifiers with external train/test datasets.
    Normal and anomaly CSVs are combined automatically and an attack_flag target
    column is added: 0 = normal, 1 = attack.
    """
    try:
        from sklearn.feature_extraction import DictVectorizer
        from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, matthews_corrcoef, confusion_matrix, roc_auc_score
        from sklearn.pipeline import Pipeline
        from sklearn.tree import DecisionTreeClassifier
        from sklearn.ensemble import RandomForestClassifier
        from sklearn.neighbors import KNeighborsClassifier
        from sklearn.naive_bayes import GaussianNB
        from sklearn.linear_model import LogisticRegression
        from sklearn.svm import SVC
    except Exception as e:
        raise HTTPException(500,'Missing ML dependencies. Run deploy.sh to install scikit-learn. Detail: '+repr(e))
    svc=_safe_token(service,"service")
    random_seed=_positive_int(random_seed,"random seed",0,999999999)
    nt,nf=await _read_ml_upload(normal_training_file)
    at,af=await _read_ml_upload(anomaly_training_file)
    nv,nvf=await _read_ml_upload(normal_test_file)
    av,avf=await _read_ml_upload(anomaly_test_file)
    all_fields=[]
    for fs in [nf,af,nvf,avf]:
        for f in fs:
            if f not in all_fields and f!='attack_flag': all_fields.append(f)
    fields=all_fields+['attack_flag']
    def tag(rows,flag):
        out=[]
        for r in rows:
            rr={f:r.get(f,'') for f in all_fields}
            rr['attack_flag']=str(flag)
            out.append(rr)
        return out
    train_rows=tag(nt,0)+tag(at,1)
    test_rows=tag(nv,0)+tag(av,1)
    if len(train_rows)<10 or len(test_rows)<2:
        raise HTTPException(400,'Insufficient samples. Need at least 10 training rows and 2 test rows.')
    if len(set(r['attack_flag'] for r in train_rows))<2 or len(set(r['attack_flag'] for r in test_rows))<2:
        raise HTTPException(400,'Both training and test sets must contain normal and anomaly records.')
    ts=datetime.now().strftime('%Y%m%d_%H%M%S')
    train_path=ML_DATASETS_DIR/f'binary_{svc}_training_{ts}.csv'
    test_path=ML_DATASETS_DIR/f'binary_{svc}_test_{ts}.csv'
    _write_rows_csv(train_path,fields,train_rows)
    _write_rows_csv(test_path,fields,test_rows)
    feature_fields, excluded_fields = _binary_feature_fields(fields)
    if not feature_fields:
        raise HTTPException(400, 'No usable feature columns remain after leakage-safe exclusions.')
    def make_X(rows):
        X=[]
        for r in rows:
            item={}
            for f in feature_fields:
                v=r.get(f,'')
                item[f]=_to_float(v) if _is_float(v) else (str(v).strip() if v is not None else '')
            item=_augment_ml_features(item, r)
            X.append(item)
        return X
    Xtr=make_X(train_rows); ytr=[r['attack_flag'] for r in train_rows]
    Xte=make_X(test_rows); yte=[r['attack_flag'] for r in test_rows]
    all_models=_model_suite(random_seed)
    requested_models=_selected_model_names(model_profile, selected_models_json)
    models={name:all_models[name] for name in requested_models if name in all_models}
    if not models:
        raise HTTPException(400, 'No valid ML models selected.')
    exp_id=str(uuid.uuid4())
    exp_name=_normalize_experiment_name(experiment_name.strip(), f'binary_{svc}_{ts}')
    results=[]
    labels=['0','1']
    for name,model in models.items():
        start_t=time.time()
        try:
            pipe=Pipeline([('vec',DictVectorizer(sparse=False)),('model',model)])
            pipe.fit(Xtr,ytr)
            pred=pipe.predict(Xte)
            auc=None
            try:
                proba=pipe.predict_proba(Xte)
                auc=roc_auc_score(yte,proba[:,1])
            except Exception:
                pass
            art=MODELS_DIR/f"{exp_id}_{svc}_{re.sub(r'[^a-zA-Z0-9]+','_',name)}.pkl"
            art_path=''
            try:
                with art.open('wb') as f: pickle.dump(pipe,f)
                art_path=str(art.relative_to(ROOT))
            except Exception:
                pass
            res={'id':str(uuid.uuid4()),'service':svc,'model_name':name,'accuracy':round(accuracy_score(yte,pred),6),'precision_macro':round(precision_score(yte,pred,average='macro',zero_division=0),6),'recall_macro':round(recall_score(yte,pred,average='macro',zero_division=0),6),'f1_macro':round(f1_score(yte,pred,average='macro',zero_division=0),6),'f1_weighted':round(f1_score(yte,pred,average='weighted',zero_division=0),6),'mcc':round(matthews_corrcoef(yte,pred),6),'roc_auc':round(auc,6) if auc is not None else None,'train_seconds':round(time.time()-start_t,4),'artifact_path':art_path,'confusion_matrix':confusion_matrix(yte,pred,labels=labels).tolist(),'labels':labels,'train_rows':len(Xtr),'test_rows':len(Xte),'top_features':_top_model_features(pipe), **_binary_extra_metrics(yte,pred)}
            results.append(res)
        except Exception as e:
            results.append({'id':str(uuid.uuid4()),'service':svc,'model_name':name,'error':repr(e),'train_seconds':round(time.time()-start_t,4)})
    valid=[r for r in results if 'error' not in r]
    if not valid:
        return {'experiment':{'name':exp_name},'results':results,'best_by_service':{},'diagnostic':'No valid models. Check that the target has two classes and enough samples.'}
    best=sorted(valid,key=lambda r:(r.get('mcc') if r.get('mcc') is not None else -999,r.get('f1_macro') or 0,r.get('recall_macro') or 0),reverse=True)[0]
    best_by_service={svc:{'model':best['model_name'],'mcc':best.get('mcc'),'f1_macro':best.get('f1_macro'),'recall_macro':best.get('recall_macro')}}
    exp={'id':exp_id,'name':exp_name,'dataset_filename':f'{train_path.name} | {test_path.name}','target_column':'attack_flag','service_column':'service','rows_total':len(train_rows)+len(test_rows),'columns_total':len(fields),'test_size':0,'random_seed':random_seed,'created_at':now(),'best_model':best['model_name'],'best_by_service':best_by_service,'binary_training_file':train_path.name,'binary_test_file':test_path.name,'normal_training_file':normal_training_file.filename,'anomaly_training_file':anomaly_training_file.filename,'normal_test_file':normal_test_file.filename,'anomaly_test_file':anomaly_test_file.filename,'config':{'mode':'binary_external_train_test','service':svc,'model_profile':model_profile,'selected_models':list(models.keys()),'features_used':_engineered_feature_names(feature_fields),'raw_features_used':feature_fields,'features_excluded':excluded_fields,'feature_engineering':'Automatic text-derived indicators from detail and matched_log_line were added.','data_leakage_protection':'CAPEC, label and target-like fields are excluded from predictors for binary attack detection.','dataset_report':_dataset_summary_from_files(svc,nt,at,nv,av,fields,feature_fields,excluded_fields)}}
    _store_ml_experiment(exp,results)
    return {'experiment':exp,'results':results,'best_by_service':best_by_service,'binary_training_download':f'/api/download/ml_datasets/{train_path.name}','binary_test_download':f'/api/download/ml_datasets/{test_path.name}'}


@app.post('/api/ml/multi-binary-train')
async def ml_multi_binary_train(
    experiment_name:str=Form('multi_service_experiment'),
    random_seed:int=Form(42),
    services_json:str=Form('[]')
):
    """Run coordinated binary experiments for multiple services.

    Each service references four CSV paths already produced by Export Split ZIP.
    The endpoint stores one consolidated experiment with service-level results.
    """
    try:
        services=json.loads(services_json)
    except Exception:
        raise HTTPException(400,'Invalid services JSON')
    if not isinstance(services,list) or not services:
        raise HTTPException(400,'At least one service entry is required')
    # This lightweight coordinator records the requested services and returns a
    # clear message. Full file upload per-service is handled by the UI through the
    # single-service endpoint to avoid changing validated training logic.
    return {'message':'Multi-service experiment UI is enabled. Add service rows and run each service; consolidated reports are generated from Experiment History.','services':services,'experiment_name':experiment_name,'random_seed':random_seed}


@app.post('/api/ml/capec-multiclass-train')
async def ml_capec_multiclass_train(
    experiment_name:str=Form('CAPEC_multiclass_experiment'),
    random_seed:int=Form(42),
    test_size:float=Form(0.25),
    target_column:str=Form('capec_category'),
    model_profile:str=Form('balanced'),
    selected_models_json:str=Form(''),
    anomaly_files:List[UploadFile]=File(...)
):
    """Build and train a multiclass CAPEC attribution experiment.

    Input files must be clean anomaly CSVs. The endpoint concatenates a variable
    number of anomaly files, creates capec_multiclass_dataset.csv plus
    stratified training/test CSVs, excludes CAPEC label leakage fields from X,
    trains the selected classifiers, and stores metrics/reports in SQLite.
    """
    try:
        from sklearn.feature_extraction import DictVectorizer
        from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, matthews_corrcoef, confusion_matrix, roc_auc_score, balanced_accuracy_score
        from sklearn.model_selection import train_test_split
        from sklearn.pipeline import Pipeline
    except Exception as e:
        raise HTTPException(500,'Missing ML dependencies. Run deploy.sh to install scikit-learn. Detail: '+repr(e))
    if not anomaly_files:
        raise HTTPException(400,'Select at least one clean anomaly CSV file')
    random_seed=_positive_int(random_seed,'random seed',0,999999999)
    test_size=_positive_float(test_size,'test size',0.1,0.5)
    target_column=_safe_token(target_column or 'capec_category','target column','capec_category')
    if target_column not in {'capec_category','capec_id','attack_category_key'}:
        raise HTTPException(400,'Target column must be capec_category, capec_id or attack_category_key')
    all_fields=[]; all_rows=[]; source_files=[]
    for f in anomaly_files:
        rows,fields=await _read_ml_upload(f)
        source_files.append(f.filename or 'unknown.csv')
        for col in fields:
            if col not in all_fields:
                all_fields.append(col)
        all_rows.extend(rows)
    if target_column not in all_fields:
        raise HTTPException(400,f'Target column {target_column} was not found in the uploaded anomaly CSV files')
    # Keep only attack/anomaly rows with a non-empty CAPEC target.
    clean=[]
    for r in all_rows:
        y=(r.get(target_column) or '').strip()
        if not y:
            continue
        # A clean anomaly dataset may already contain only attack rows.  If
        # attack_flag is present, accept 1/true/anomaly and reject explicit 0.
        af=str(r.get('attack_flag','')).strip().lower()
        label=str(r.get('label','')).strip().lower()
        mode=str(r.get('mode','')).strip().lower()
        if af in {'0','false','normal'} or label == 'normal' or mode == 'normal':
            continue
        rr={f:r.get(f,'') for f in all_fields}
        clean.append(rr)
    if len(clean)<20:
        raise HTTPException(400,'At least 20 anomaly rows with CAPEC labels are required')
    classes=sorted(set((r.get(target_column) or '').strip() for r in clean if (r.get(target_column) or '').strip()))
    if len(classes)<2:
        raise HTTPException(400,'CAPEC multiclass training requires at least two CAPEC classes')
    feature_fields, excluded_fields = _capec_feature_fields(all_fields, target_column)
    if not feature_fields:
        raise HTTPException(400,'No usable features remain after CAPEC leakage-safe exclusions')
    ts=datetime.now().strftime('%Y%m%d_%H%M%S')
    exp_name=_normalize_experiment_name(experiment_name.strip(), f'capec_multiclass_{ts}')
    dataset_path=ML_DATASETS_DIR/f'capec_multiclass_dataset_{ts}.csv'
    train_path=ML_DATASETS_DIR/f'capec_multiclass_training_{ts}.csv'
    test_path=ML_DATASETS_DIR/f'capec_multiclass_test_{ts}.csv'
    # Preserve all original columns in exported multiclass CSVs for traceability.
    _write_rows_csv(dataset_path, all_fields, clean)
    y=[(r.get(target_column) or '').strip() for r in clean]
    try:
        train_rows,test_rows=train_test_split(clean,test_size=test_size,random_state=random_seed,stratify=y)
    except Exception:
        train_rows,test_rows=train_test_split(clean,test_size=test_size,random_state=random_seed)
    _write_rows_csv(train_path, all_fields, train_rows)
    _write_rows_csv(test_path, all_fields, test_rows)
    def make_X(rows):
        X=[]
        for r in rows:
            item={}
            for f in feature_fields:
                v=r.get(f,'')
                item[f]=_to_float(v) if _is_float(v) else (str(v).strip() if v is not None else '')
            item=_augment_ml_features(item, r)
            X.append(item)
        return X
    Xtr=make_X(train_rows); ytr=[(r.get(target_column) or '').strip() for r in train_rows]
    Xte=make_X(test_rows); yte=[(r.get(target_column) or '').strip() for r in test_rows]
    all_models=_model_suite(random_seed)
    requested_models=_selected_model_names(model_profile, selected_models_json)
    models={name:all_models[name] for name in requested_models if name in all_models}
    if not models:
        raise HTTPException(400,'No valid ML models selected')
    exp_id=str(uuid.uuid4())
    results=[]; labels=sorted(list(set(ytr)|set(yte)))
    for name,model in models.items():
        start_t=time.time()
        try:
            pipe=Pipeline([('vec',DictVectorizer(sparse=False)),('model',model)])
            pipe.fit(Xtr,ytr)
            pred=pipe.predict(Xte)
            auc=None
            try:
                proba=pipe.predict_proba(Xte)
                auc=roc_auc_score(yte,proba,multi_class='ovr',average='macro')
            except Exception:
                pass
            art=MODELS_DIR/f"{exp_id}_CAPEC_{re.sub(r'[^a-zA-Z0-9]+','_',name)}.pkl"
            art_path=''
            try:
                with art.open('wb') as fh: pickle.dump(pipe,fh)
                art_path=str(art.relative_to(ROOT))
            except Exception:
                pass
            res={'id':str(uuid.uuid4()),'service':'CAPEC','model_name':name,
                 'accuracy':round(accuracy_score(yte,pred),6),
                 'precision_macro':round(precision_score(yte,pred,average='macro',zero_division=0),6),
                 'recall_macro':round(recall_score(yte,pred,average='macro',zero_division=0),6),
                 'f1_macro':round(f1_score(yte,pred,average='macro',zero_division=0),6),
                 'f1_weighted':round(f1_score(yte,pred,average='weighted',zero_division=0),6),
                 'mcc':round(matthews_corrcoef(yte,pred),6),
                 'balanced_accuracy':round(balanced_accuracy_score(yte,pred),6),
                 'roc_auc':round(auc,6) if auc is not None else None,
                 'train_seconds':round(time.time()-start_t,4),'artifact_path':art_path,
                 'confusion_matrix':confusion_matrix(yte,pred,labels=labels).tolist(),'labels':labels,
                 'train_rows':len(Xtr),'test_rows':len(Xte),'top_features':_top_model_features(pipe)}
            results.append(res)
        except Exception as e:
            results.append({'id':str(uuid.uuid4()),'service':'CAPEC','model_name':name,'error':repr(e),'train_seconds':round(time.time()-start_t,4)})
    valid=[r for r in results if 'error' not in r]
    if not valid:
        return {'experiment':{'name':exp_name},'results':results,'best_by_service':{},'diagnostic':'No valid CAPEC models. Check class distribution and feature values.'}
    best=sorted(valid,key=lambda r:(r.get('mcc') if r.get('mcc') is not None else -999, r.get('f1_macro') or 0, r.get('balanced_accuracy') or 0),reverse=True)[0]
    distribution_all=_capec_distribution(clean,target_column)
    distribution_train=_capec_distribution(train_rows,target_column)
    distribution_test=_capec_distribution(test_rows,target_column)
    best_by_service={'CAPEC':{'model':best['model_name'],'mcc':best.get('mcc'),'f1_macro':best.get('f1_macro'),'recall_macro':best.get('recall_macro'),'balanced_accuracy':best.get('balanced_accuracy')}}
    exp={'id':exp_id,'name':exp_name,'dataset_filename':f'{dataset_path.name} | {train_path.name} | {test_path.name}',
         'target_column':target_column,'service_column':'service','rows_total':len(clean),'columns_total':len(all_fields),
         'test_size':test_size,'random_seed':random_seed,'created_at':now(),'best_model':best['model_name'],'best_by_service':best_by_service,
         'capec_dataset_file':dataset_path.name,'capec_training_file':train_path.name,'capec_test_file':test_path.name,
         'source_files':source_files,
         'config':{'mode':'capec_multiclass_external','target_column':target_column,'model_profile':model_profile,
                   'selected_models':list(models.keys()),'source_files':source_files,
                   'features_used':_engineered_feature_names(feature_fields),'raw_features_used':feature_fields,
                   'features_excluded':excluded_fields,
                   'feature_engineering':'Automatic text-derived indicators from detail and matched_log_line were added.',
                   'data_leakage_protection':'CAPEC target and alternate CAPEC label fields are excluded from predictors for multiclass attribution.',
                   'dataset_report':{'task':'CAPEC multiclass classification','rows_total':len(clean),'training_rows':len(train_rows),'test_rows':len(test_rows),'classes':classes,'class_count':len(classes),'distribution_all':distribution_all,'distribution_training':distribution_train,'distribution_test':distribution_test,'features_count':len(feature_fields)}}}
    _store_ml_experiment(exp,results)
    return {'experiment':exp,'results':results,'best_by_service':best_by_service,
            'capec_dataset_download':f'/api/download/ml_datasets/{dataset_path.name}',
            'capec_training_download':f'/api/download/ml_datasets/{train_path.name}',
            'capec_test_download':f'/api/download/ml_datasets/{test_path.name}',
            'distribution':distribution_all}


# ---------------------------------------------------------------------------
# Full-service research orchestration (v0.6)
# ---------------------------------------------------------------------------
RESEARCH_PORT_PLAN = [
    ("http",80,"normal"),("http",81,"anomaly"),
    ("ftp",2121,"normal"),("ftp",2122,"anomaly"),
    ("ssh",2222,"normal"),("ssh",2223,"anomaly"),
    ("smtp",25,"normal"),("smtp",2525,"anomaly"),
    ("imap",143,"normal"),("imap",1143,"anomaly"),
    ("postgresql",5433,"normal"),("postgresql",5434,"anomaly"),
    ("rest_api",8000,"normal"),("rest_api",8001,"anomaly"),
    ("smb",445,"normal"),("smb",1445,"anomaly"),
    ("wireguard_ui",51821,"normal"),("wireguard_ui",51823,"anomaly"),
]
RESEARCH_FAMILIES={"http","ftp","ssh","mail","postgresql","rest_api","smb","wireguard"}

def _research_family(service):
    if service in {"smtp","imap"}: return "mail"
    if service=="wireguard_ui": return "wireguard"
    return service

def _research_credentials(service, mode, capec="benign"):
    d=_service_profile_defaults(service, mode, capec)
    return d.get('username',''),d.get('password',''),d.get('path','/')

def _research_actions(req:ResearchCampaignReq):
    host=_reject_dangerous(req.host,'research host',255)
    nd=_positive_int(req.normal_duration_seconds,'normal duration',10,86400)
    ad=_positive_int(req.anomaly_duration_seconds,'anomaly duration',10,86400)
    reps=_positive_int(req.repetitions,'repetitions',1,20)
    conc=_positive_int(req.concurrency,'concurrency',1,64)
    nr=_positive_float(req.normal_rate_per_second,'normal rate',0.01,1000)
    ar=_positive_float(req.anomaly_rate_per_second,'anomaly rate',0.01,1000)
    requested=set(req.include_capec_categories or [])
    actions=[]
    for service,port,kind in RESEARCH_PORT_PLAN:
        if kind=='normal':
            cats=['benign']
        else:
            cats=[c for c in CAPEC_BY_SERVICE.get(service,['resource_depletion']) if not requested or c in requested]
        for rep in range(1,reps+1):
            for cat in cats:
                user,pwd,path=_research_credentials(service,'normal' if kind=='normal' else 'anomaly',cat)
                actions.append({
                    'target_name':f'{service}-{kind}-{port}','host':host,'port':port,'service':service,
                    'mode':'normal' if kind=='normal' else 'anomaly','attack_category':cat,
                    'duration_seconds':nd if kind=='normal' else ad,
                    'rate_per_second':nr if kind=='normal' else ar,
                    'concurrency':conc,'path':path or '/','username':user,'password':pwd,
                    'dns_query':'example.com','payload':'','profile_name':f'research_{service}_{kind}_{cat}_r{rep}'
                })
    return actions

@app.get('/api/research/readiness')
def research_readiness(host:str='100.10.10.3', timeout_seconds:float=0.7):
    timeout=max(.05,min(float(timeout_seconds),3.0)); checks=[]
    for service,port,kind in RESEARCH_PORT_PLAN:
        reachable=_tcp_open(host,port,timeout)
        checks.append({'family':_research_family(service),'service':service,'mode':kind,'host':host,'port':port,'reachable':reachable})
    family={}
    for x in checks:
        family.setdefault(x['family'],{'normal':False,'anomaly':False,'checks':[]})
        family[x['family']][x['mode']]=family[x['family']][x['mode']] or x['reachable']
        family[x['family']]['checks'].append(x)
    complete=all(v['normal'] and v['anomaly'] for v in family.values()) and RESEARCH_FAMILIES.issubset(family)
    return {'host':host,'complete':complete,'families':family,'checks':checks,'required_families':sorted(RESEARCH_FAMILIES)}

@app.post('/api/research/full-campaign')
def research_full_campaign(req:ResearchCampaignReq):
    readiness=research_readiness(req.host)
    if req.require_complete_coverage and not readiness['complete']:
        missing=[f for f,v in readiness['families'].items() if not (v['normal'] and v['anomaly'])]
        raise HTTPException(409,'Full-service coverage is incomplete: '+', '.join(missing))
    actions=_research_actions(req)
    group=CampaignGroup(name=_reject_dangerous(req.name,'campaign name',160),actions=[CampaignAction(**a) for a in actions],execute_now=bool(req.launch),notes='CAUSALIS v0.6 full-service research campaign: 8 paired service families, CAPEC-ground-truth actions, sequential reproducible execution.')
    gid=str(uuid.uuid4())
    estimate=sum(a.duration_seconds for a in group.actions)
    result={'campaign_group_id':gid,'name':group.name,'actions':len(actions),'estimated_seconds':estimate,'estimated_hours':round(estimate/3600,2),'readiness':readiness,'group_payload':group.model_dump(),'launched':False}
    if req.launch:
        threading.Thread(target=group_worker,args=(gid,group),daemon=True).start(); result['launched']=True
    else:
        history_upsert({'id':gid,'name':group.name,'status':'draft','created_at':now(),'started_at':None,'finished_at':None,'scheduled_start':'','scheduled_start_epoch':None,'execute_now':False,'notes':group.notes,'actions_total':len(actions),'actions_finished':0,'child_campaigns':[],'progress_pct':0,'group_payload':group.model_dump()})
    record_experiment_activity('research_campaign','created',f'Full-service research campaign {group.name} prepared',metadata={'campaign_group_id':gid,'actions':len(actions),'estimated_seconds':estimate})
    return result


def _guess_evidence_identity(filename:str):
    n=filename.lower().replace('-','_')
    service=None
    aliases=[('rest_api',['rest','fastapi','api']),('postgresql',['postgres','postgresql','db']),('wireguard_ui',['wireguard','wireguard_ui','vpn','wg']),('smb',['smb','samba']),('imap',['imap','dovecot']),('smtp',['smtp','postfix','mail']),('http',['http','dvwa','mitmproxy','apache']),('ssh',['ssh','auth']),('ftp',['ftp','vsftpd'])]
    for svc,words in aliases:
        if any(w in n for w in words): service=svc; break
    kind='normal' if any(w in n for w in ['normalidad','normal','benign']) else ('anomaly' if any(w in n for w in ['pentesting','attack','anomaly','malicious']) else 'all')
    return service,kind

@app.post('/api/research/evidence-batch')
async def research_evidence_batch(evidence_zip:UploadFile=File(...), window_seconds:int=Form(8), remove_unmatched:bool=Form(False), drop_duplicates:bool=Form(True)):
    if not (evidence_zip.filename or '').lower().endswith('.zip'):
        raise HTTPException(400,'Upload a ZIP containing service logs')
    raw=await evidence_zip.read()
    if not raw or len(raw)>2_000_000_000: raise HTTPException(400,'Evidence ZIP is empty or exceeds 2 GB')
    window=_positive_int(window_seconds,'matching window',1,3600)
    batch_id=datetime.now().strftime('%Y%m%d_%H%M%S'); batch_dir=UPLOADS/f'evidence_{batch_id}'; batch_dir.mkdir(parents=True,exist_ok=True)
    results=[]; clean_files=[]
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        for info in z.infolist():
            if info.is_dir() or info.file_size>250_000_000: continue
            service,kind=_guess_evidence_identity(info.filename)
            if not service: continue
            text=z.read(info).decode('utf-8',errors='ignore')
            m=build_match(service,kind,window,text)
            matched_path=MATCHED_DIR/m['file']
            rows,fields,_=_read_csv_text(matched_path.read_text(encoding='utf-8',errors='ignore'))
            out_rows=[]; seen=set()
            for r in rows:
                if remove_unmatched and str(r.get('matched','')).lower() not in {'true','1'}: continue
                key=tuple(r.get(f,'') for f in fields)
                if drop_duplicates and key in seen: continue
                seen.add(key); out_rows.append(r)
            out=CLEAN_DIR/f'clean_{service}_{kind}_{batch_id}.csv'; _write_rows_csv(out,fields,out_rows)
            clean_files.append(out)
            results.append({'source':info.filename,'service':service,'kind':kind,**m,'clean_file':out.name,'clean_rows':len(out_rows)})
    if not results: raise HTTPException(400,'No recognizable service log files were found. Include service and normal/pentesting in filenames.')
    manifest={'batch_id':batch_id,'created_at':now(),'window_seconds':window,'files':results,'coverage':sorted(set((r['service'],r['kind']) for r in results))}
    manifest_path=batch_dir/'evidence_manifest.json'; manifest_path.write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding='utf-8')
    record_experiment_activity('evidence','completed',f'Batch evidence import {batch_id} completed',metadata={'files':len(results),'clean_files':len(clean_files)})
    return manifest

@app.get('/api/research/reproducibility-package')
def research_reproducibility_package():
    stamp=datetime.now().strftime('%Y%m%d_%H%M%S'); out=EXP/f'causalis_research_package_{stamp}.zip'
    include=[EVENTS,DB_PATH,TARGETS,PROFILES,CAMPAIGN_HISTORY]
    include += list(MATCHED_DIR.glob('*.csv'))+list(CLEAN_DIR.glob('*.csv'))+list(SPLIT_DIR.glob('*'))+list(ML_DATASETS_DIR.glob('*.csv'))+list(ML_REPORTS_DIR.glob('*'))
    with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
        for f in include:
            if f.exists() and f.is_file(): z.write(f,f.relative_to(ROOT))
        manifest={'product':PRODUCT_NAME,'version':PRODUCT_VERSION,'generated_at':now(),'files':[str(f.relative_to(ROOT)) for f in include if f.exists() and f.is_file()]}
        z.writestr('research_manifest.json',json.dumps(manifest,indent=2,ensure_ascii=False))
    return FileResponse(out,filename=out.name,media_type='application/zip')

@app.get("/api/ml/experiments")
def ml_experiments():
    with _db_lock, db_conn() as con:
        rows=con.execute("SELECT id,name,created_at,target_column,rows_total,columns_total,best_model,best_service_summary FROM ml_experiments ORDER BY created_at DESC LIMIT 100").fetchall()
    return [dict(r) for r in rows]

@app.post("/api/ml/train")
def ml_train(req:MLTrainReq):
    try:
        from sklearn.compose import ColumnTransformer
        from sklearn.feature_extraction import DictVectorizer
        from sklearn.impute import SimpleImputer
        from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, matthews_corrcoef, confusion_matrix, roc_auc_score
        from sklearn.model_selection import train_test_split
        from sklearn.pipeline import Pipeline
        from sklearn.preprocessing import StandardScaler, LabelEncoder
        from sklearn.tree import DecisionTreeClassifier
        from sklearn.ensemble import RandomForestClassifier
        from sklearn.neighbors import KNeighborsClassifier
        from sklearn.naive_bayes import GaussianNB
        from sklearn.linear_model import LogisticRegression
        from sklearn.svm import SVC
    except Exception as e:
        raise HTTPException(500,"Missing ML dependencies. Run deploy.sh to install scikit-learn. Detail: "+repr(e))
    src,rows,fields=_read_uploaded_dataset(req.upload_id)
    if req.target_column not in fields:
        raise HTTPException(400,"The target variable does not exist in the CSV")
    # Prevent data leakage in ad-hoc binary experiments too.
    if str(req.target_column).lower() == 'attack_flag':
        feature_fields, excluded_fields = _binary_feature_fields(fields)
    else:
        feature_fields=[f for f in fields if f!=req.target_column]
        excluded_fields=[req.target_column]
    if not feature_fields:
        raise HTTPException(400,"The dataset does not contain input features")
    clean=[]
    for r in rows:
        y=(r.get(req.target_column) or '').strip()
        if y!='': clean.append(r)
    if len(clean)<10:
        raise HTTPException(400,"At least 10 rows with non-empty target are required")
    req.test_size=_positive_float(req.test_size,"test size",0.1,0.5)
    req.random_seed=_positive_int(req.random_seed,"random seed",0,999999999)
    exp_id=str(uuid.uuid4())
    exp_name=_normalize_experiment_name(req.experiment_name.strip(), f"experiment_{datetime.now().strftime('%Y%m%d_%H%M%S')}")
    # subconjuntos: global y por servicio si existe columna
    groups={"ALL":clean}
    if req.group_by_service and req.service_column in fields:
        sv={}
        for r in clean:
            sv.setdefault((r.get(req.service_column) or 'desconocido').strip() or 'desconocido',[]).append(r)
        for k,v in sv.items():
            if len(v)>=10 and len(set((x.get(req.target_column) or '').strip() for x in v))>=2:
                groups[k]=v
    models=_model_suite(req.random_seed)
    results=[]; best_by_service={}
    for svc,grows in groups.items():
        y=[(r.get(req.target_column) or '').strip() for r in grows]
        if len(set(y))<2: continue
        X=[]
        for r in grows:
            item={}
            for f in feature_fields:
                if f==req.service_column and svc!='ALL':
                    continue
                v=r.get(f,'')
                item[f]=_to_float(v) if _is_float(v) else (str(v).strip() if v is not None else '')
            item=_augment_ml_features(item, r)
            X.append(item)
        try:
            Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=max(0.1,min(req.test_size,0.5)),random_state=req.random_seed,stratify=y)
        except Exception:
            Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=max(0.1,min(req.test_size,0.5)),random_state=req.random_seed)
        vec=DictVectorizer(sparse=False)
        for name,model in models.items():
            start_t=time.time()
            pipe=Pipeline([('vec',vec),('model',model)])
            try:
                pipe.fit(Xtr,ytr)
                pred=pipe.predict(Xte)
                proba=None
                try: proba=pipe.predict_proba(Xte)
                except Exception: proba=None
                labels=sorted(list(set(yte)|set(pred)))
                auc=None
                if proba is not None:
                    try:
                        if len(labels)==2:
                            auc=roc_auc_score(yte,proba[:,1])
                        else:
                            auc=roc_auc_score(yte,proba,multi_class='ovr',average='macro')
                    except Exception:
                        auc=None
                art=MODELS_DIR/f"{exp_id}_{re.sub(r'[^a-zA-Z0-9]+','_',svc)}_{re.sub(r'[^a-zA-Z0-9]+','_',name)}.pkl"
                try:
                    with art.open('wb') as f: pickle.dump(pipe,f)
                    art_path=str(art.relative_to(ROOT))
                except Exception:
                    art_path=''
                res={"id":str(uuid.uuid4()),"service":svc,"model_name":name,"accuracy":round(accuracy_score(yte,pred),6),"precision_macro":round(precision_score(yte,pred,average='macro',zero_division=0),6),"recall_macro":round(recall_score(yte,pred,average='macro',zero_division=0),6),"f1_macro":round(f1_score(yte,pred,average='macro',zero_division=0),6),"f1_weighted":round(f1_score(yte,pred,average='weighted',zero_division=0),6),"mcc":round(matthews_corrcoef(yte,pred),6),"roc_auc":round(auc,6) if auc is not None else None,"train_seconds":round(time.time()-start_t,4),"artifact_path":art_path,"confusion_matrix":confusion_matrix(yte,pred,labels=labels).tolist(),"labels":labels,"train_rows":len(Xtr),"test_rows":len(Xte),"top_features":_top_model_features(pipe)}
                results.append(res)
            except Exception as e:
                results.append({"id":str(uuid.uuid4()),"service":svc,"model_name":name,"error":repr(e),"train_seconds":round(time.time()-start_t,4)})
        valid=[r for r in results if r.get('service')==svc and 'error' not in r]
        if valid:
            best=sorted(valid,key=lambda r:(r.get('mcc') if r.get('mcc') is not None else -999, r.get('f1_macro') or 0, r.get('recall_macro') or 0),reverse=True)[0]
            best_by_service[svc]={"model":best['model_name'],"mcc":best.get('mcc'),"f1_macro":best.get('f1_macro'),"recall_macro":best.get('recall_macro')}
    best_global=best_by_service.get('ALL',{})
    exp={"id":exp_id,"name":exp_name,"dataset_filename":src.name,"target_column":req.target_column,"service_column":req.service_column,"rows_total":len(clean),"columns_total":len(fields),"test_size":req.test_size,"random_seed":req.random_seed,"created_at":now(),"best_model":best_global.get('model',''),"best_by_service":best_by_service,"config":{**req.model_dump(),"features_used":feature_fields,"features_excluded":excluded_fields}}
    _store_ml_experiment(exp, results)
    return {"experiment":exp,"results":results,"best_by_service":best_by_service}





@app.post('/api/match/window-advisor')
async def temporal_window_advisor(service:str=Form(...), dataset_kind:str=Form('all'), log_file:UploadFile=File(...)):
    """Evaluate candidate correlation windows and recommend the best trade-off.

    The advisor supports methodological justification of the selected temporal
    window by comparing match rate and ambiguity across several candidates.
    """
    raw=await log_file.read()
    if len(raw) > 120_000_000:
        raise HTTPException(400,'The log file is too large; maximum supported size is 120 MB')
    if not raw:
        raise HTTPException(400,'The log file is empty')
    text=raw.decode('utf-8',errors='ignore')
    svc=_safe_token(service,'service'); kind=_safe_token(dataset_kind,'dataset kind')
    with _db_lock, db_conn() as con:
        events=[dict(r) for r in con.execute("SELECT * FROM events WHERE service=?"+(" AND mode=?" if kind in ('normal','anomaly') else "")+" ORDER BY timestamp_epoch", ((svc,kind) if kind in ('normal','anomaly') else (svc,))).fetchall()]
    logs=[]
    for line in text.splitlines():
        ts=log_time(line)
        if ts: logs.append({'ts':ts,'line':line})
    candidates=[0.5,1,2,3,5,10,15]
    rows=[]
    for w in candidates:
        matched=ambiguous=0; used_logs={}
        for e in events:
            ets=float(e.get('timestamp_epoch') or 0)
            hits=[i for i,l in enumerate(logs) if abs(ets-l['ts'])<=w]
            if hits:
                matched+=1
                if len(hits)>1: ambiguous+=1
                used_logs[hits[0]]=used_logs.get(hits[0],0)+1
        dup=sum(1 for v in used_logs.values() if v>1)
        rate=matched/len(events) if events else 0
        ambiguity_ratio=ambiguous/matched if matched else 0
        cpi=rate-(ambiguity_ratio*0.25)-(dup/max(1,matched)*0.15)
        rows.append({'window_seconds':w,'events':len(events),'matched':matched,'match_rate':round(rate,6),'ambiguous_matches':ambiguous,'duplicate_correlations':dup,'cpi':round(cpi,6)})
    rec=max(rows,key=lambda r:r['cpi']) if rows else None
    return {'service':svc,'dataset_kind':kind,'log_lines':len(logs),'candidates':rows,'recommended':rec}

# ---------------------------------------------------------------------------
# Intelligent Mode

@app.post('/api/match/window-advisor')
async def temporal_window_advisor(service:str=Form(...), dataset_kind:str=Form('all'), log_file:UploadFile=File(...)):
    """Evaluate candidate correlation windows and recommend the best trade-off.

    The advisor supports methodological justification of the selected temporal
    window by comparing match rate and ambiguity across several candidates.
    """
    raw=await log_file.read()
    if len(raw) > 120_000_000:
        raise HTTPException(400,'The log file is too large; maximum supported size is 120 MB')
    if not raw:
        raise HTTPException(400,'The log file is empty')
    text=raw.decode('utf-8',errors='ignore')
    svc=_safe_token(service,'service'); kind=_safe_token(dataset_kind,'dataset kind')
    with _db_lock, db_conn() as con:
        events=[dict(r) for r in con.execute("SELECT * FROM events WHERE service=?"+(" AND mode=?" if kind in ('normal','anomaly') else "")+" ORDER BY timestamp_epoch", ((svc,kind) if kind in ('normal','anomaly') else (svc,))).fetchall()]
    logs=[]
    for line in text.splitlines():
        ts=log_time(line)
        if ts: logs.append({'ts':ts,'line':line})
    candidates=[0.5,1,2,3,5,10,15]
    rows=[]
    for w in candidates:
        matched=ambiguous=0; used_logs={}
        for e in events:
            ets=float(e.get('timestamp_epoch') or 0)
            hits=[i for i,l in enumerate(logs) if abs(ets-l['ts'])<=w]
            if hits:
                matched+=1
                if len(hits)>1: ambiguous+=1
                used_logs[hits[0]]=used_logs.get(hits[0],0)+1
        dup=sum(1 for v in used_logs.values() if v>1)
        rate=matched/len(events) if events else 0
        ambiguity_ratio=ambiguous/matched if matched else 0
        cpi=rate-(ambiguity_ratio*0.25)-(dup/max(1,matched)*0.15)
        rows.append({'window_seconds':w,'events':len(events),'matched':matched,'match_rate':round(rate,6),'ambiguous_matches':ambiguous,'duplicate_correlations':dup,'cpi':round(cpi,6)})
    rec=max(rows,key=lambda r:r['cpi']) if rows else None
    return {'service':svc,'dataset_kind':kind,'log_lines':len(logs),'candidates':rows,'recommended':rec}

# ---------------------------------------------------------------------------
# Intelligent Mode is isolated from the validated manual workflow. It discovers
# active hosts and open ports inside a private lab range, then produces editable
# targets, profiles and a campaign proposal. Manual target/profile/campaign
# generation remains unchanged.
# Generic service fingerprinting registry. Port pairs used by controlled cyber ranges are supported as presets, while all discovered targets remain editable and infrastructure-agnostic.
SERVICE_CATALOG={
    'http':{'label':'HTTP / Web','ports':[80,81,8080,443,8443],'normal_actions':['navigation','login','forms'],'capec':['abuse_of_functionality','resource_depletion','data_leakage','injection','time_and_state']},
    'rest_api':{'label':'REST API','ports':[8000,8001],'normal_actions':['resource listing','API documentation','CRUD requests'],'capec':['abuse_of_functionality','resource_depletion','data_leakage','subverting_authentication','injection']},
    'ftp':{'label':'FTP','ports':[21,2121,2122],'normal_actions':['login','directory listing','transfer'],'capec':['abuse_of_functionality','data_leakage','subverting_authentication','probabilistic_techniques']},
    'ssh':{'label':'SSH','ports':[22,2222,2223],'normal_actions':['login','commands','transfer'],'capec':['resource_depletion','subverting_authentication','probabilistic_techniques']},
    'smtp':{'label':'SMTP','ports':[25,2525,587,1587],'normal_actions':['send mail'],'capec':['abuse_of_functionality','resource_depletion','spoofing']},
    'imap':{'label':'IMAP','ports':[143,1143,993,1993],'normal_actions':['login','list mailboxes','read mailbox'],'capec':['abuse_of_functionality','data_leakage','subverting_authentication','probabilistic_techniques']},
    'smb':{'label':'SMB','ports':[445,1445],'normal_actions':['authenticate','list shares'],'capec':['data_leakage','subverting_authentication','probabilistic_techniques','resource_depletion']},
    'postgresql':{'label':'PostgreSQL','ports':[5432,5433,5434],'normal_actions':['connect','query','transaction'],'capec':['data_leakage','subverting_authentication','probabilistic_techniques','injection']},
    'wireguard_ui':{'label':'WireGuard Management UI','ports':[51821,51823],'normal_actions':['status page'],'capec':['abuse_of_functionality','resource_depletion','subverting_authentication']},
    'dns':{'label':'DNS','ports':[53],'normal_actions':['resolve'],'capec':['spoofing','resource_depletion','data_leakage']},
    'ldap':{'label':'LDAP','ports':[389,636],'normal_actions':['bind','search'],'capec':['subverting_authentication','data_leakage']},
    'rdp':{'label':'RDP','ports':[3389],'normal_actions':['connect'],'capec':['subverting_authentication','resource_depletion']},
    'mysql':{'label':'MySQL','ports':[3306],'normal_actions':['connect','query'],'capec':['data_leakage','subverting_authentication','injection']},
    'tcp':{'label':'Generic TCP','ports':[],'normal_actions':['connect'],'capec':['resource_depletion']},
    'portainer':{'label':'Portainer','ports':[9000],'normal_actions':['status page'],'capec':['abuse_of_functionality','resource_depletion']}
}

SERVICE_BY_PORT={port:service for service,meta in SERVICE_CATALOG.items() for port in meta.get('ports',[])}
SERVICE_BY_PORT.update({23:'tcp',2323:'tcp'})
HONEynet_TRAFFIC_KIND_BY_PORT={
    80:'normal',81:'anomaly',2121:'normal',2122:'anomaly',2222:'normal',2223:'anomaly',
    25:'normal',2525:'anomaly',587:'normal',1587:'anomaly',143:'normal',1143:'anomaly',
    993:'normal',1993:'anomaly',445:'normal',1445:'anomaly',5433:'normal',5434:'anomaly',
    8000:'normal',8001:'anomaly',51821:'normal',51823:'anomaly'
}
CAPEC_BY_SERVICE={service:list(meta.get('capec',[])) for service,meta in SERVICE_CATALOG.items()}

SERVICE_DEFAULTS={
    ('ftp','normal'):{'username':'ftpuser','password':'password'},
    ('ftp','anomaly_valid'):{'username':'ftpuser','password':'password'},
    ('ftp','anomaly_invalid'):{'username':'root','password':'invalid'},
    ('ssh','normal'):{'username':'root','password':'password'},
    ('ssh','anomaly_valid'):{'username':'root','password':'password'},
    ('ssh','anomaly_invalid'):{'username':'root','password':'invalid'},
    ('imap','normal'):{'username':'usuario1@normalidad.tics','password':'password'},
    ('imap','anomaly_valid'):{'username':'usuario1@pentesting.tics','password':'password'},
    ('imap','anomaly_invalid'):{'username':'usuario1@pentesting.tics','password':'invalid'},
    ('postgresql','normal'):{'username':'myuser','password':'mypassword'},
    ('postgresql','anomaly_valid'):{'username':'myuser','password':'mypassword'},
    ('postgresql','anomaly_invalid'):{'username':'myuser','password':'invalid'},
    ('smb','normal'):{'username':'user','password':'password'},
    ('smb','anomaly_valid'):{'username':'user','password':'password'},
    ('smb','anomaly_invalid'):{'username':'administrator','password':'invalid'},
    ('rest_api','normal'):{'path':'/'},('rest_api','anomaly_valid'):{'path':'/'},('rest_api','anomaly_invalid'):{'path':'/token'},
    ('wireguard_ui','normal'):{'path':'/'},('wireguard_ui','anomaly_valid'):{'path':'/'},('wireguard_ui','anomaly_invalid'):{'path':'/api/session'}
}

def _service_profile_defaults(service:str, mode:str, capec:str='benign')->Dict[str,str]:
    if mode=='normal':
        return dict(SERVICE_DEFAULTS.get((service,'normal'),{}))
    auth_failure=capec in ('subverting_authentication','probabilistic_techniques')
    key='anomaly_invalid' if auth_failure else 'anomaly_valid'
    return dict(SERVICE_DEFAULTS.get((service,key),{}))


def _parse_ports(value:str)->List[int]:
    ports=[]
    for part in str(value or "").split(','):
        part=part.strip()
        if not part: continue
        if '-' in part:
            a,b=part.split('-',1)
            a=_positive_int(a,'port',1,65535); b=_positive_int(b,'port',1,65535)
            if b<a: raise HTTPException(400,'Invalid port range')
            ports.extend(range(a,min(b,65535)+1))
        else:
            ports.append(_positive_int(part,'port',1,65535))
    return sorted(set(ports))[:512]

def _validate_private_network(cidr:str, allow_non_private: bool = False):
    raw=_reject_dangerous(cidr,'IP range',80)
    try:
        net=ipaddress.ip_network(raw, strict=False)
    except Exception:
        raise HTTPException(400,'Invalid IP range. Use CIDR format, e.g. 192.168.1.0/24')
    if not (net.is_private or net.is_loopback) and not allow_non_private:
        raise HTTPException(400, 'This range is not private by default. Allowed ranges: 10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16, 127.0.0.0/8. Enable Allow Non-RFC1918 Lab Networks only for controlled lab ranges such as 100.10.10.0/24.')
    if net.num_addresses>1024:
        raise HTTPException(400,'Range too large. Use /22 or smaller for controlled lab discovery, or split the lab into smaller CIDR ranges')
    return net

def _tcp_open(host:str, port:int, timeout:float)->bool:
    try:
        with socket.create_connection((host,port),timeout=timeout):
            return True
    except Exception:
        return False

def _profile_templates_for_target(t:Dict[str,Any], objective:str="research_dataset")->List[Dict[str,Any]]:
    """Build service-aware profiles for Intelligent Mode.

    Normality honeynet ports receive only normal profiles. Pentesting ports
    receive a broader CAPEC coverage so generated campaigns are useful for
    research datasets and not only quick smoke tests.
    """
    service=t['service']; port=int(t['port']); host_token=t['host'].replace('.','_')
    traffic_kind=t.get('traffic_kind') or HONEynet_TRAFFIC_KIND_BY_PORT.get(port,'unknown')
    if objective=='quick_validation':
        normal_dur, attack_dur, repeat = 60, 45, 1
    elif objective=='large_balanced_dataset':
        normal_dur, attack_dur, repeat = 900, 600, 3
    else:
        normal_dur, attack_dur, repeat = 300, 240, 2
    normal_defaults=_service_profile_defaults(service,'normal')
    base={"service":service,"port":port,"duration_seconds":normal_dur,"rate_per_second":1,"concurrency":1,"path":normal_defaults.get('path','/'),"username":normal_defaults.get('username',''),"password":normal_defaults.get('password',''),"dns_query":"example.com","payload":"","description":"Generated by CAUSALIS generic service adapter"}
    profiles=[]
    if traffic_kind in ('normal','unknown'):
        profiles.append({**base,"name":f"auto_{service}_{host_token}_{port}_normal","mode":"normal","attack_category":"benign","description":"Normal profile generated from service fingerprinting"})
    if traffic_kind in ('anomaly','unknown'):
        for capec in CAPEC_BY_SERVICE.get(service,["resource_depletion"]):
            anomaly_defaults=_service_profile_defaults(service,'anomaly',capec)
            profiles.append({**base,"name":f"auto_{service}_{host_token}_{port}_{capec}","mode":"anomaly","attack_category":capec,"duration_seconds":attack_dur,"rate_per_second":3 if capec=='resource_depletion' else 1,"concurrency":3 if capec in ('resource_depletion','probabilistic_techniques') else 1,"path":anomaly_defaults.get('path',base.get('path','/')),"username":anomaly_defaults.get('username',''),"password":anomaly_defaults.get('password',''),"description":f"CAPEC-oriented profile generated by the {service} adapter"})
    # Duplicate profile templates with deterministic suffixes for long research campaigns.
    expanded=[]
    for p in profiles:
        expanded.append(p)
        for i in range(1, repeat):
            cp=dict(p); cp['name']=f"{p['name']}_r{i+1}"; expanded.append(cp)
    return expanded

def _action_from_target_profile(t:Dict[str,Any], p:Dict[str,Any])->Dict[str,Any]:
    return {"target_name":t['name'],"host":t['host'],"port":t['port'],"service":t['service'],"mode":p['mode'],"attack_category":p.get('attack_category','benign'),"duration_seconds":p.get('duration_seconds',60),"rate_per_second":p.get('rate_per_second',1),"concurrency":p.get('concurrency',1),"path":p.get('path','/'),"username":p.get('username',''),"password":p.get('password',''),"dns_query":p.get('dns_query','example.com'),"payload":p.get('payload',''),"profile_name":p['name']}

@app.post('/api/intelligent/scan')
def intelligent_scan(req:IntelligentScanReq):
    """Discover hosts and generate a research-oriented campaign proposal.

    The scan uses bounded parallel TCP connect checks. It does not perform any
    exploit activity; it only detects reachable services in authorized lab ranges.
    """
    net=_validate_private_network(req.ip_range, req.allow_non_private)
    ports=_parse_ports(req.ports)
    timeout=max(0.05,min(float(req.timeout_seconds or 0.35),3.0))
    max_workers=max(1,min(int(req.max_workers or 48),128))
    hosts=[str(ip) for ip in net.hosts()]
    discovered_map={h:[] for h in hosts}
    def check(pair):
        host,port=pair
        if _tcp_open(host,port,timeout):
            return host,{"port":port,"service":SERVICE_BY_PORT.get(port,'tcp'),"traffic_kind":HONEynet_TRAFFIC_KIND_BY_PORT.get(port,'unknown')}
        return None
    tasks=[(h,p) for h in hosts for p in ports]
    # Run discovery concurrently so /24 lab ranges complete in a reasonable time.
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as ex:
        for result in ex.map(check, tasks):
            if result:
                host,op=result
                discovered_map.setdefault(host,[]).append(op)
    discovered=[{"host":h,"open_ports":sorted(ops,key=lambda x:x['port'])} for h,ops in discovered_map.items() if ops]
    targets=[]; profiles=[]; actions=[]
    normal_actions=attack_actions=0
    for h in discovered:
        for op in h['open_ports']:
            service=op['service']; port=op['port']; kind=op.get('traffic_kind','unknown')
            suffix = 'normal' if kind=='normal' else ('anomaly' if kind=='anomaly' else 'lab')
            t={"id":str(uuid.uuid4()),"name":f"auto_{service}_{h['host'].replace('.','_')}_{port}_{suffix}","host":h['host'],"port":port,"service":service,"notes":f"Generated by Intelligent Mode ({kind})","traffic_kind":kind}
            targets.append(t)
            ps=_profile_templates_for_target(t, req.campaign_objective); profiles.extend(ps)
            new_actions=[_action_from_target_profile(t,p) for p in ps]
            for a in new_actions:
                if a.get('mode')=='normal': normal_actions+=1
                else: attack_actions+=1
            actions.extend(new_actions)
    non_private_allowed = bool(req.allow_non_private and not (net.is_private or net.is_loopback))
    capecs=sorted({a.get('attack_category') for a in actions if a.get('mode')=='anomaly' and a.get('attack_category')!='benign'})
    services=sorted({t.get('service') for t in targets})
    coverage={
        "services":services,
        "service_labels":{svc:SERVICE_CATALOG.get(svc,{}).get('label',svc) for svc in services},
        "services_count":len(services),
        "capec_categories":capecs,
        "capec_count":len(capecs),
        "normal_actions":normal_actions,
        "attack_actions":attack_actions,
        "expected_duration_seconds":sum(int(a.get('duration_seconds') or 0) for a in actions),
        "campaign_objective":req.campaign_objective,
        "balance_note":"Balanced enough" if normal_actions and attack_actions and min(normal_actions,attack_actions)/max(normal_actions,attack_actions)>=0.4 else "Review balance before long experiments"
    }
    campaign={"name":f"INTELLIGENT_{req.campaign_objective}_{datetime.now().strftime('%Y%m%d_%H%M%S')}","actions":actions,"execute_now":False,"scheduled_start":"","scheduled_start_epoch":None,"notes":f"Generated from {req.ip_range}. Objective={req.campaign_objective}. Review before execution."}
    if req.save_generated:
        for t in targets: db_add_target(t)
        for p in profiles: db_add_profile(p)
    return {"range":str(net),"ports":ports,"hosts_found":len(discovered),"discovered":discovered,"targets":targets,"profiles":profiles,"campaign":campaign,"coverage":coverage,"saved":bool(req.save_generated),"non_private_allowed":non_private_allowed,"scan_checks":len(tasks),"max_workers":max_workers}

@app.post('/api/intelligent/apply')
def intelligent_apply(req:IntelligentApplyReq):
    saved_targets=saved_profiles=0
    for t in req.targets:
        t=_validate_target_payload(t); t.setdefault('id',str(uuid.uuid4())); db_add_target(t); saved_targets+=1
    for p in req.profiles:
        p=_validate_profile_payload(p); db_add_profile(p); saved_profiles+=1
    actions=[CampaignAction(**_validate_campaign_payload(a)).model_dump() for a in req.actions]
    return {"targets_saved":saved_targets,"profiles_saved":saved_profiles,"campaign_draft":{"name":_reject_dangerous(req.campaign_name,'campaign name',160),"actions":actions,"execute_now":False,"scheduled_start":"","scheduled_start_epoch":None,"notes":_reject_dangerous(req.notes,'notes',500)}}

@app.get("/api/config/export")
def export_targets_profiles():
    """Export targets and profiles to JSON so another ATG installation can reuse them."""
    payload = {
        "format": "THREATSLEUTH_ATG_TARGETS_PROFILES_EXPORT_V1",
        "exported_at": now(),
        "targets": db_targets(),
        "profiles": db_profiles(),
    }
    out = EXP / f"atg_targets_profiles_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    out.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    return FileResponse(str(out), filename=out.name, media_type="application/json")

@app.post("/api/config/import")
async def import_targets_profiles(config_file: UploadFile = File(...)):
    """Import targets/profiles from a trusted JSON file after schema validation.

    The uploaded file is parsed as data only. It is never executed or used as a
    remote include, which prevents Remote File Inclusion-style abuse.
    """
    if not (config_file.filename or "").lower().endswith(".json"):
        raise HTTPException(400, "Only JSON import files are allowed")
    raw = await config_file.read()
    if not raw or len(raw) > 2_000_000:
        raise HTTPException(400, "The JSON file is empty or too large")
    try:
        payload = json.loads(raw.decode("utf-8"))
    except Exception:
        raise HTTPException(400, "Invalid JSON file")
    targets = payload.get("targets", []) if isinstance(payload, dict) else []
    profiles = payload.get("profiles", []) if isinstance(payload, dict) else []
    if not isinstance(targets, list) or not isinstance(profiles, list):
        raise HTTPException(400, "Invalid import structure")
    imported_targets = imported_profiles = skipped = 0
    for item in targets:
        try:
            if not isinstance(item, dict):
                skipped += 1; continue
            t = _validate_target_payload(item)
            t.setdefault("id", str(uuid.uuid4()))
            db_add_target(t); imported_targets += 1
        except Exception:
            skipped += 1
    for item in profiles:
        try:
            if not isinstance(item, dict):
                skipped += 1; continue
            p = _validate_profile_payload(item)
            db_add_profile(p); imported_profiles += 1
        except Exception:
            skipped += 1
    return {"targets_imported": imported_targets, "profiles_imported": imported_profiles, "skipped": skipped}

def _fmt_num(value, digits=3):
    if value is None or value == "":
        return "-"
    try:
        return f"{float(value):.{digits}f}"
    except Exception:
        return str(value)


def _load_report_experiment(experiment_id: str):
    experiment_id = _reject_dangerous(experiment_id, "experiment id", 80)
    with _db_lock, db_conn() as con:
        exp = con.execute("SELECT * FROM ml_experiments WHERE id=?", (experiment_id,)).fetchone()
        if not exp:
            raise HTTPException(404, "Experiment not found")
        results = con.execute(
            "SELECT * FROM ml_results WHERE experiment_id=? ORDER BY service, mcc DESC, f1_macro DESC",
            (experiment_id,),
        ).fetchall()
    return dict(exp), [dict(r) for r in results]


def _report_extra(row: dict) -> dict:
    try:
        return json.loads(row.get("report_json") or "{}")
    except Exception:
        return {}


def _brand_data_uri(path: Path) -> str:
    if not path.exists():
        return ""
    return f"data:image/png;base64,{base64.b64encode(path.read_bytes()).decode('ascii')}"


def _build_html_report(e: dict, rs: list[dict], output_path: Path) -> None:
    cfg = json.loads(e.get("config_json") or "{}")
    inner_cfg = cfg.get("config", cfg) if isinstance(cfg, dict) else {}
    dataset_report = inner_cfg.get("dataset_report", {}) if isinstance(inner_cfg, dict) else {}
    features_used = inner_cfg.get("features_used") or dataset_report.get("features_used") or []
    raw_features_used = inner_cfg.get("raw_features_used") or []
    features_excluded = inner_cfg.get("features_excluded") or dataset_report.get("features_excluded") or []
    model_profile = inner_cfg.get("model_profile", "")
    selected_models = inner_cfg.get("selected_models", [])
    logo = _brand_data_uri(BRAND_LOGO)
    rows = "".join(
        f"<tr><td>{html.escape(str(r.get('service','')))}</td><td>{html.escape(str(r.get('model_name','')))}</td>"
        f"<td>{r.get('accuracy','')}</td><td>{r.get('precision_macro','')}</td><td>{r.get('recall_macro','')}</td>"
        f"<td>{r.get('f1_macro','')}</td><td>{r.get('f1_weighted','')}</td><td>{r.get('mcc','')}</td>"
        f"<td>{_report_extra(r).get('balanced_accuracy','')}</td><td>{r.get('roc_auc','')}</td><td>{r.get('train_seconds','')}</td></tr>"
        for r in rs
    )
    ranked = sorted(
        rs,
        key=lambda x: ((x.get("mcc") if x.get("mcc") is not None else -999), x.get("f1_macro") or 0),
        reverse=True,
    )
    best = ranked[0] if ranked else {}
    bars = []
    for r in ranked[:12]:
        try:
            value = max(0.0, min(float(r.get("mcc") or 0), 1.0))
        except Exception:
            value = 0.0
        bars.append(
            f"<div class='barrow'><span>{html.escape(str(r.get('model_name','model')))}</span>"
            f"<div class='bar'><b style='width:{value*100:.1f}%'></b></div><strong>{value:.3f}</strong></div>"
        )
    try:
        cm = json.loads(best.get("confusion_matrix_json") or "[]")
    except Exception:
        cm = []
    cm_html = ""
    if cm:
        maxv = max([float(v) for row in cm for v in row] or [1.0])
        cm_rows = []
        for row in cm:
            cells = "".join(
                f"<td style='--heat:{(float(v)/maxv if maxv else 0):.3f}'>{v}</td>" for v in row
            )
            cm_rows.append(f"<tr>{cells}</tr>")
        cm_html = f"<section><h2>Confusion Matrix</h2><table class='heatmap'>{''.join(cm_rows)}</table></section>"
    conclusion = (
        f"The highest-ranked model was {best.get('model_name')} for {best.get('service')}, "
        f"with MCC={best.get('mcc')} and F1 macro={best.get('f1_macro')}."
        if best
        else "No valid model result was available."
    )
    generated = datetime.now().astimezone().isoformat(timespec="seconds")
    logo_html = f'<img src="{logo}" alt="CAUSALIS">' if logo else f"<h1>{PRODUCT_NAME}</h1>"
    report = f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{PRODUCT_NAME} Report · {html.escape(str(e.get("name") or e.get("id")))}</title>
<style>
:root{{--ink:#eaf2ff;--muted:#8ea4bc;--panel:#0d1a2d;--line:#24415f;--blue:#31a9df;--green:#78c86a;--bg:#07111f}}
*{{box-sizing:border-box}}body{{font-family:Inter,Segoe UI,Arial,sans-serif;margin:0;background:var(--bg);color:var(--ink);line-height:1.45}}main{{max-width:1180px;margin:auto;padding:32px}}header{{padding:24px 32px;background:linear-gradient(135deg,#0a1728,#102f35);border-bottom:1px solid var(--line)}}header img{{max-width:560px;width:72%;height:auto}}header p{{margin:8px 0 0;color:var(--muted)}}section{{margin:18px 0;padding:20px;background:var(--panel);border:1px solid var(--line);border-radius:16px}}h1,h2,h3{{margin-top:0}}h2{{color:#bfe8ff}}.tagline{{color:#9bd88e}}.kpis{{display:grid;grid-template-columns:repeat(4,minmax(130px,1fr));gap:12px}}.kpi{{padding:15px;border:1px solid var(--line);border-radius:12px;background:#091525}}.kpi span{{display:block;color:var(--muted);font-size:12px;text-transform:uppercase}}.kpi strong{{font-size:24px}}table{{border-collapse:collapse;width:100%;font-size:12px}}td,th{{border:1px solid var(--line);padding:8px;text-align:left}}th{{background:#122943}}pre{{background:#050c16;border:1px solid var(--line);border-radius:10px;padding:12px;white-space:pre-wrap;overflow-wrap:anywhere;color:#c9d7e7}}.barrow{{display:grid;grid-template-columns:180px 1fr 55px;gap:10px;align-items:center;margin:8px 0}}.bar{{height:12px;background:#050c16;border:1px solid var(--line);border-radius:999px;overflow:hidden}}.bar b{{display:block;height:100%;background:linear-gradient(90deg,var(--blue),var(--green))}}.heatmap{{width:auto;min-width:300px}}.heatmap td{{text-align:center;background:rgba(120,200,106,var(--heat));font-weight:800;min-width:48px}}footer{{padding:20px 32px;color:var(--muted);font-size:12px;border-top:1px solid var(--line)}}@media(max-width:760px){{.kpis{{grid-template-columns:1fr 1fr}}main{{padding:16px}}}}
</style></head><body><header>{logo_html}<p>{PRODUCT_DESCRIPTOR} · {PRODUCT_TAGLINE}</p></header><main>
<section><h1>{html.escape(str(e.get('name') or e.get('id')))}</h1><p class="tagline">Experiment report generated from persisted CAUSALIS evidence.</p><div class="kpis"><div class="kpi"><span>Best model</span><strong>{html.escape(str(e.get('best_model') or best.get('model_name') or '-'))}</strong></div><div class="kpi"><span>Rows</span><strong>{e.get('rows_total','-')}</strong></div><div class="kpi"><span>Columns</span><strong>{e.get('columns_total','-')}</strong></div><div class="kpi"><span>Random seed</span><strong>{e.get('random_seed','-')}</strong></div></div></section>
<section><h2>Experiment Metadata</h2><table><tr><th>ID</th><td>{html.escape(str(e.get('id','')))}</td></tr><tr><th>Created</th><td>{html.escape(str(e.get('created_at','')))}</td></tr><tr><th>Generated</th><td>{generated}</td></tr><tr><th>Target column</th><td>{html.escape(str(e.get('target_column','')))}</td></tr><tr><th>Dataset</th><td>{html.escape(str(e.get('dataset_filename','')))}</td></tr><tr><th>Model profile</th><td>{html.escape(str(model_profile or 'not specified'))}</td></tr><tr><th>Selected models</th><td>{html.escape(', '.join(selected_models) if selected_models else 'not specified')}</td></tr></table></section>
<section><h2>Model Ranking by MCC</h2>{''.join(bars) or '<p>No valid metrics available.</p>'}</section>
<section><h2>Metrics on External Test Set</h2><div style="overflow:auto"><table><thead><tr><th>Service</th><th>Model</th><th>Accuracy</th><th>Precision</th><th>Recall</th><th>F1 macro</th><th>F1 weighted</th><th>MCC</th><th>Balanced Acc.</th><th>ROC-AUC</th><th>Train s</th></tr></thead><tbody>{rows}</tbody></table></div></section>
{cm_html}
<section><h2>Dataset and Feature Provenance</h2><h3>Dataset report</h3><pre>{html.escape(json.dumps(dataset_report,indent=2,ensure_ascii=False))}</pre><h3>Excluded features</h3><pre>{html.escape(json.dumps(features_excluded,indent=2,ensure_ascii=False))}</pre><h3>Raw features used</h3><pre>{html.escape(json.dumps(raw_features_used or features_used,indent=2,ensure_ascii=False))}</pre><h3>Complete configuration</h3><pre>{html.escape(json.dumps(cfg,indent=2,ensure_ascii=False))}</pre></section>
<section><h2>Automatic Summary</h2><p>{html.escape(conclusion)}</p><p>Results are reported for the configured external test dataset. MCC, macro F1, recall, and class-level confusion should be interpreted together when classes are imbalanced.</p></section>
</main><footer>{PRODUCT_NAME} {PRODUCT_VERSION} · {PRODUCT_DESCRIPTOR} · Built on {BASELINE_NAME}</footer></body></html>'''
    output_path.write_text(report, encoding="utf-8")


def _build_pdf_report(e: dict, rs: list[dict], output_path: Path) -> None:
    try:
        from reportlab.lib import colors
        from reportlab.lib.enums import TA_CENTER
        from reportlab.lib.pagesizes import A4, landscape
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib.units import mm
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image as RLImage, PageBreak
    except Exception as exc:
        raise HTTPException(500, f"PDF support is unavailable: {exc}")
    cfg = json.loads(e.get("config_json") or "{}")
    inner = cfg.get("config", cfg) if isinstance(cfg, dict) else {}
    dataset_report = inner.get("dataset_report", {}) if isinstance(inner, dict) else {}
    ranked = sorted(
        rs,
        key=lambda x: ((x.get("mcc") if x.get("mcc") is not None else -999), x.get("f1_macro") or 0),
        reverse=True,
    )
    best = ranked[0] if ranked else {}
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name="BrandTitle", parent=styles["Title"], fontSize=22, leading=26, textColor=colors.HexColor("#163b54"), alignment=TA_CENTER, spaceAfter=8))
    styles.add(ParagraphStyle(name="BrandSub", parent=styles["Normal"], fontSize=10, textColor=colors.HexColor("#40758a"), alignment=TA_CENTER, spaceAfter=16))
    styles.add(ParagraphStyle(name="Section", parent=styles["Heading2"], fontSize=14, textColor=colors.HexColor("#1f6783"), spaceBefore=10, spaceAfter=8))
    doc = SimpleDocTemplate(str(output_path), pagesize=landscape(A4), rightMargin=14*mm, leftMargin=14*mm, topMargin=12*mm, bottomMargin=12*mm, title=f"{PRODUCT_NAME} Experiment Report", author=PRODUCT_NAME)
    story = []
    if BRAND_LOGO.exists():
        logo = RLImage(str(BRAND_LOGO), width=115*mm, height=38*mm)
        logo.hAlign = "CENTER"
        story.append(logo)
    else:
        story.append(Paragraph(PRODUCT_NAME, styles["BrandTitle"]))
    story.append(Paragraph(f"{PRODUCT_DESCRIPTOR}<br/>{PRODUCT_TAGLINE}", styles["BrandSub"]))
    story.append(Paragraph(html.escape(str(e.get("name") or e.get("id"))), styles["BrandTitle"]))
    meta = [
        ["Experiment ID", str(e.get("id", "")), "Created", str(e.get("created_at", ""))],
        ["Best model", str(e.get("best_model") or best.get("model_name") or "-"), "Random seed", str(e.get("random_seed", "-"))],
        ["Rows", str(e.get("rows_total", "-")), "Columns", str(e.get("columns_total", "-"))],
        ["Dataset", str(e.get("dataset_filename", "")), "Target", str(e.get("target_column", ""))],
    ]
    mt = Table(meta, colWidths=[30*mm, 80*mm, 28*mm, 105*mm])
    mt.setStyle(TableStyle([
        ("GRID", (0,0), (-1,-1), 0.5, colors.HexColor("#9ab8c7")),
        ("BACKGROUND", (0,0), (0,-1), colors.HexColor("#dff1f7")),
        ("BACKGROUND", (2,0), (2,-1), colors.HexColor("#e7f5e3")),
        ("VALIGN", (0,0), (-1,-1), "TOP"),
        ("FONTSIZE", (0,0), (-1,-1), 8),
        ("PADDING", (0,0), (-1,-1), 5),
    ]))
    story += [mt, Spacer(1, 8*mm), Paragraph("Model Metrics", styles["Section"])]
    data = [["Service", "Model", "Accuracy", "Precision", "Recall", "F1", "MCC", "ROC-AUC", "Train s"]]
    for r in ranked:
        data.append([
            str(r.get("service", "")), str(r.get("model_name", "")), _fmt_num(r.get("accuracy")),
            _fmt_num(r.get("precision_macro")), _fmt_num(r.get("recall_macro")), _fmt_num(r.get("f1_macro")),
            _fmt_num(r.get("mcc")), _fmt_num(r.get("roc_auc")), _fmt_num(r.get("train_seconds"), 2),
        ])
    tbl = Table(data, repeatRows=1, colWidths=[24*mm, 40*mm, 22*mm, 22*mm, 22*mm, 22*mm, 22*mm, 22*mm, 20*mm])
    tbl.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,0), colors.HexColor("#163b54")),
        ("TEXTCOLOR", (0,0), (-1,0), colors.white),
        ("GRID", (0,0), (-1,-1), 0.35, colors.HexColor("#9ab8c7")),
        ("ROWBACKGROUNDS", (0,1), (-1,-1), [colors.white, colors.HexColor("#f2f8fa")]),
        ("FONTSIZE", (0,0), (-1,-1), 7),
        ("VALIGN", (0,0), (-1,-1), "MIDDLE"),
        ("ALIGN", (2,1), (-1,-1), "RIGHT"),
    ]))
    story.append(tbl)
    try:
        cm = json.loads(best.get("confusion_matrix_json") or "[]")
    except Exception:
        cm = []
    if cm:
        story += [Spacer(1, 6*mm), Paragraph("Confusion Matrix — Best Model", styles["Section"])]
        cm_data = [[str(v) for v in row] for row in cm]
        cm_tbl = Table(cm_data)
        maxv = max([float(v) for row in cm for v in row] or [1])
        commands = [
            ("GRID", (0,0), (-1,-1), 0.5, colors.HexColor("#5f8191")),
            ("ALIGN", (0,0), (-1,-1), "CENTER"),
            ("FONTSIZE", (0,0), (-1,-1), 9),
        ]
        for ri, row in enumerate(cm):
            for ci, value in enumerate(row):
                ratio = float(value) / maxv if maxv else 0
                bg = colors.Color(0.88 - 0.45*ratio, 0.96 - 0.22*ratio, 0.88 - 0.42*ratio)
                commands.append(("BACKGROUND", (ci,ri), (ci,ri), bg))
        cm_tbl.setStyle(TableStyle(commands))
        story.append(cm_tbl)
    story += [PageBreak(), Paragraph("Dataset and Configuration Provenance", styles["Section"])]
    provenance = json.dumps({
        "dataset_report": dataset_report,
        "features_used": inner.get("features_used", []),
        "features_excluded": inner.get("features_excluded", []),
        "configuration": cfg,
    }, indent=2, ensure_ascii=False)
    for chunk in [provenance[i:i+3500] for i in range(0, len(provenance), 3500)]:
        story.append(Paragraph(html.escape(chunk).replace("\n", "<br/>").replace(" ", "&nbsp;"), styles["Code"]))
    def footer(canvas, doc_obj):
        canvas.saveState()
        canvas.setFont("Helvetica", 7)
        canvas.setFillColor(colors.HexColor("#607b89"))
        canvas.drawString(14*mm, 7*mm, f"{PRODUCT_NAME} {PRODUCT_VERSION} · {PRODUCT_DESCRIPTOR}")
        canvas.drawRightString(landscape(A4)[0]-14*mm, 7*mm, f"Page {doc_obj.page}")
        canvas.restoreState()
    doc.build(story, onFirstPage=footer, onLaterPages=footer)


@app.get("/api/ml/experiments/{experiment_id}/report")
def ml_experiment_report(experiment_id: str, format: str = "html"):
    """Generate a branded CAUSALIS report in HTML, PDF, or both formats."""
    fmt = (format or "html").strip().lower()
    if fmt not in {"html", "pdf", "both"}:
        raise HTTPException(400, "format must be html, pdf, or both")
    e, rs = _load_report_experiment(experiment_id)
    safe_name = _safe_token(e.get("name") or experiment_id, "experiment name")
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    html_path = ML_REPORTS_DIR / f"causalis_report_{safe_name}_{stamp}.html"
    pdf_path = ML_REPORTS_DIR / f"causalis_report_{safe_name}_{stamp}.pdf"
    with ML_JOB_LOCK:
        if fmt in {"html", "both"}:
            _build_html_report(e, rs, html_path)
        if fmt in {"pdf", "both"}:
            _build_pdf_report(e, rs, pdf_path)
    if fmt == "html":
        record_experiment_activity("report","generated",f"HTML report generated for {e.get('name') or experiment_id}",e.get('workspace_experiment_id'),{"file":html_path.name})
        return FileResponse(str(html_path), filename=html_path.name, media_type="text/html")
    if fmt == "pdf":
        record_experiment_activity("report","generated",f"PDF report generated for {e.get('name') or experiment_id}",e.get('workspace_experiment_id'),{"file":pdf_path.name})
        return FileResponse(str(pdf_path), filename=pdf_path.name, media_type="application/pdf")
    zip_path = ML_REPORTS_DIR / f"causalis_report_{safe_name}_{stamp}.zip"
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.write(html_path, arcname=html_path.name)
        zf.write(pdf_path, arcname=pdf_path.name)
    record_experiment_activity("report","generated",f"HTML and PDF report package generated for {e.get('name') or experiment_id}",e.get('workspace_experiment_id'),{"file":zip_path.name})
    return FileResponse(str(zip_path), filename=zip_path.name, media_type="application/zip")


@app.get("/api/download/{name}")
def dl_legacy(name:str):
    p=EXP/name
    if not p.exists(): raise HTTPException(404,"not found")
    return FileResponse(str(p),filename=p.name)

@app.get("/api/download/{folder}/{name}")
def dl_folder(folder:str,name:str):
    allowed={"matched_logs":MATCHED_DIR,"clean_datasets":CLEAN_DIR,"dataset_splits":SPLIT_DIR,"ml_datasets":ML_DATASETS_DIR,"ml_reports":ML_REPORTS_DIR}
    base=allowed.get(folder)
    if base is None:
        raise HTTPException(404,"unknown download folder")
    p=base/name
    if not p.exists(): raise HTTPException(404,"not found")
    return FileResponse(str(p),filename=p.name)
