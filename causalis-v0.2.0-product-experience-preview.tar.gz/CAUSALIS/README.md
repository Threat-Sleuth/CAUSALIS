# CAUSALIS

![CAUSALIS](app/static/brand/causalis_logo_light_full.png)

**Controlled Cyber Experimentation**  
*From controlled action to measurable evidence.*

---

## Overview

CAUSALIS is a product-oriented platform for controlled and reproducible cybersecurity experimentation. It preserves the validated ThreatSleuth ATG research core while providing a professional workflow for experiment design, evidence correlation, dataset engineering, machine-learning evaluation, analytics, and report generation.

## Version 0.2.0 — Product Experience Preview

This release substantially redesigns the user experience without changing the validated execution core.

### New product workflow

```text
Home
  ↓
Experiment Designer
  ↓
Guided Discovery
  ↓
Data Engineering
  ↓
Machine Learning
  ↓
Analytics & Reports
```

### Main improvements

- Operational status moved to Home.
- Experiment Designer organized into Targets, Profiles, and Campaigns.
- Guided Discovery redesigned around network scope, discovery strategy, and a reviewable experiment proposal.
- Data Engineering organized as Correlate, Analyze, Clean, and Package.
- Machine Learning organized by task: Binary Detection, CAPEC Attribution, and History.
- Dataset split export moved into the Data Engineering workflow.
- Primary report formats remain HTML and PDF.
- Official CAUSALIS logo family integrated into the product.

## Core Capabilities

- Controlled normal and anomaly traffic generation
- Campaign execution and scheduling
- Intelligent service discovery
- Event persistence and ground-truth preservation
- Log ingestion and temporal correlation
- Dataset quality assessment and cleaning
- Binary and CAPEC multiclass machine-learning experiments
- Integrated analytics and confusion matrices
- HTML and PDF report generation
- SQLite persistence
- Offline operation after installation

## Installation

```bash
tar -xzf causalis-v0.2.0-product-experience-preview.tar.gz
cd CAUSALIS
chmod +x deploy.sh run.sh stop.sh
./deploy.sh
./run.sh
```

Use the URL displayed by the startup script.

## Existing Database Compatibility

The SQLite path remains unchanged for compatibility:

```text
data/atg.db
```

Stop CAUSALIS before restoring a previous database.

## Architecture

See [`architecture.md`](architecture.md).

## Responsible Use

CAUSALIS is intended exclusively for authorized research, teaching, dataset generation, and controlled laboratory testing. Do not use it against systems or networks without explicit authorization.

## Development Principles

1. **Do not break what already works.**
2. **Every interface element must have a clear purpose.**
3. **The next recommended action should be evident to the user.**

## Status

CAUSALIS is under private product development.
