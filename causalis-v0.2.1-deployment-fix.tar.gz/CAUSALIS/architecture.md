# CAUSALIS Architecture

**Version:** 0.2.0  
**Release:** Product Experience Preview  
**Validated baseline:** ThreatSleuth ATG 1.0.0 / CAUSALIS 0.1.2

## Architectural Principle

CAUSALIS 0.2.0 is a presentation and workflow evolution around the validated experimentation core. Traffic generation, scheduling, event registration, log correlation, dataset cleaning, machine-learning training, SQLite persistence, and report generation remain compatible with the validated baseline.

## Logical Architecture

```text
Browser GUI
   │
   ▼
FastAPI Application
   ├── Experiment Designer
   ├── Guided Discovery
   ├── Traffic Generation Engine
   ├── Campaign Scheduler
   ├── Event Registration
   ├── Log Correlation
   ├── Data Engineering
   ├── Machine Learning
   ├── Analytics
   └── HTML/PDF Reporting
   │
   ├── SQLite
   └── File Artifact Storage
```

## Product Workspaces

### Home

Operational dashboard containing platform status, scheduler state, current campaign execution, recent activity, readiness, event distribution, and model snapshots.

### Experiment Designer

Three-column workflow:

1. Targets
2. Profiles
3. Campaign actions and campaign assembly

The underlying target, profile, one-off action, and campaign APIs are unchanged.

### Guided Discovery

Product-oriented interface over the validated Intelligent Mode:

- Authorized CIDR scope
- Modern controlled-range toggle
- Quick, Standard, Extended, and Custom scan profiles
- Service-aware discovery
- Generated targets and profiles
- Reviewable experiment proposal

The backend remains deterministic and rule-based.

### Data Engineering

Workflow stages:

1. Correlate service logs with CAUSALIS events
2. Analyze dataset quality
3. Review feature recommendations
4. Generate the clean dataset
5. Generate a portable training/test package when required

### Machine Learning

Task-oriented views:

- Binary Detection
- CAPEC Attribution
- Experiment History

The scikit-learn training functions and persisted result schema remain unchanged.

### Analytics & Reports

Consumes persisted `ml_experiments` and `ml_results` data to render rankings, metric profiles, confusion matrices, class distributions, and report actions.

## Persistence

SQLite remains the embedded database. The validated database file remains `data/atg.db`. File artifacts continue to be stored under `data/exports`, `data/uploads`, `data/models`, and related folders.

## Backward Compatibility

CAUSALIS 0.2.0 does not require a destructive database migration. Existing validated databases can be restored while the application is stopped.

## Regression-Critical Components

- Traffic generation
- Rate and concurrency behavior
- Scheduler and epoch handling
- Campaign groups
- Event persistence
- Intelligent discovery/apply workflow
- Log matching and temporal-window advisor
- Dataset analysis and cleaning
- Split generation
- Binary and multiclass training
- Experiment persistence
- HTML and PDF reporting

## Next Architectural Milestone

The next major milestone is the Experiment Workspace entity, which will group traffic, evidence, datasets, models, analytics, reports, and future APT scenarios under one experiment lifecycle.
