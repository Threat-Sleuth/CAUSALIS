# CAUSALIS 0.1.2 — Initial Product Package

CAUSALIS 0.1.2 is the first package released under the CAUSALIS product identity.

## Included

- CAUSALIS branding across GUI, favicon, footer and generated reports;
- integrated analytics inherited from the validated Studio 0.1.1 package;
- Generate report dialog with HTML, PDF or both;
- branded HTML and PDF reports;
- report generation shown in Recent Activity;
- event-mode percentage and imbalance observation;
- multi-service ML dataset filename/service warnings;
- rewritten README and architecture specification;
- ReportLab PDF dependency;
- preferred `CAUSALIS_PORT` configuration with `ATG_PORT` compatibility.

## Core compatibility

Traffic generation, scheduling, Intelligent Mode, correlation, cleaning, dataset construction and ML training remain based on the validated ThreatSleuth ATG 1.0.0 core.
