# CAUSALIS Architecture

**Document version:** 0.1  
**Product version:** 0.1.2  
**Status:** Initial product architecture  
**Technical baseline:** ThreatSleuth ATG 1.0.0 Stable

<p align="center">
  <img src="app/static/brand/causalis_logo_horizontal.png" alt="CAUSALIS" width="620">
</p>

## 1. Architectural Objective

CAUSALIS is a product layer built around a validated cybersecurity experimentation core. The initial product architecture deliberately minimizes changes to traffic generation, scheduling, event correlation, dataset processing and model training.

The governing rule is:

> **DO NOT BREAK WHAT ALREADY WORKS.**

The current release focuses on brand integration, product experience, integrated analytics and report generation while preserving the validated core API and SQLite schema.

---

## 2. Runtime View

```text
Browser GUI
   │
   │ HTML / CSS / JavaScript / JSON / multipart uploads
   ▼
FastAPI application
   │
   ├── Product dashboard and analytics API
   ├── Target and profile management
   ├── Traffic generation engine
   ├── Campaign scheduler
   ├── Intelligent Mode
   ├── Event persistence
   ├── Log correlation
   ├── Dataset quality and cleaning
   ├── Machine-learning orchestration
   └── HTML/PDF report generation
   │
   ├────────────► SQLite: data/atg.db
   └────────────► Filesystem: data/*
```

The application remains a local FastAPI web application served by Uvicorn. It uses a browser-based frontend without a separate frontend framework.

---

## 3. Product Metadata and Branding

Product metadata is centralized in `app/main.py`:

```python
PRODUCT_NAME = "CAUSALIS"
PRODUCT_VERSION = "0.1.2"
PRODUCT_DESCRIPTOR = "Controlled Cyber Experimentation"
PRODUCT_TAGLINE = "From controlled action to measurable evidence."
BASELINE_NAME = "Validated ThreatSleuth ATG 1.0.0 Core"
```

Brand assets are stored under:

```text
app/static/brand/
```

The GUI, FastAPI metadata, health response, HTML reports and PDF reports use the shared product identity.

The historical database filename `data/atg.db` remains unchanged for compatibility.

---

## 4. Source Layout

```text
CAUSALIS/
├── app/
│   ├── __init__.py
│   ├── main.py
│   ├── static/
│   │   ├── app.js
│   │   ├── style.css
│   │   └── brand/
│   └── templates/
│       └── index.html
├── data/
│   ├── atg.db
│   ├── config/
│   ├── exports/
│   ├── logs/
│   ├── models/
│   └── uploads/
├── architecture.md
├── README.md
├── RELEASE_NOTES_CAUSALIS_v0.1.2.md
├── VERSION
├── deploy.sh
├── requirements.txt
├── run.sh
└── stop.sh
```

`app/main.py` remains the principal backend module. This concentration is known technical debt but is not addressed in the initial CAUSALIS release because large-scale refactoring would increase regression risk.

---

## 5. Validated Core

### 5.1 Traffic execution

The validated execution chain remains:

```text
Campaign / Campaign Group
        ↓
loop()
        ↓
worker()
        ↓
run_once()
        ↓
Protocol-specific interaction
        ↓
Persistent execution event
```

`loop()` controls duration, rate and concurrency. `worker()` couples one real protocol interaction with its execution record. `run_once()` dispatches to the service-specific implementation.

### 5.2 Scheduler

The scheduler supports immediate and time-based campaign execution. Epoch-based scheduling and local-time handling are regression-critical.

### 5.3 Correlation

Execution events are temporally correlated with service logs. The matching engine creates labelled records using execution metadata, service observations and CAPEC context.

### 5.4 Dataset processing

The quality pipeline supports:

- missing-value analysis;
- duplicate detection;
- type inference;
- text-quality checks;
- domain checks;
- entropy and variability indicators;
- outlier analysis;
- configurable cleaning;
- train/test export.

### 5.5 Machine learning

Scikit-learn classifiers are trained through shared experiment workflows. Results are persisted in SQLite and include metrics, confusion matrices, training times and report metadata.

---

## 6. Persistence Architecture

### 6.1 SQLite

The validated schema contains:

- `targets`;
- `profiles`;
- `campaign_groups`;
- `events`;
- `app_settings`;
- `ml_experiments`;
- `ml_results`.

The product dashboards read these tables without changing the validated training pipeline.

### 6.2 Filesystem

The filesystem stores:

- uploaded files;
- matched logs;
- cleaned datasets;
- train/test splits;
- ML datasets;
- trained model artifacts;
- generated reports.

The hybrid persistence model is preserved in 0.1.2.

---

## 7. Product GUI Architecture

### 7.1 Application shell

The application shell includes:

- CAUSALIS horizontal logo;
- descriptor and tagline;
- responsible-use notice;
- global actions;
- Home, Traffic, Intelligent Mode, Data, Models and Results navigation;
- branded footer.

### 7.2 Home

`GET /api/studio/home` provides aggregated read-only product data:

- counts;
- readiness;
- recent campaigns;
- recent ML experiments;
- recent generated reports;
- best models;
- event distribution.

The frontend adds a class-balance observation when one mode accounts for at least 75% of recorded events.

### 7.3 Results

Results uses:

- `GET /api/studio/ml-dashboard`;
- `GET /api/studio/ml-experiments/{experiment_id}`.

The frontend renders:

- metric cards;
- MCC ranking bars;
- best-model metric profile;
- heatmap confusion matrix;
- class distribution;
- training-time/MCC scatter plot;
- detailed metric table.

The training pipeline is not recalculated by the GUI.

---

## 8. Report Architecture

The report interface exposes one action: **Generate report**.

Supported modes:

```text
HTML
PDF
HTML + PDF
```

Endpoint:

```text
GET /api/ml/experiments/{experiment_id}/report?format=html|pdf|both
```

### HTML

The backend creates a self-contained branded HTML document with embedded logo data, metadata, metrics, MCC ranking, confusion matrix and provenance.

### PDF

PDF generation uses ReportLab and includes:

- CAUSALIS branding;
- experiment metadata;
- metrics table;
- confusion matrix;
- dataset and configuration provenance;
- product footer and page numbers.

### Both

The backend generates HTML and PDF, then returns a ZIP archive containing both files.

The GUI and reports consume persisted results. Reports do not retrain or recalculate model outputs.

---

## 9. Recent Activity

The Home activity feed currently combines persisted or observable activity from:

- campaign groups;
- ML experiments;
- generated CAUSALIS reports.

Correlation and cleaning operations are not yet first-class persisted activities. A future Experiment Workspace will introduce a unified activity model.

---

## 10. Compatibility Decisions

The following are intentionally preserved:

- existing API routes;
- SQLite schema;
- `data/atg.db` filename;
- scheduler semantics;
- rate/concurrency behavior;
- existing campaign and event records;
- upload and path validation;
- Intelligent Mode review-before-apply behavior;
- ML experiment and result persistence;
- existing HTML report route, extended through a `format` query parameter.

The legacy `ATG_PORT` variable remains accepted, while `CAUSALIS_PORT` is now preferred.

---

## 11. New GUI Validation Controls

The multi-service ML batch performs a filename-based service consistency check. If a selected file appears to correspond to another service, the GUI displays a warning.

This check is advisory rather than blocking because expert experiments may intentionally combine heterogeneous data.

---

## 12. Regression-Critical Checklist

Every package must validate:

1. deployment and startup;
2. database compatibility;
3. target/profile persistence;
4. one-off traffic;
5. campaign execution;
6. scheduled execution;
7. event logging;
8. Intelligent Mode;
9. log upload and matching;
10. quality analysis and cleaning;
11. dataset split generation;
12. binary training;
13. multi-service batch training;
14. CAPEC multiclass training;
15. experiment persistence;
16. Results visualization;
17. HTML report generation;
18. PDF report generation;
19. combined report ZIP generation;
20. absence of regressions in the validated core.

---

## 13. Known Technical Debt

- backend responsibilities remain concentrated in `app/main.py`;
- frontend behavior remains concentrated in `app.js`;
- filesystem and SQLite artifacts are not yet unified by an Experiment entity;
- processing operations do not yet produce a unified persistent activity log;
- the generated brand assets are raster assets and should eventually be replaced by clean master vector files;
- broader support for the upcoming eight-service honeynet remains future work.

Technical debt will be addressed incrementally and only with explicit regression coverage.

---

## 14. Next Architectural Milestones

1. validate CAUSALIS 0.1.2;
2. improve interaction details and accessibility;
3. introduce Experiment Workspace and explicit lifecycle;
4. unify experiment artifacts and activities;
5. add guided dataset workflow;
6. integrate the next eight-service honeynet;
7. add APT scenarios, ATT&CK mappings and causal ground truth;
8. evaluate commercial packaging and licensing.
