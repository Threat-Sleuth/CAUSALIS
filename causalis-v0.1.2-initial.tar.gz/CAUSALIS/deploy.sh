#!/usr/bin/env bash
set -euo pipefail

APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$APP_DIR"

log(){ echo "[CAUSALIS][DEPLOY] $*"; }

if [[ "${EUID}" -ne 0 ]]; then
  log "Requesting sudo privileges to install system packages..."
  exec sudo -E bash "$0" "$@"
fi

ORIG_USER="${SUDO_USER:-${USER}}"
ORIG_GROUP="$(id -gn "$ORIG_USER" 2>/dev/null || echo "$ORIG_USER")"

log "Updating repositories and installing system dependencies..."
apt update
apt install -y python3 python3-venv python3-pip

log "Creating local virtual environment in $APP_DIR/.venv..."
if [[ ! -x "$APP_DIR/.venv/bin/python" ]]; then
  rm -rf "$APP_DIR/.venv"
  python3 -m venv "$APP_DIR/.venv"
fi

VENV_PY="$APP_DIR/.venv/bin/python"
VENV_PIP="$APP_DIR/.venv/bin/pip"

if [[ ! -x "$VENV_PIP" ]]; then
  log "pip is not available inside the virtual environment; recreating it..."
  rm -rf "$APP_DIR/.venv"
  python3 -m venv "$APP_DIR/.venv"
  VENV_PY="$APP_DIR/.venv/bin/python"
  VENV_PIP="$APP_DIR/.venv/bin/pip"
fi

log "Installing Python dependencies inside the virtual environment, not globally..."
"$VENV_PY" -m pip install --upgrade pip
"$VENV_PY" -m pip install -r requirements.txt

log "Creating data directories..."
mkdir -p data/logs data/exports data/config data/uploads
chown -R "$ORIG_USER:$ORIG_GROUP" "$APP_DIR" || true

cat > "$APP_DIR/run.sh" <<'RUNEOF'
#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
PORT="${CAUSALIS_PORT:-${ATG_PORT:-8080}}"
exec .venv/bin/uvicorn app.main:app --host 0.0.0.0 --port "$PORT"
RUNEOF
chmod +x "$APP_DIR/run.sh"
chown "$ORIG_USER:$ORIG_GROUP" "$APP_DIR/run.sh" || true

log "Installation completed successfully."
log "Manual startup: ./run.sh"
log "URL: http://<HOST_IP>:8080"
