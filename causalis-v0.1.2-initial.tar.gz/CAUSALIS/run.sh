#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [[ ! -f .venv/bin/activate ]]; then
  echo "Virtual environment not found. Run ./deploy.sh once with Internet access."
  exit 1
fi
source .venv/bin/activate
PORT="${CAUSALIS_PORT:-${ATG_PORT:-8080}}"
exec uvicorn app.main:app --host 0.0.0.0 --port "$PORT"
