# ThreatSleuth Studio v0.1.1

## Product experience update

- Replaced residual visible ThreatSleuth ATG product branding with ThreatSleuth Studio.
- Home now shows unified recent activity from persisted traffic campaigns and ML experiments.
- Results redesigned as an analytical dashboard.
- Added MCC model-ranking bars.
- Added best-model metric profile.
- Added confusion-matrix heatmap.
- Added class-distribution visualization when persisted experiment metadata provides it.
- Added training-time versus MCC visualization.
- Detailed model metrics remain available in a collapsible table.
- Primary report generation now produces HTML only.
- TXT and Markdown reports are no longer generated.
- CSV and JSON are no longer generated as side effects of HTML report generation. Technical exports remain a separate product concern.

## Regression policy

Traffic generation, scheduler, Intelligent Mode, correlation, cleaning, dataset construction and ML training logic were not redesigned in this release.
