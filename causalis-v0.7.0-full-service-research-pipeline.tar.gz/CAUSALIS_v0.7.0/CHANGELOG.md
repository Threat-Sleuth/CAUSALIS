# Changelog

## 0.7.0 — 2026-07-25

### Fixed
- REST API dataset split naming and class separation.
- Service names containing underscores in split export.
- UTC handling for offset-less HTTP ISO timestamps.
- PostgreSQL evidence alias detection for `database` filenames.

### Added
- Automatic binary dataset discovery from one folder.
- Automatic CAPEC anomaly discovery from one folder.
- Dataset completeness validation before training.
- Sequential multi-service binary execution from discovered splits.

### Preserved
- v0.6.0 campaign, processing, correlation, ML, reporting and manual-input workflows.
