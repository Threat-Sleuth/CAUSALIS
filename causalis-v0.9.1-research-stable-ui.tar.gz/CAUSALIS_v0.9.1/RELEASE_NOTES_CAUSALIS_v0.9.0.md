# CAUSALIS v0.9.0 — Research Stable Candidate

Release date: 2026-07-29

CAUSALIS v0.9.0 consolidates the resilient machine-learning execution layer validated during the long-running CAPEC multiclass experiment. The validated scientific pipeline is preserved; changes focus on persistence, observability, recovery, and operator feedback.

## Added

- Durable experiment timeline stored in each task result.
- Per-experiment `experiment.log` JSON Lines audit trail.
- Per-model duration history for adaptive ETA calculation.
- Process RSS and process swap telemetry, plus system RAM, system swap, and CPU telemetry.
- Resource peaks and incremental resource history after every completed model.
- Model history panel showing completed, active, and pending models.
- Recovery-aware UI state and resume counter.
- Database migrations for accumulated active time, last resume time, resume count, and pause timestamps.

## Improved

- Pause now enters an explicit `pause_requested` state and waits for the current model to finish safely.
- Interrupted running tasks are marked `recovered` after application restart.
- Resume messaging distinguishes ordinary resume from checkpoint recovery.
- Safe cancellation messaging explicitly preserves completed model artifacts.
- ETA uses observed per-model durations instead of a purely linear elapsed-time projection.
- Task monitor exposes current and peak resource use and a compact execution timeline.
- Persistent task restoration recognizes queued, running, pause-requested, paused, recovered, and cancelling states.

## Preserved scientific baseline

The following validated behavior remains unchanged:

- log processing and event matching;
- clean-dataset generation;
- TRAIN/TEST dataset construction;
- binary classification pipeline;
- CAPEC multiclass classification pipeline;
- model metrics and classification artifacts;
- report generation and export formats.

## Validation scope

A short validation campaign should verify:

1. normal completion of a short CAPEC task;
2. pause request during a model and safe pause after model completion;
3. application or VM restart and recovery from checkpoint;
4. resume count and task state persistence;
5. incremental model history and timeline updates;
6. `experiment.log` creation;
7. current and peak RSS/swap telemetry;
8. final reports and metrics unchanged from the validated scientific workflow.

## Known limitation

Python worker threads cannot be terminated safely from outside the running estimator. Therefore v0.9.0 implements safe cancellation at model boundaries, but deliberately does not expose a misleading hard-kill control inside the application.
