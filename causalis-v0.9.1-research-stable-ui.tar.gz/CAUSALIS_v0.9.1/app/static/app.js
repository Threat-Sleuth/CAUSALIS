function q(s){return document.querySelector(s)}

function enforceNumericMinimums(){
  document.querySelectorAll('input[type="number"]').forEach(input=>{
    input.addEventListener('input',()=>{
      const minAttr=input.getAttribute('min');
      if(minAttr===null || input.value==='') return;
      const min=Number(minAttr);
      const val=Number(input.value);
      if(Number.isFinite(val) && val < min){ input.value=String(min); }
    });
    input.addEventListener('blur',()=>{
      const minAttr=input.getAttribute('min');
      if(minAttr===null) return;
      const min=Number(minAttr);
      const val=Number(input.value);
      if(input.value==='' || !Number.isFinite(val) || val < min){ input.value=String(min); }
    });
  });
}
function msg(t,e=false){const m=q("#msg"); if(m){m.textContent=t;m.style.color=e?"#f87171":"#22c55e"} console.log(t)}
async function api(p,o={}){
  const r=await fetch(p,o);
  const tx=await r.text();
  if(!r.ok) throw Error(tx||r.status);
  return tx?JSON.parse(tx):{};
}
function unsafeText(v){return /(<\s*script|<\/|;\s*drop\s+table|\$\(|`|\.\.\/|\x00)/i.test(String(v||''));}
function validateNoInjection(o){
  for(const [k,v] of Object.entries(o)){
    if(typeof v==='string' && unsafeText(v)) throw Error(`Unsafe input detected in ${k}`);
  }
}
function positiveNumber(value,name,min,max){
  const n=Number(value);
  if(!Number.isFinite(n) || n<min || n>max) throw Error(`${name} must be between ${min} and ${max}`);
  return n;
}
function formObj(f){
  let fd=new FormData(f),o={};
  for(let [k,v] of fd.entries()) o[k]=v;
  if((o.mode||'normal')==='normal') o.attack_category='benign';
  const pDate=document.querySelector('#pointScheduledDate');
  const pTime=document.querySelector('#pointScheduledTime');
  if(pDate && pTime){
    if(pDate.value && pTime.value){
      o.scheduled_start=`${pDate.value}T${pTime.value}`;
      const dt=new Date(o.scheduled_start);
      if(!Number.isNaN(dt.getTime())) o.scheduled_start_epoch=Math.floor(dt.getTime()/1000);
    }else{
      o.scheduled_start='';
      o.scheduled_start_epoch=null;
    }
  }else if(o.scheduled_start){
    const dt=new Date(o.scheduled_start);
    if(!Number.isNaN(dt.getTime())) o.scheduled_start_epoch=Math.floor(dt.getTime()/1000);
  }
  ["port","duration_seconds","concurrency"].forEach(k=>o[k]=parseInt(o[k]||"0"));
  const unit=document.querySelector('#durationUnit')?.value||'seconds';
  if(unit==='minutes') o.duration_seconds=o.duration_seconds*60;
  o.rate_per_second=parseFloat(o.rate_per_second||"1");
  o.port=positiveNumber(o.port,'Port',1,65535);
  o.duration_seconds=positiveNumber(o.duration_seconds,'Duration',1,86400);
  o.concurrency=positiveNumber(o.concurrency,'Concurrency',1,1000);
  o.rate_per_second=positiveNumber(o.rate_per_second,'Rate',0.01,10000);
  validateNoInjection(o);
  return o;
}
function targetFormObj(f){
  const fd=new FormData(f), o={};
  for(let [k,v] of fd.entries()) o[k]=v;
  o.port=parseInt(o.port||"0");
  o.port=positiveNumber(o.port,'Port',1,65535);
  validateNoInjection(o);
  return o;
}
function clampNumericInputs(){
  document.querySelectorAll('input[type="number"]').forEach(input=>{
    const apply=()=>{
      const min=input.getAttribute('min');
      const max=input.getAttribute('max');
      if(input.value==='') return;
      let n=Number(input.value);
      if(!Number.isFinite(n)){input.value=min||'';return;}
      if(min!==null && n<Number(min)) input.value=min;
      if(max!==null && n>Number(max)) input.value=max;
    };
    input.addEventListener('input',apply);
    input.addEventListener('blur',apply);
  });
}
function applyToCampaign(data){
  const f=q("#campaignForm");
  if(!f) return;
  const m={
    target_name:data.name||data.target_name,
    host:data.host,
    port:data.port,
    service:data.service,
    mode:data.mode,
    attack_category:data.attack_category,
    duration_seconds:data.duration_seconds,
    rate_per_second:data.rate_per_second,
    concurrency:data.concurrency,
    path:data.path,
    username:data.username,
    password:data.password,
    dns_query:data.dns_query,
    payload:data.payload,
    profile_name:data.profile_name||data.name,
    scheduled_start:data.scheduled_start
  };
  Object.keys(m).forEach(k=>{
    if(m[k]!==undefined && m[k]!==null && f.elements[k]!==undefined){
      f.elements[k].value=m[k];
    }
  });
  const du=document.querySelector('#durationUnit'); if(du) du.value='seconds';
  if(m.scheduled_start){
    const parts=String(m.scheduled_start).split('T');
    if(q('#pointScheduledDate') && parts[0]) q('#pointScheduledDate').value=parts[0];
    if(q('#pointScheduledTime') && parts[1]) q('#pointScheduledTime').value=parts[1].slice(0,5);
  }
  updateCapecState();
}
async function loadTargets(){
  const a=await api("/api/targets");
  const tb=q("#targetsTable tbody"), sel=q("#savedTargets");
  tb.innerHTML="";
  sel.innerHTML="";
  if(!a.length){
    sel.innerHTML='<option value="">No saved targets</option>';
    return;
  }
  a.forEach(t=>{
    const tr=document.createElement("tr");
    tr.innerHTML=`<td>${t.name}</td><td>${t.host}:${t.port}</td><td>${String(t.service).toUpperCase()}</td><td><button type="button" onclick="useTarget('${t.id}')">usar</button></td><td><button type="button" onclick="delTarget('${t.id}')">x</button></td>`;
    tb.appendChild(tr);
    const opt=document.createElement("option");
    opt.value=t.id;
    opt.textContent=`${t.name} · ${String(t.service).toUpperCase()} · ${t.host}:${t.port}`;
    opt.dataset.target=JSON.stringify(t);
    sel.appendChild(opt);
  });
}
function loadSelectedTarget(){
  const sel=q("#savedTargets");
  if(!sel || !sel.value){msg("No target selected",true);return}
  useTarget(sel.value);
}
function useTarget(id){
  const sel=q("#savedTargets");
  const opt=[...sel.options].find(o=>o.value===id);
  if(!opt || !opt.dataset.target){msg("Target not found",true);return}
  const t=JSON.parse(opt.dataset.target);
  applyToCampaign(t);
  sel.value=id;
  msg("Target loaded: "+t.name);
}
async function delTarget(id){
  await api("/api/targets/"+id,{method:"DELETE"});
  await loadTargets();
}
q("#targetForm").onsubmit=async e=>{
  e.preventDefault();
  try{
    await api("/api/targets",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(targetFormObj(e.target))});
    msg("Target saved");
    await loadTargets();
  }catch(x){msg("Error saving target: "+x.message,true)}
};
async function loadProfiles(){
  const a=await api("/api/profiles");
  const sel=q("#profiles");
  sel.innerHTML='<option value="">Manual profile...</option>';
  a.forEach(p=>{
    const opt=document.createElement("option");
    opt.value=p.name;
    opt.textContent=`${p.name} · ${String(p.service).toUpperCase()} · ${p.mode}`;
    opt.dataset.profile=JSON.stringify(p);
    sel.appendChild(opt);
  });
}
q("#profiles").addEventListener("change",e=>{
  if(!e.target.value)return;
  const opt=e.target.selectedOptions[0];
  if(!opt || !opt.dataset.profile)return;
  const p=JSON.parse(opt.dataset.profile);
  applyToCampaign(p);
  q("#campaignForm").elements.profile_name.value=p.name;
  msg("Profile loaded: "+p.name);
});
async function saveProfile(){
  try{
    let o=formObj(q("#campaignForm"));
    o.name=q("#profileName").value||("profile_"+Date.now());
    await api("/api/profiles",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(o)});
    msg("Profile saved");
    await loadProfiles();
  }catch(x){msg("Error saving profile: "+x.message,true)}
}
q("#campaignForm").onsubmit=e=>{e.preventDefault();start()};
async function start(){
  try{
    const r=await api("/api/campaigns",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(formObj(q("#campaignForm")))});
    msg("One-off traffic started "+r.campaign_id);
    await loadAll();
  }catch(x){msg("Error starting one-off traffic: "+x.message,true)}
}
async function testOnce(){
  try{
    const r=await api("/api/test-once",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(formObj(q("#campaignForm")))});
    msg("Test: "+JSON.stringify(r));
    await loadAll();
  }catch(x){msg("Test error: "+x.message,true)}
}
async function loadCampaigns(){
  const a=await api("/api/campaigns");
  const tb=q("#campaignsTable tbody"), pb=q("#progressBox");
  tb.innerHTML=""; pb.innerHTML="";
  a.slice().reverse().forEach(c=>{
    let r=c.request||{}, pct=c.progress_pct??0;
    tb.innerHTML+=`<tr><td>${c.id.slice(0,6)}</td><td>${c.status}</td><td>${r.service||""}</td><td>${r.mode||""}</td><td>${c.events}</td><td>${pct}%</td></tr>`;
    pb.innerHTML+=`<div class="progress-item"><div class="progress-label"><span>${c.id.slice(0,8)} · ${r.service||""} · ${r.host||""}:${r.port||""} · ${c.status}</span><span>${pct}% · ${c.events} ev</span></div><div class="bar"><div class="bar-fill" style="width:${pct}%"></div></div></div>`;
  });
}
async function loadEvents(){
  const e=await api("/api/events?limit=80");
  q("#eventsBox").textContent=e.map(x=>JSON.stringify(x)).join("\n");
}
async function loadMetrics(){
  q("#metricsBox").textContent=JSON.stringify(await api("/api/metrics"),null,2);
}
async function loadAll(){
  try{await Promise.all([loadTargets(),loadProfiles(),loadCampaigns(),loadEvents(),loadMetrics(),loadCampaignHistory(),loadMlExperiments(),loadSystemStatus(),loadSchedulerStatus(),loadStudioHome(),loadStudioResults(),loadExperimentWorkspaces()])}
  catch(x){msg("Error loading data: "+x.message,true)}
}
function exportSplit(){
  const dir=q('#splitOutputDir')?.value||'';
  const qs=dir?`&output_dir=${encodeURIComponent(dir)}`:'';
  location=`/api/export/split?fmt=csv${qs}`;
}
function exportConfig(){location='/api/config/export'}
async function importConfig(){
  const f=q('#configImportFile')?.files?.[0];
  if(!f){msg('Select a JSON file to import',true);return;}
  if(!f.name.toLowerCase().endsWith('.json')){msg('Only JSON files are allowed',true);return;}
  try{
    const fd=new FormData(); fd.append('config_file',f);
    const r=await api('/api/config/import',{method:'POST',body:fd});
    msg(`Import completed: ${r.targets_imported} targets, ${r.profiles_imported} profiles, ${r.skipped} skipped`);
    await loadTargets(); await loadProfiles();
  }catch(x){msg('Import error: '+x.message,true)}
}
async function matchLogs(){
  try{
    const file=q("#logFile")?.files?.[0];
    let r;
    if(file){
      const fd=new FormData();
      fd.append("service",q("#matchService").value);
      fd.append("dataset_kind",q("#matchKind").value);
      fd.append("window_seconds",positiveNumber(q("#matchWindow").value||"5","Window",1,3600));
      fd.append("log_file",file);
      r=await api("/api/match-file",{method:"POST",body:fd});
    }else{
      let body={service:q("#matchService").value,dataset_kind:q("#matchKind").value,window_seconds:positiveNumber(q("#matchWindow").value||"5","Window",1,3600),log_text:q("#logText").value};
      r=await api("/api/match",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
    }
    q("#matchResult").innerHTML=`Generated: <a href="${r.download}">${r.file}</a><br><span>${r.matched}/${r.events} matched events · ${r.log_lines} log lines processed</span>`;
  }catch(x){q("#matchResult").textContent="Error: "+x.message}
}
async function analyzeTemporalWindow(){
  const file=q('#logFile')?.files?.[0];
  if(!file){q('#windowAdvisorResult').textContent='Select a log file first.';return;}
  try{
    const fd=new FormData();
    fd.append('service',q('#matchService').value);
    fd.append('dataset_kind',q('#matchKind').value);
    fd.append('log_file',file);
    q('#windowAdvisorResult').textContent='Analyzing candidate windows...';
    const r=await api('/api/match/window-advisor',{method:'POST',body:fd});
    const rows=(r.candidates||[]).map(x=>`<tr><td>${x.window_seconds}s</td><td>${Math.round(x.match_rate*10000)/100}%</td><td>${x.matched}/${x.events}</td><td>${x.ambiguous_matches}</td><td>${x.duplicate_correlations}</td><td>${x.cpi}</td></tr>`).join('');
    q('#windowAdvisorResult').innerHTML=`<h3>Temporal Window Advisor</h3><p>Recommended: <b>${r.recommended?.window_seconds||''} seconds</b></p><div class="small-table"><table><thead><tr><th>Window</th><th>Match %</th><th>Matched</th><th>Ambiguous</th><th>Duplicates</th><th>CPI</th></tr></thead><tbody>${rows}</tbody></table></div>`;
  }catch(x){q('#windowAdvisorResult').textContent='Advisor error: '+x.message;}
}

function bindLogFile(){
  const f=q("#logFile"), name=q("#logFileName");
  if(!f || !name)return;
  f.addEventListener("change",()=>{name.textContent=f.files.length?`${f.files[0].name} · ${(f.files[0].size/1024).toFixed(1)} KB`:"No file selected"});
}
window.addEventListener("DOMContentLoaded",()=>{bindLogFile();clampNumericInputs();bindIntelligentMode();loadAll();setInterval(()=>{loadCampaigns();loadMetrics();loadCampaignHistory();loadSystemStatus();loadSchedulerStatus();loadStudioHome()},2000);setInterval(loadEvents,5000);});

let datasetAnalysis=null;
function bindTabs(){
  document.querySelectorAll('.tab-btn').forEach(btn=>{
    btn.addEventListener('click',()=>{
      document.querySelectorAll('.tab-btn').forEach(b=>b.classList.remove('active'));
      document.querySelectorAll('.tab-panel').forEach(p=>p.classList.remove('active'));
      btn.classList.add('active');
      const panel=q('#'+btn.dataset.tab); if(panel) panel.classList.add('active');
    });
  });
}
function bindDatasetFile(){
  const f=q('#datasetFile'), name=q('#datasetFileName');
  if(!f || !name)return;
  f.addEventListener('change',()=>{name.textContent=f.files.length?`${f.files[0].name} · ${(f.files[0].size/1024).toFixed(1)} KB`:'No CSV selected'});
}
async function analyzeDataset(){
  const f=q('#datasetFile')?.files?.[0];
  if(!f){q('#datasetResult').textContent='Select a CSV first'; return;}
  try{
    const fd=new FormData(); fd.append('dataset_file',f);
    q('#datasetResult').textContent='Analyzing dataset...';
    datasetAnalysis=await api('/api/dataset/analyze-file',{method:'POST',body:fd});
    renderDatasetAnalysis(datasetAnalysis);
  }catch(x){q('#datasetResult').textContent='Error: '+x.message;}
}
function renderDatasetAnalysis(r){
  const low=r.low_variability_columns||[], outs=r.outlier_columns||[];
  q('#datasetResult').innerHTML=`Dataset: <b>${r.filename}</b> · ${r.rows} rows · ${r.columns_count} columns<br><span>${low.length} zero/near-zero variability columns · ${r.outlier_row_count||0} rows with possible outliers · ${(r.duplicate_report&&r.duplicate_report.exact_duplicates)||0} exact duplicates</span>`;
  const cols=(r.columns||[]).map(c=>`<tr class="${c.mark_low_variability?'warn-row':''}"><td><label><input class="drop-col" type="checkbox" value="${escapeHtml(c.name)}" ${c.mark_low_variability?'checked':''}> ${escapeHtml(c.name)}</label></td><td>${c.type}</td><td>${c.missing}</td><td>${c.unique}</td><td>${c.normalized_entropy}</td><td>${Math.round((c.dominant_ratio||0)*100)}%</td><td>${escapeHtml(c.reason||'')}</td></tr>`).join('');
  const missing=(r.missing_report||[]).filter(x=>x.missing>0).map(x=>`<li><b>${escapeHtml(x.column)}</b>: ${x.missing} missing values (${Math.round(x.missing_ratio*10000)/100}%). Cause: ${escapeHtml(x.cause)}. Action: ${escapeHtml(x.suggested_action)}</li>`).join('') || '<li>No relevant missing values detected.</li>';
  const dup=r.duplicate_report||{};
  const types=(r.type_report||[]).filter(x=>x.issues).map(x=>`<li><b>${escapeHtml(x.column)}</b>: ${escapeHtml(x.issues)} · suggested type: ${escapeHtml(x.suggested_type)}</li>`).join('') || '<li>Data types appear consistent according to automatic inference.</li>';
  const outHtml=outs.length?outs.map(o=>`<li><b>${escapeHtml(o.column)}</b>: ${o.count} values out of range [${o.low}, ${o.high}]. ${escapeHtml(o.suggested_action||'')}</li>`).join(''):'<li>No relevant numeric outliers detected.</li>';
  const domain=(r.domain_logic_report||[]).map(x=>`<li><b>${escapeHtml(x.column)}</b>: ${escapeHtml(x.issue)} (${x.count})</li>`).join('') || '<li>No domain-rule issues detected by heuristics.</li>';
  const text=(r.text_quality_report||[]).map(x=>`<li><b>${escapeHtml(x.column)}</b>: spaces=${x.space_issues}, encoding suspicions=${x.encoding_suspicions}, variant groups=${(x.variant_groups||[]).length}. ${escapeHtml(x.suggested_action)}</li>`).join('') || '<li>No clear text/format issues detected.</li>';
  const corr=(r.correlation_report||[]).map(x=>`<li><b>${escapeHtml(x.column_a)}</b> ↔ <b>${escapeHtml(x.column_b)}</b>: r=${x.correlation}. ${escapeHtml(x.suggested_action)}</li>`).join('') || '<li>No numeric correlations ≥ 0.95 detected.</li>';
  const balance=(r.class_balance_report||[]).map(x=>`<li><b>${escapeHtml(x.column)}</b>: imbalance ratio ${x.imbalance_ratio}. ${escapeHtml(x.suggested_action)}</li>`).join('') || '<li>No typical target column was found or there are not multiple classes.</li>';
  q('#datasetSummary').innerHTML=`
    <h3>1. Dimensionality, entropy and variability</h3>
    <div class="small-table dataset-table"><table><thead><tr><th>Drop</th><th>Type</th><th>Missing</th><th>Unique</th><th>Norm. entropy</th><th>Dominant</th><th>Reason</th></tr></thead><tbody>${cols}</tbody></table></div>
    <h3>2. Integrity and missing values</h3><ul class="outlier-list">${missing}</ul>
    <h3>3. Duplicates</h3><ul class="outlier-list"><li>Exact duplicates: <b>${dup.exact_duplicates||0}</b>. ${escapeHtml(dup.suggested_action||'')}</li></ul>
    <h3>4. Data types</h3><ul class="outlier-list">${types}</ul>
    <h3>5. Outliers</h3><ul class="outlier-list">${outHtml}</ul>
    <h3>6. Consistency and domain logic</h3><ul class="outlier-list">${domain}</ul>
    <h3>7. Text and format quality</h3><ul class="outlier-list">${text}</ul>
    <h3>8. Correlation, redundancy and class balance</h3><ul class="outlier-list">${corr}${balance}</ul>`;
}
async function cleanDataset(){
  if(!datasetAnalysis || !datasetAnalysis.upload_id){q('#datasetResult').textContent='Analyze a CSV first'; return;}
  try{
    const drop=[...document.querySelectorAll('.drop-col:checked')].map(x=>x.value);
    const body={upload_id:datasetAnalysis.upload_id,service:q('#cleanService')?.value||'unknown',dataset_kind:q('#cleanKind')?.value||'all',drop_columns:drop,drop_outlier_rows:!!q('#dropOutliers')?.checked,drop_duplicate_rows:!!q('#dropDuplicates')?.checked,normalize_text:!!q('#normalizeText')?.checked};
    const r=await api('/api/dataset/clean',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
    q('#datasetResult').innerHTML=`Clean CSV generated: <a href="${r.download}">${r.file}</a><br><span>${r.rows}/${r.original_rows} rows kept · ${r.dropped_columns.length} columns removed</span>`;
  }catch(x){q('#datasetResult').textContent='Error: '+x.message;}
}
function escapeHtml(s){return String(s??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));}



function openStudioTab(tabId){
  const btn=document.querySelector(`.tab-btn[data-tab="${tabId}"]`);
  if(btn) btn.click();
}
function fmtMetric(v){
  if(v===null||v===undefined||v==='') return '-';
  const n=Number(v);
  if(!Number.isFinite(n)) return escapeHtml(v);
  return n.toFixed(3);
}
function pctMetric(v){
  const n=Number(v);
  if(!Number.isFinite(n)) return '-';
  return `${(n*100).toFixed(1)}%`;
}
function renderMiniBars(rows,labelKey='service'){
  if(!rows||!rows.length) return '<p class="muted">No data available yet.</p>';
  const max=Math.max(...rows.map(x=>Number(x.count||0)),1), total=rows.reduce((a,x)=>a+Number(x.count||0),0)||1;
  return rows.map(x=>{
    const count=Number(x.count||0), w=Math.round((count/max)*100), pct=(count/total*100).toFixed(1);
    return `<div class="mini-bar-row"><span>${escapeHtml(x[labelKey]||x.mode||'unknown')}</span><div class="mini-bar"><b style="width:${w}%"></b></div><em>${count} · ${pct}%</em></div>`;
  }).join('');
}
async function loadStudioHome(){
  try{
    const r=await api('/api/studio/home');
    const c=r.counts||{};
    if(q('#homeTargets')) q('#homeTargets').textContent=c.targets??'-';
    if(q('#homeProfiles')) q('#homeProfiles').textContent=c.profiles??'-';
    if(q('#homeEvents')) q('#homeEvents').textContent=c.events??'-';
    if(q('#homeMlExperiments')) q('#homeMlExperiments').textContent=c.ml_experiments??'-';
    const steps=[
      ['Targets configured',(c.targets||0)>0],
      ['Profiles available',(c.profiles||0)>0],
      ['Traffic events recorded',(c.events||0)>0],
      ['ML experiments generated',(c.ml_experiments||0)>0]
    ];
    if(q('#homeReadiness')) q('#homeReadiness').innerHTML=steps.map(([name,ok])=>`<div class="workflow-step ${ok?'done':'pending'}"><span>${ok?'✓':'○'}</span><b>${name}</b></div>`).join('');
    const activity=(r.recent_activity||[]).map(x=>{const kind=x.type==='ml'?'ML':(x.type==='report'?'REPORT':'TRAFFIC');return `<div class="activity-item ${x.status==='running'?'running':''}"><div><b><span class="activity-kind ${escapeHtml(x.type||'system')}">${kind}</span>${escapeHtml(x.title||'Activity')}</b><span>${escapeHtml(x.detail||x.status||'')}</span></div><time>${escapeHtml(x.timestamp||'')}</time></div>`}).join('');
    if(q('#homeActivity')) q('#homeActivity').innerHTML=activity||'<p class="muted">No platform activity yet.</p>';
    const best=(r.best_models||[]).map(x=>`<div class="best-model-card"><div><b>${escapeHtml(x.model_name)}</b><span>${escapeHtml(x.experiment_name||'Experiment')} · ${escapeHtml(x.service||'global')}</span></div><strong>MCC ${fmtMetric(x.mcc)}</strong></div>`).join('');
    if(q('#homeBestModels')) q('#homeBestModels').innerHTML=best||'<p class="muted">No trained model results yet.</p>';
    if(q('#homeEventDistribution')){
      const modes=r.events_by_mode||[], total=modes.reduce((a,x)=>a+Number(x.count||0),0)||1;
      const top=Math.max(...modes.map(x=>Number(x.count||0)),0)/total;
      const note=top>=.75?'<div class="insight-note warning"><b>Class distribution observation</b><span>One traffic mode represents '+(top*100).toFixed(1)+'% of recorded events. Review class balance before model training.</span></div>':'';
      q('#homeEventDistribution').innerHTML='<h3>By service</h3>'+renderMiniBars(r.events_by_service||[],'service')+'<h3>By mode</h3>'+renderMiniBars(r.events_by_mode||[],'mode')+note;
    }
    await loadGuidedHomeContext();
  }catch(e){console.warn('CAUSALIS home unavailable',e);}
}
function renderConfusionMatrix(cm){
  if(!Array.isArray(cm)||!cm.length) return '<p class="muted">No confusion matrix available.</p>';
  const max=Math.max(...cm.flat().map(Number),1);
  return `<div class="heatmap-wrap"><table class="confusion-table heatmap"><tbody>${cm.map(row=>`<tr>${row.map(cell=>{const a=.10+(.78*(Number(cell||0)/max));return `<td style="--heat:${a}">${escapeHtml(cell)}</td>`}).join('')}</tr>`).join('')}</tbody></table></div>`;
}
function metricBars(best){
  if(!best) return '';
  const metrics=[['Accuracy',best.accuracy],['Precision',best.precision_macro],['Recall',best.recall_macro],['F1 macro',best.f1_macro],['MCC',best.mcc]];
  return `<div class="metric-profile">${metrics.map(([n,v])=>{const pct=Math.max(0,Math.min(100,Number(v||0)*100));return `<div class="profile-row"><span>${n}</span><div><b style="width:${pct}%"></b></div><strong>${fmtMetric(v)}</strong></div>`}).join('')}</div>`;
}
function rankingBars(results){
  const rows=results.slice().sort((a,b)=>Number(b.mcc||-999)-Number(a.mcc||-999));
  if(!rows.length) return '<p class="muted">No valid model results.</p>';
  const min=Math.min(0,...rows.map(x=>Number(x.mcc||0))), max=Math.max(...rows.map(x=>Number(x.mcc||0)),.001), span=Math.max(max-min,.001);
  return `<div class="ranking-bars">${rows.map((x,i)=>{const w=Math.max(2,((Number(x.mcc||0)-min)/span)*100);return `<div class="ranking-row"><span><em>#${i+1}</em>${escapeHtml(x.model_name)}</span><div><b style="width:${w}%"></b></div><strong>${fmtMetric(x.mcc)}</strong></div>`}).join('')}</div>`;
}
function classDistribution(e){
  const cfg=e.config||{}, inner=cfg.config||cfg, dr=inner.dataset_report||cfg.dataset_report||{};
  const dist=dr.distribution_all||{}; const rows=Object.entries(dist).map(([label,count])=>({label,count:Number(count||0)}));
  if(!rows.length) return '<p class="muted">Class distribution is not available for this experiment.</p>';
  const max=Math.max(...rows.map(x=>x.count),1), total=rows.reduce((a,x)=>a+x.count,0)||1;
  return `<div class="class-bars">${rows.sort((a,b)=>b.count-a.count).map(x=>`<div class="class-row"><span>${escapeHtml(x.label)}</span><div><b style="width:${(x.count/max)*100}%"></b></div><strong>${x.count} <small>${((x.count/total)*100).toFixed(1)}%</small></strong></div>`).join('')}</div>`;
}
function performanceScatter(results){
  const pts=results.filter(x=>Number.isFinite(Number(x.train_seconds))&&Number.isFinite(Number(x.mcc)));
  if(!pts.length) return '<p class="muted">Training-time data is not available.</p>';
  const maxT=Math.max(...pts.map(x=>Number(x.train_seconds)),.001); const W=560,H=220,pad=34;
  const circles=pts.map((x,i)=>{const cx=pad+(Number(x.train_seconds)/maxT)*(W-pad*2),cy=H-pad-(Math.max(-1,Math.min(1,Number(x.mcc)))+1)/2*(H-pad*2);return `<g><circle cx="${cx}" cy="${cy}" r="6"><title>${escapeHtml(x.model_name)} · ${Number(x.train_seconds).toFixed(3)}s · MCC ${fmtMetric(x.mcc)}</title></circle><text x="${cx+8}" y="${cy-7}">${escapeHtml(x.model_name)}</text></g>`}).join('');
  return `<svg class="performance-scatter" viewBox="0 0 ${W} ${H}" role="img" aria-label="Training time versus MCC"><line x1="${pad}" y1="${H-pad}" x2="${W-pad}" y2="${H-pad}"/><line x1="${pad}" y1="${pad}" x2="${pad}" y2="${H-pad}"/>${circles}<text x="${W/2-45}" y="${H-5}">Training time →</text><text x="4" y="18">MCC ↑</text></svg>`;
}
async function loadStudioResults(){
  try{
    const r=await api('/api/studio/ml-dashboard');
    const exps=r.experiments||[];
    if(q('#studioExperimentList')){
      q('#studioExperimentList').innerHTML=exps.map((e,i)=>`<button type="button" class="experiment-pill ${i===0?'selected':''}" onclick="viewStudioExperiment('${escapeHtml(e.id)}', this)"><b>${escapeHtml(e.name||e.id)}</b><span>${escapeHtml(e.created_at||'')} · ${escapeHtml(e.best_model||'no best model')}</span></button>`).join('') || '<p class="muted">No ML experiments stored yet.</p>';
    }
    const rows=(r.top_results||[]).map(x=>`<tr><td>${escapeHtml(x.experiment_name)}</td><td>${escapeHtml(x.service)}</td><td>${escapeHtml(x.model_name)}</td><td>${fmtMetric(x.accuracy)}</td><td>${fmtMetric(x.f1_macro)}</td><td>${fmtMetric(x.mcc)}</td><td>${fmtMetric(x.roc_auc)}</td></tr>`).join('');
    if(q('#studioTopModels')) q('#studioTopModels').innerHTML=`<table><thead><tr><th>Experiment</th><th>Service</th><th>Model</th><th>Accuracy</th><th>F1</th><th>MCC</th><th>ROC-AUC</th></tr></thead><tbody>${rows||'<tr><td colspan="7">No model results available.</td></tr>'}</tbody></table>`;
    if(exps[0]) await viewStudioExperiment(exps[0].id);
  }catch(e){
    if(q('#studioExperimentDetail')) q('#studioExperimentDetail').textContent='Unable to load dashboard data: '+e.message;
  }
}
async function viewStudioExperiment(id, el){
  try{
    document.querySelectorAll('.experiment-pill').forEach(x=>x.classList.remove('selected'));
    if(el) el.classList.add('selected');
    const r=await api('/api/studio/ml-experiments/'+encodeURIComponent(id));
    const e=r.experiment||{}, results=(r.results||[]).filter(x=>!x.error);
    const best=results.slice().sort((a,b)=>(Number(b.mcc??-999)-Number(a.mcc??-999)) || (Number(b.f1_macro||0)-Number(a.f1_macro||0)))[0];
    const task=(e.target_column==='capec_category')?'CAPEC Multiclass Classification':'Binary Attack Detection';
    const classes=((e.config||{}).config||e.config||{}).dataset_report?.class_count;
    const metricCards=best?`<div class="kpi-grid compact-kpis"><div class="metric-card hero-metric"><span>Best model</span><strong>${escapeHtml(best.model_name)}</strong></div><div class="metric-card"><span>MCC</span><strong>${fmtMetric(best.mcc)}</strong></div><div class="metric-card"><span>F1 macro</span><strong>${fmtMetric(best.f1_macro)}</strong></div><div class="metric-card"><span>Accuracy</span><strong>${fmtMetric(best.accuracy)}</strong></div></div>`:'';
    const ranking=results.slice().sort((a,b)=>Number(b.mcc??-999)-Number(a.mcc??-999)).map(x=>`<tr><td>${escapeHtml(x.service)}</td><td>${escapeHtml(x.model_name)}</td><td>${fmtMetric(x.accuracy)}</td><td>${fmtMetric(x.precision_macro)}</td><td>${fmtMetric(x.recall_macro)}</td><td>${fmtMetric(x.f1_macro)}</td><td>${fmtMetric(x.mcc)}</td><td>${Number(x.train_seconds||0).toFixed(3)}s</td></tr>`).join('');
    const cm=best ? (best.confusion || JSON.parse(best.confusion_matrix_json||'[]')) : [];
    if(q('#studioExperimentDetail')) q('#studioExperimentDetail').innerHTML=`
      <div class="detail-head"><div><p class="eyebrow">${task}</p><h3>${escapeHtml(e.name||e.id)}</h3><p>${e.rows_total||'-'} records${classes?' · '+classes+' classes':''} · ${results.length} model results · ${escapeHtml(e.created_at||'')}</p></div><button type="button" onclick="openReportModal('${escapeHtml(e.id)}')">Generate report</button></div>
      ${metricCards}
      <div class="analytics-grid"><section class="analytics-card"><h3>Model Performance Ranking <span>MCC</span></h3>${rankingBars(results)}</section><section class="analytics-card"><h3>Best Model Metric Profile</h3>${metricBars(best)}</section></div>
      <div class="analytics-grid"><section class="analytics-card"><h3>Confusion Matrix</h3>${renderConfusionMatrix(cm)}</section><section class="analytics-card"><h3>Class Distribution</h3>${classDistribution(e)}</section></div>
      <section class="analytics-card wide-chart"><h3>Training Time vs Performance</h3>${performanceScatter(results)}</section>
      <details class="detail-table"><summary>Detailed model metrics</summary><div class="small-table dataset-table"><table><thead><tr><th>Service</th><th>Model</th><th>Accuracy</th><th>Precision</th><th>Recall</th><th>F1</th><th>MCC</th><th>Train time</th></tr></thead><tbody>${ranking||'<tr><td colspan="8">No valid model results.</td></tr>'}</tbody></table></div></details>`;
  }catch(e){
    if(q('#studioExperimentDetail')) q('#studioExperimentDetail').textContent='Unable to load experiment: '+e.message;
  }
}

window.addEventListener('DOMContentLoaded',()=>{
  bindTabs();bindDatasetFile();bindMlFile();bindBinaryMlFiles();bindCapecFiles();bindAutoMlFolders();renderCampaignActions();bindCapecMode();
  const pd=q('#pointScheduledDate'), pt=q('#pointScheduledTime'), ph=q('#pointScheduledStart');
  if(pd&&pt&&ph){
    const psync=()=>{ph.value=(pd.value&&pt.value)?`${pd.value}T${pt.value}`:'';};
    pd.addEventListener('change',psync); pt.addEventListener('change',psync); psync();
  }
  const ex=q('#groupExecuteNow'), d=q('#groupScheduledDate'), t=q('#groupScheduledTime'), hidden=q('#groupScheduledStart');
  if(ex&&d&&t&&hidden){
    const sync=()=>{
      const disabled=ex.checked;
      d.disabled=disabled; t.disabled=disabled;
      if(disabled){d.value='';t.value='';hidden.value='';}
      else if(d.value&&t.value){hidden.value=`${d.value}T${t.value}`;}
    };
    ex.addEventListener('change',sync); d.addEventListener('change',sync); t.addEventListener('change',sync); sync();
  }
});

let campaignActions=[];
function currentAction(){
  const o=formObj(q('#campaignForm'));
  delete o.scheduled_start;
  return o;
}
function renderCampaignActions(){
  const box=q('#campaignActionsBox');
  if(!box)return;
  if(!campaignActions.length){box.textContent='No actions yet.';return;}
  box.innerHTML=campaignActions.map((a,i)=>`<div class="action-item"><b>${i+1}. ${escapeHtml(a.target_name||'manual')}</b> · ${escapeHtml(String(a.service).toUpperCase())} · ${escapeHtml(a.host)}:${a.port} · ${escapeHtml(a.mode)} · perfil: ${escapeHtml(a.profile_name||'manual')} <button type="button" onclick="removeCampaignAction(${i})">remove</button></div>`).join('');
}
function addCurrentActionToGroup(){
  try{
    const a=currentAction();
    if(!a.host){msg('The action needs host/IP',true);return;}
    campaignActions.push(a);
    renderCampaignActions();
    msg('Action added to campaign');
  }catch(x){msg('Could not add action: '+x.message,true)}
}
function removeCampaignAction(i){campaignActions.splice(i,1);renderCampaignActions();}
function clearCampaignActions(){campaignActions=[];renderCampaignActions();msg('Campaign actions cleared');}
async function launchCampaignGroup(){
  try{
    const name=q('#groupName').value.trim();
    if(!name){msg('Campaign name is required',true);return;}
    if(unsafeText(name)){msg('Campaign name contains unsafe content',true);return;}
    if(!campaignActions.length){msg('Add at least one target + profile action',true);return;}
    const execute_now=!!q('#groupExecuteNow').checked;
    const sd=q('#groupScheduledDate')?.value||'';
    const st=q('#groupScheduledTime')?.value||'';
    const scheduled_start=execute_now?'':(sd&&st?`${sd}T${st}`:'');
    let scheduled_start_epoch=null;
    if(scheduled_start){
      const dt=new Date(scheduled_start);
      if(!Number.isNaN(dt.getTime())) scheduled_start_epoch=Math.floor(dt.getTime()/1000);
    }
    if(!execute_now && (!scheduled_start || scheduled_start_epoch===null)){msg('Select a valid date and time to schedule the campaign',true);return;}
    const body={name,actions:campaignActions,execute_now,scheduled_start,scheduled_start_epoch,notes:q('#groupNotes').value||''};
    const r=await api('/api/campaign-groups',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
    msg('Campaign created: '+r.campaign_group_id+' · status: '+(r.status||'created'));
    campaignActions=[];renderCampaignActions();
    await loadAll();
  }catch(x){msg('Error creating campaign: '+x.message,true)}
}
async function loadCampaignHistory(){
  const tb=q('#campaignHistoryTable tbody');
  if(!tb)return;
  const a=await api('/api/campaign-history');
  lastCampaignHistory=a;
  updateCampaignExecutionPanel(a);
  tb.innerHTML='';
  a.slice(0,30).forEach(c=>{
    tb.innerHTML+=`<tr><td>${escapeHtml(c.name||c.id)}</td><td>${escapeHtml(c.status||'')}</td><td>${c.actions_finished||0}/${c.actions_total||0}</td><td>${c.progress_pct||0}%</td><td><button type="button" onclick="reuseCampaign('${escapeHtml(c.id)}')">Reuse</button></td></tr>`;
  });
}


function updateCapecState(){
  const f=q('#campaignForm'); if(!f)return;
  const mode=f.elements['mode']?.value || 'normal';
  const capec=q('#attackCategory');
  if(!capec)return;
  if(mode==='normal'){
    capec.disabled=true;
    capec.value='abuse_of_functionality';
    capec.closest('.field')?.classList.add('disabled-field');
    capec.title='Disabled because traffic type is Normal. Enabled only for Anomaly.';
  }else{
    capec.disabled=false;
    capec.closest('.field')?.classList.remove('disabled-field');
    capec.title='Select the anomaly CAPEC category.';
  }
}
function bindCapecMode(){
  const f=q('#campaignForm'); if(!f)return;
  const mode=f.elements['mode'];
  if(mode){mode.addEventListener('change',updateCapecState);}
  updateCapecState();
}


let intelligentProposal=null;
function switchToTab(id){
  document.querySelectorAll('.tab-btn').forEach(b=>b.classList.remove('active'));
  document.querySelectorAll('.tab-panel').forEach(p=>p.classList.remove('active'));
  const btn=[...document.querySelectorAll('.tab-btn')].find(b=>b.dataset.tab===id);
  if(btn) btn.classList.add('active');
  const panel=q('#'+id); if(panel) panel.classList.add('active');
}
function bindIntelligentMode(){ /* Guided Discovery is now a first-class workspace. */ }

function setDiscoveryProfile(profile,button){
  document.querySelectorAll('.scan-profile').forEach(b=>b.classList.toggle('active',b===button));
  const ports={
    quick:'80,81,2121,2122,2222,2223,25,2525,587,1587,143,1143,993,1993,445,1445,5433,5434,8000,8001,51821,51823',
    standard:'21,22,23,25,53,80,81,110,139,143,389,443,445,465,587,636,993,995,1445,1587,1993,2121,2122,2222,2223,3306,3389,5432,5433,5434,8000,8001,8080,8443,9000,51821,51823',
    extended:'20-25,53,67-69,80,81,110,111,123,135,137-139,143,161,389,443,445,465,587,636,993,995,1143,1445,1587,1993,2121,2122,2222,2223,3306,3389,5432,5433,5434,6379,8000,8001,8080,8443,9000,27017,51821,51823'
  };
  if(profile!=='custom' && q('#intelligentPorts')) q('#intelligentPorts').value=ports[profile]||ports.quick;
  q('#customPortPanel')?.classList.toggle('custom-selected',profile==='custom');
}
function showMlWorkspace(view,button){
  document.querySelectorAll('.ml-mode-switch button').forEach(b=>b.classList.toggle('active',b===button));
  const map={binary:'#mlBinaryWorkspace',capec:'#mlCapecWorkspace',history:'#mlHistoryWorkspace'};
  document.querySelectorAll('.ml-workspace-card').forEach(c=>c.classList.remove('active'));
  q(map[view])?.classList.add('active');
}
function applyPortPreset(){
  const presets={
    extended8:'80,81,2121,2122,2222,2223,25,2525,587,1587,143,1143,993,1993,445,1445,5433,5434,8000,8001,51821,51823',
    web:'80,81,443,8000,8001,8080,8443,51821,51823',
    auth:'22,23,143,445,993,1143,1445,1993,2121,2122,2222,2223,3389,389',
    db:'3306,5432,5433,5434,1433,1521,6379,27017',
    mail:'25,2525,587,1587,143,1143,993,1993',
    common:'21,22,23,25,53,80,110,143,443,445,587,993,995,3306,5432,3389,389'
  };
  const v=q('#intelligentPortPreset')?.value||'extended8';
  if(q('#intelligentPorts')) q('#intelligentPorts').value=presets[v]||presets.extended8;
}

let intelligentScanController=null;
async function intelligentScan(){
  if(intelligentScanController) return;
  intelligentScanController=new AbortController();
  const startButton=q('#analyzeEnvironmentButton'),cancelButton=q('#cancelEnvironmentButton');
  if(startButton){startButton.disabled=true;startButton.textContent='Analyzing environment…';}
  if(cancelButton)cancelButton.disabled=false;
  try{
    const body={
      ip_range:q('#intelligentRange').value,
      ports:q('#intelligentPorts').value,
      timeout_seconds:Number(q('#intelligentTimeout').value||0.35),
      allow_non_private:!!q('#allowNonPrivateLabRange')?.checked,
      save_generated:false,
      campaign_objective:q('#intelligentObjective')?.value||'research_dataset',
      detection_profile:q('#intelligentDetectionProfile')?.value||'generic_extended_services',
      max_workers:48
    };
    validateNoInjection(body);
    if(body.allow_non_private && !confirm('You enabled scanning for a non-RFC1918 lab range. Continue only if this CIDR belongs to your controlled laboratory.')) return;
    q('#intelligentResult').textContent='Analyzing the authorized laboratory environment...'; if(q('#intelligentProgress')) q('#intelligentProgress').innerHTML='<div class="discovery-step">✓ Network scope validated</div><div class="discovery-step">● Concurrent service discovery running</div><div class="discovery-step idle">○ Experiment proposal pending</div><div class="bar"><div class="bar-fill blue" style="width:42%"></div></div>';
    intelligentProposal=await api('/api/intelligent/scan',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body),signal:intelligentScanController.signal});
    renderIntelligentProposal(intelligentProposal);
  }catch(x){
    if(x?.name==='AbortError'){
      q('#intelligentResult').textContent='Environment analysis cancelled by the user.';
      if(q('#intelligentProgress'))q('#intelligentProgress').innerHTML='<div class="discovery-step warning">■ Analysis cancelled safely</div><div class="discovery-step idle">No proposal was applied.</div>';
    }else q('#intelligentResult').textContent='Guided Discovery error: '+x.message;
  }finally{
    intelligentScanController=null;
    if(startButton){startButton.disabled=false;startButton.textContent='Analyze Environment';}
    if(cancelButton)cancelButton.disabled=true;
  }
}
function cancelIntelligentScan(){
  if(!intelligentScanController)return;
  q('#intelligentResult').textContent='Cancellation requested…';
  intelligentScanController.abort();
}
function renderIntelligentProposal(r){
  const targets=(r.targets||[]).map(t=>`<tr><td>${escapeHtml(t.name)}</td><td>${escapeHtml(t.host)}:${t.port}</td><td>${escapeHtml(t.service)}</td></tr>`).join('');
  const profiles=(r.profiles||[]).slice(0,80).map(p=>`<tr><td>${escapeHtml(p.name)}</td><td>${escapeHtml(p.service)}</td><td>${escapeHtml(p.mode)}</td><td>${escapeHtml(p.attack_category)}</td></tr>`).join('');
  q('#intelligentResult').innerHTML=`Environment analyzed: <b>${r.hosts_found}</b> hosts · <b>${(r.targets||[]).length}</b> service endpoints · <b>${(r.profiles||[]).length}</b> generated profiles · <b>${(r.campaign?.actions||[]).length}</b> proposed actions${r.non_private_allowed?' · <b>controlled non-RFC1918 scope</b>':''}`; if(q('#intelligentProgress')) q('#intelligentProgress').innerHTML=`<div class="discovery-step">✓ Network scope validated</div><div class="discovery-step">✓ Services identified from ${r.scan_checks||0} checks</div><div class="discovery-step">✓ Reviewable experiment proposal generated</div><div class="bar"><div class="bar-fill blue" style="width:100%"></div></div><p>Coverage: ${(r.coverage?.services_count)||0} services · ${(r.coverage?.capec_count)||0} CAPEC families · ${(r.coverage?.normal_actions)||0} normal actions · ${(r.coverage?.attack_actions)||0} attack actions. ${escapeHtml(r.coverage?.balance_note||'')}</p>`;
  q('#intelligentTargets').innerHTML=`<h3>Generated Targets</h3><p class="muted">Detected services are fingerprinted using the selected profile.</p><div class="small-table"><table><thead><tr><th>Name</th><th>Endpoint</th><th>Service</th></tr></thead><tbody>${targets||'<tr><td colspan="3">No open services found.</td></tr>'}</tbody></table></div>`;
  q('#intelligentProfiles').innerHTML=`<h3>Generated Profiles</h3><div class="small-table"><table><thead><tr><th>Name</th><th>Service</th><th>Mode</th><th>CAPEC</th></tr></thead><tbody>${profiles||'<tr><td colspan="4">No profiles generated.</td></tr>'}</tbody></table></div>`;
  q('#intelligentCampaign').innerHTML=`<h3>Campaign Proposal</h3><p>Name: <b>${escapeHtml(r.campaign?.name||'')}</b></p><p>Actions: ${(r.campaign?.actions||[]).length}</p><button type="button" onclick="applyIntelligentProposal()">Review and Create Experiment Draft</button>`;
}
async function applyIntelligentProposal(){
  if(!intelligentProposal){q('#intelligentResult').textContent='Run a scan first.';return;}
  try{
    const body={targets:intelligentProposal.targets||[],profiles:intelligentProposal.profiles||[],campaign_name:intelligentProposal.campaign?.name||'Intelligent Campaign Proposal',actions:intelligentProposal.campaign?.actions||[],notes:intelligentProposal.campaign?.notes||'Generated by Intelligent Mode'};
    const r=await api('/api/intelligent/apply',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
    await loadTargets(); await loadProfiles();
    campaignActions=(r.campaign_draft.actions||[]).map(a=>({...a}));
    q('#groupName').value=r.campaign_draft.name||'Intelligent Campaign Proposal';
    q('#groupNotes').value=r.campaign_draft.notes||'Generated by Intelligent Mode';
    q('#groupExecuteNow').checked=false;
    renderCampaignActions();
    q('#intelligentResult').textContent=`Saved ${r.targets_saved} targets and ${r.profiles_saved} profiles. Campaign draft loaded in Manual Mode for review.`;
    switchToTab('trafficTab');
  }catch(x){q('#intelligentResult').textContent='Apply error: '+x.message;}
}

let mlUploadId=null;
let mlFields=[];
async function mlUploadDataset(){
  const f=q('#mlDatasetFile')?.files?.[0];
  if(!f){q('#mlResult').textContent='Select a CSV first';return;}
  try{
    const fd=new FormData(); fd.append('dataset_file',f);
    q('#mlResult').textContent='Loading and analyzing dataset headers...';
    const r=await api('/api/dataset/analyze-file',{method:'POST',body:fd});
    mlUploadId=r.upload_id; mlFields=(r.columns||[]).map(c=>c.name);
    const target=q('#mlTargetColumn'), svc=q('#mlServiceColumn');
    target.innerHTML=''; svc.innerHTML='';
    mlFields.forEach(c=>{
      const o=document.createElement('option'); o.value=c; o.textContent=c; target.appendChild(o);
      const s=document.createElement('option'); s.value=c; s.textContent=c; svc.appendChild(s);
    });
    const preferred=['label','class','target','y','categoria','category','capec_category','attack_category'];
    const found=mlFields.find(c=>preferred.includes(c.toLowerCase()));
    if(found) target.value=found;
    const service=mlFields.find(c=>c.toLowerCase()==='service' || c.toLowerCase()==='servicio');
    if(service) svc.value=service;
    q('#mlResult').innerHTML=`ML dataset loaded: <b>${escapeHtml(r.filename)}</b> · ${r.rows} rows · ${r.columns_count} columns`;
  }catch(x){q('#mlResult').textContent='Error loading ML dataset: '+x.message;}
}
async function mlTrain(){
  if(!mlUploadId){q('#mlResult').textContent='Load an ML CSV dataset first';return;}
  const target=q('#mlTargetColumn').value;
  if(!target){q('#mlResult').textContent='Select a target variable';return;}
  try{
    q('#mlResult').textContent='Training models. This may take time depending on dataset size...';
    const body={upload_id:mlUploadId,target_column:target,service_column:q('#mlServiceColumn').value||'service',test_size:parseFloat(q('#mlTestSize').value||'0.25'),random_seed:parseInt(q('#mlRandomSeed').value||'42'),experiment_name:q('#mlExperimentName').value||'',group_by_service:!!q('#mlGroupByService').checked};
    const r=await api('/api/ml/train',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
    renderMlResults(r);
    await loadMlExperiments();
  }catch(x){q('#mlResult').textContent='Error training models: '+x.message;}
}
function renderMlResults(r){
  const ok=(r.results||[]).filter(x=>!x.error);
  const err=(r.results||[]).filter(x=>x.error);
  const rows=ok.sort((a,b)=>String(a.service).localeCompare(String(b.service)) || (b.mcc-a.mcc)).map(x=>`<tr><td>${escapeHtml(x.service)}</td><td>${escapeHtml(x.model_name)}</td><td>${x.accuracy}</td><td>${x.precision_macro}</td><td>${x.recall_macro}</td><td>${x.f1_macro}</td><td>${x.f1_weighted}</td><td>${x.mcc}</td><td>${x.balanced_accuracy??''}</td><td>${x.roc_auc??''}</td><td>${x.specificity??''}</td><td>${x.fpr??''}</td><td>${x.fnr??''}</td></tr>`).join('');
  const best=Object.entries(r.best_by_service||{}).map(([svc,b])=>`<li><b>${escapeHtml(svc)}</b>: ${escapeHtml(b.model)} · MCC=${b.mcc} · F1=${b.f1_macro} · Recall=${b.recall_macro}</li>`).join('');
  q('#mlResult').innerHTML=`Experiment saved: <b>${escapeHtml(r.experiment.name)}</b> · valid models: ${ok.length} · errors: ${err.length}`;
  q('#mlSummary').innerHTML=`<h3>Best model by service</h3><ul class="outlier-list">${best||'<li>Insufficient results.</li>'}</ul><h3>Metrics by model</h3><div class="small-table dataset-table"><table><thead><tr><th>Service</th><th>Model</th><th>Accuracy</th><th>Precision</th><th>Recall</th><th>F1 macro</th><th>F1 weighted</th><th>MCC</th><th>Balanced Acc.</th><th>ROC-AUC</th><th>Spec.</th><th>FPR</th><th>FNR</th></tr></thead><tbody>${rows}</tbody></table></div>`;
}
async function loadMlExperiments(){
  const tb=q('#mlExperimentsTable tbody'); if(!tb)return;
  try{
    const a=await api('/api/ml/experiments');
    tb.innerHTML='';
    a.forEach(e=>{tb.innerHTML+=`<tr><td>${escapeHtml(e.created_at||'')}</td><td>${escapeHtml(e.name||'')}</td><td>${escapeHtml(e.target_column||'')}</td><td>${escapeHtml(e.best_model||'')}</td><td><button type="button" onclick="openStudioTab('resultsTab');viewStudioExperiment('${escapeHtml(e.id)}')">View</button> <button type="button" onclick="openReportModal('${escapeHtml(e.id)}')">Report</button></td></tr>`});
  }catch(x){/* no bloquear UI */}
}
let reportExperimentId=null;
function openReportModal(id){
  if(mlJobRunning){q('#mlResult').textContent='A ML job is currently running. Report generation is temporarily disabled to avoid concurrent backend load.';return;}
  if(!id){q('#mlResult').textContent='Experiment id not found';return;}
  reportExperimentId=id;
  const modal=q('#reportModal'); if(modal){modal.hidden=false;document.body.classList.add('modal-open');}
}
function closeReportModal(){
  const modal=q('#reportModal'); if(modal)modal.hidden=true;
  document.body.classList.remove('modal-open');
}
function confirmGenerateReport(){
  if(!reportExperimentId)return;
  const selected=document.querySelector('input[name="reportFormat"]:checked');
  const format=selected?selected.value:'html';
  const url='/api/ml/experiments/'+encodeURIComponent(reportExperimentId)+'/report?format='+encodeURIComponent(format);
  closeReportModal();
  window.location=url;
  setTimeout(()=>{loadStudioHome();},1500);
}
function downloadMlReport(id){openReportModal(id);}
function bindMlFile(){
  const f=q('#mlDatasetFile'), name=q('#mlDatasetFileName');
  if(!f || !name)return;
  f.addEventListener('change',()=>{name.textContent=f.files.length?`${f.files[0].name} · ${(f.files[0].size/1024).toFixed(1)} KB`:'No CSV selected'; mlUploadId=null; q('#mlSummary').innerHTML='';});
}


async function loadSystemStatus(){
  try{
    const r=await api('/api/system/status');
    if(q('#systemLocalTime')) q('#systemLocalTime').textContent='Local system time: '+(r.local_time||'unknown');
    if(q('#systemUtcTime')) q('#systemUtcTime').textContent='UTC time: '+(r.utc_time||'unknown');
    if(q('#systemTimezone')) q('#systemTimezone').textContent='Time zone: '+(r.timezone||'unknown');
    if(q('#systemNtp')){
      q('#systemNtp').textContent='NTP: '+(r.ntp||'unknown');
      q('#systemNtp').className=(String(r.ntp).toLowerCase().includes('inactive')||String(r.ntp).toLowerCase()==='no')?'warn-text':'';
    }
  }catch(e){/* do not block UI */}
}
async function loadSchedulerStatus(){
  try{
    const r=await api('/api/scheduler/status');
    const scheduled=r.scheduled||[];
    if(q('#schedulerStarted')) q('#schedulerStarted').textContent='Status: '+(r.started?'Active':'Inactive');
    if(q('#schedulerLastCheck')) q('#schedulerLastCheck').textContent='Last check: '+(r.time||'unknown');
    if(q('#schedulerPending')) q('#schedulerPending').textContent='Pending campaigns: '+scheduled.length;
    if(q('#schedulerNext')){
      const next=scheduled.map(x=>x.scheduled_start).filter(Boolean).sort()[0]||'none';
      q('#schedulerNext').textContent='Next execution: '+next;
    }
  }catch(e){/* do not block UI */}
}
function selectRecommendedColumns(){document.querySelectorAll('.drop-col').forEach(x=>{const tr=x.closest('tr'); x.checked=!!(tr&&tr.classList.contains('warn-row'));});}
function unselectAllColumns(){document.querySelectorAll('.drop-col').forEach(x=>x.checked=false);}
let lastCampaignHistory=[];
function reuseCampaign(id){
  const c=lastCampaignHistory.find(x=>x.id===id);
  if(!c){msg('Campaign not found',true);return;}
  const payload=c.group_payload || (c.group_json?JSON.parse(c.group_json):null) || c;
  const actions=payload.actions || (payload.group_payload&&payload.group_payload.actions) || [];
  if(!actions.length){msg('This campaign has no reusable actions',true);return;}
  campaignActions=actions.map(a=>({...a}));
  q('#groupName').value=(c.name||'campaign')+'_copy';
  q('#groupNotes').value='Reused from campaign '+(c.name||c.id);
  q('#groupExecuteNow').checked=true;
  renderCampaignActions();
  msg('Campaign loaded as editable draft. Original history was not modified.');
}
function bindBinaryMlFiles(){
  [['#mlNormalTrainFile','#mlNormalTrainFileName'],['#mlAnomalyTrainFile','#mlAnomalyTrainFileName'],['#mlNormalTestFile','#mlNormalTestFileName'],['#mlAnomalyTestFile','#mlAnomalyTestFileName']].forEach(([fi,ni])=>{
    const f=q(fi), n=q(ni); if(!f||!n)return;
    f.addEventListener('change',()=>{n.textContent=f.files.length?`${f.files[0].name} · ${(f.files[0].size/1024).toFixed(1)} KB`:'No file selected';});
  });
}
let mlBatch=[];
let mlJobRunning=false;
function getSelectedMlModels(){
  return Array.from(document.querySelectorAll('.ml-model')).filter(x=>x.checked).map(x=>x.value);
}
function applyMlModelProfile(){
  const profile=q('#mlModelProfile')?.value||'fast';
  const sets={
    fast:['Decision Tree','Random Forest','Extra Trees','Logistic Regression','Naive Bayes'],
    balanced:['Decision Tree','Random Forest','Extra Trees','Logistic Regression','Naive Bayes','KNN','Gradient Boosting','AdaBoost'],
    full:['Decision Tree','Random Forest','Extra Trees','Logistic Regression','Naive Bayes','KNN','Gradient Boosting','AdaBoost','Hist Gradient Boosting','SVM','MLP']
  };
  if(profile==='custom') return;
  const chosen=new Set(sets[profile]||sets.fast);
  document.querySelectorAll('.ml-model').forEach(x=>{x.checked=chosen.has(x.value);});
}
function currentMlFiles(){
  return {
    normalTrain:q('#mlNormalTrainFile')?.files?.[0],
    anomalyTrain:q('#mlAnomalyTrainFile')?.files?.[0],
    normalTest:q('#mlNormalTestFile')?.files?.[0],
    anomalyTest:q('#mlAnomalyTestFile')?.files?.[0]
  };
}
function inferServiceFromFilename(name){
  const n=String(name||'').toLowerCase();
  return ['http','https','ftp','ssh','smtp','imap','dns','smb','ldap','rdp','mysql','postgresql'].find(s=>new RegExp('(^|[^a-z])'+s+'([^a-z]|$)').test(n))||null;
}
function mlFileWarnings(service,files){
  const warnings=[];
  Object.entries(files).forEach(([kind,file])=>{const inferred=inferServiceFromFilename(file?.name);if(inferred&&inferred!==service)warnings.push(`${kind}: ${file.name} appears to belong to ${inferred.toUpperCase()}, not ${service.toUpperCase()}.`);});
  return warnings;
}
function addMlServiceToBatch(){
  const files=currentMlFiles();
  if(!files.normalTrain||!files.anomalyTrain||!files.normalTest||!files.anomalyTest){q('#mlResult').textContent='Select the four CSV files before adding this service to the batch.';return;}
  const svc=q('#mlBinaryService')?.value||'unknown';
  const warnings=mlFileWarnings(svc,files);
  mlBatch.push({
    service:svc,
    experiment:q('#mlExperimentName')?.value||`${svc}_batch`,
    seed:q('#mlRandomSeed')?.value||'42',
    profile:q('#mlModelProfile')?.value||'fast',
    models:getSelectedMlModels(),
    files, warnings
  });
  renderMlBatch();
}
function clearMlBatch(){mlBatch=[];renderMlBatch();}
function renderMlBatch(){
  const box=q('#mlBatchList'); if(!box)return;
  if(!mlBatch.length){box.textContent='No services added.';return;}
  box.innerHTML='<ul>'+mlBatch.map((x,i)=>`<li>${i+1}. ${escapeHtml(x.service)} · ${escapeHtml(x.profile)} · models: ${x.models.length} · ${escapeHtml(x.files.normalTrain.name)} / ${escapeHtml(x.files.anomalyTrain.name)}${(x.warnings||[]).length?`<div class="batch-warning">⚠ ${(x.warnings||[]).map(escapeHtml).join('<br>')}</div>`:''}</li>`).join('')+'</ul><p class="muted">Run Batch Sequentially will process the queue one service at a time to avoid ML memory spikes.</p>';
}
function sanitizeExperimentNameClient(value){
  return String(value||'').replace(/[^a-zA-Z0-9_-]+/g,'_').replace(/^_+|_+$/g,'');
}
function setMlBusy(isBusy, message=''){
  mlJobRunning=!!isBusy;
  ['#mlTrainBtn','#mlBatchRunBtn','#mlBatchAddBtn','#mlValidateFolderBtn','#mlAutoTrainBtn','#capecTrainBtn','#capecAutoTrainBtn'].forEach(sel=>{const b=q(sel); if(b)b.disabled=mlJobRunning;});
  document.querySelectorAll('#mlExperimentsTable button').forEach(b=>{b.disabled=mlJobRunning;});
  if(message) q('#mlResult').innerHTML=`<div class="ml-status-running">${escapeHtml(message)}</div>`;
}
async function submitBinaryMlJob(job, indexLabel=''){
  const fd=new FormData();
  fd.append('service',job.service||q('#mlBinaryService').value||'unknown');
  fd.append('experiment_name',sanitizeExperimentNameClient(job.experiment||q('#mlExperimentName').value||''));
  fd.append('random_seed',positiveNumber(job.seed||q('#mlRandomSeed').value||'42','Random seed',0,999999999));
  fd.append('model_profile',job.profile||q('#mlModelProfile')?.value||'fast');
  fd.append('selected_models_json',JSON.stringify(job.models&&job.models.length?job.models:getSelectedMlModels()));
  fd.append('normal_training_file',job.files.normalTrain); fd.append('anomaly_training_file',job.files.anomalyTrain); fd.append('normal_test_file',job.files.normalTest); fd.append('anomaly_test_file',job.files.anomalyTest);
  q('#mlResult').innerHTML=`<div class="progress-note">${indexLabel} Building binary datasets, applying leakage-safe exclusions, creating engineered text features, and training selected models for <b>${escapeHtml(job.service)}</b>...</div>`;
  const created=await api('/api/tasks/ml/binary',{method:'POST',body:fd});
  const task=await monitorPersistentTask(created.task_id,'#mlResult');
  if(task.status!=='completed') throw new Error(task.error||`Task ${task.status}`);
  return task.result||{};
}
async function runMlBatch(){
  if(!mlBatch.length){q('#mlResult').textContent='No services in batch.';return;}
  const completed=[]; const errors=[];
  setMlBusy(true,'Running ML batch sequentially. Please do not start reports or other ML jobs.');
  try{
    for(let i=0;i<mlBatch.length;i++){
      const job=mlBatch[i];
      q('#mlSummary').innerHTML=`<div class="progress-note">Batch progress: ${i+1}/${mlBatch.length}. Running ${escapeHtml(job.service)}. Completed: ${completed.join(', ')||'none'}.</div>`;
      try{ await submitBinaryMlJob(job,`Batch ${i+1}/${mlBatch.length}:`); completed.push(job.service); }
      catch(e){ errors.push(`${job.service}: ${e.message}`); q('#mlSummary').innerHTML+=`<div class="progress-note error">${escapeHtml(job.service)} failed: ${escapeHtml(e.message)}</div>`; }
    }
    q('#mlResult').innerHTML=`<div class="progress-note ok">Batch completed. Services completed: ${completed.join(', ')||'none'}. Errors: ${errors.length}</div>`;
    if(errors.length) q('#mlResult').innerHTML+=`<pre>${escapeHtml(errors.join('\n'))}</pre>`;
    await loadMlExperiments();
  }finally{ setMlBusy(false); }
}

async function mlTrainBinary(){
  const files=currentMlFiles();
  if(!files.normalTrain||!files.anomalyTrain||!files.normalTest||!files.anomalyTest){q('#mlResult').textContent='Select the four required datasets: normal/anomaly training and normal/anomaly test.';return;}
  setMlBusy(true,'Training binary models. Feature engineering and report generation may take several minutes.');
  try{
    const job={service:q('#mlBinaryService').value||'unknown',experiment:sanitizeExperimentNameClient(q('#mlExperimentName').value||''),seed:q('#mlRandomSeed').value||'42',profile:q('#mlModelProfile')?.value||'fast',models:getSelectedMlModels(),files};
    await submitBinaryMlJob(job,'Single service:');
  }catch(x){q('#mlResult').textContent='Error training binary models: '+x.message;}
  finally{ setMlBusy(false); }
}


function bindCapecFiles(){
  const f=q('#capecAnomalyFiles'), n=q('#capecAnomalyFilesName');
  if(!f||!n)return;
  f.addEventListener('change',()=>{
    if(!f.files.length){n.textContent='No CSV files selected';return;}
    const total=Array.from(f.files).reduce((a,x)=>a+x.size,0);
    n.textContent=`${f.files.length} CSV selected · ${(total/1024).toFixed(1)} KB`;
  });
}
function getSelectedCapecModels(){
  return Array.from(document.querySelectorAll('.capec-model')).filter(x=>x.checked).map(x=>x.value);
}
function applyCapecModelProfile(){
  const profile=q('#capecModelProfile')?.value||'balanced';
  const sets={
    fast:['Decision Tree','Random Forest','Extra Trees','Logistic Regression','Naive Bayes'],
    balanced:['Decision Tree','Random Forest','Extra Trees','Logistic Regression','Naive Bayes','KNN','Gradient Boosting','AdaBoost'],
    full:['Decision Tree','Random Forest','Extra Trees','Logistic Regression','Naive Bayes','KNN','Gradient Boosting','AdaBoost','Hist Gradient Boosting','SVM','MLP']
  };
  if(profile==='custom') return;
  const chosen=new Set(sets[profile]||sets.balanced);
  document.querySelectorAll('.capec-model').forEach(x=>{x.checked=chosen.has(x.value);});
}
function renderCapecDistribution(dist){
  if(!dist) return '';
  const cats=Object.entries(dist.by_category||{}).map(([k,v])=>`<tr><td>${escapeHtml(k)}</td><td>${v}</td></tr>`).join('');
  const services=Object.entries(dist.by_service||{}).map(([k,v])=>`<tr><td>${escapeHtml(k)}</td><td>${v}</td></tr>`).join('');
  return `<h3>CAPEC Distribution</h3><div class="row two"><div class="small-table dataset-table"><table><thead><tr><th>CAPEC category</th><th>Rows</th></tr></thead><tbody>${cats}</tbody></table></div><div class="small-table dataset-table"><table><thead><tr><th>Service</th><th>Rows</th></tr></thead><tbody>${services}</tbody></table></div></div>`;
}
async function trainCapecMulticlass(){
  const files=q('#capecAnomalyFiles')?.files;
  if(!files||!files.length){q('#capecResult').textContent='Select one or more clean anomaly CSV files first.';return;}
  setMlBusy(true,'Building CAPEC multiclass dataset and training attribution models.');
  try{
    const fd=new FormData();
    fd.append('experiment_name',sanitizeExperimentNameClient(q('#capecExperimentName').value||'CAPEC_multiclass'));
    fd.append('random_seed',positiveNumber(q('#capecRandomSeed').value||'42','Random seed',0,999999999));
    fd.append('test_size',positiveNumber(q('#capecTestSize').value||'0.25','Test size',0.1,0.5));
    fd.append('target_column',q('#capecTargetColumn').value||'capec_category');
    fd.append('model_profile',q('#capecModelProfile').value||'balanced');
    fd.append('selected_models_json',JSON.stringify(getSelectedCapecModels()));
    Array.from(files).forEach(f=>fd.append('anomaly_files',f));
    q('#capecResult').innerHTML='<div class="progress-note">Concatenating clean anomaly datasets, calculating CAPEC distribution, generating stratified train/test split and training selected models...</div>';
    const created=await api('/api/tasks/ml/capec',{method:'POST',body:fd});
    const t=await monitorPersistentTask(created.task_id,'#capecResult');
    const r=t.result||{};
    if(r.experiment){
      q('#capecResult').innerHTML+=`<p>CAPEC experiment saved: <b>${escapeHtml(r.experiment.name)}</b> · target: <b>${escapeHtml(r.experiment.target_column)}</b> · rows: ${r.experiment.rows_total}</p>`;
      if(r.capec_dataset_download||r.capec_training_download||r.capec_test_download){
        q('#capecResult').innerHTML += `<br><a href="${r.capec_dataset_download}">capec_multiclass_dataset</a> · <a href="${r.capec_training_download}">training split</a> · <a href="${r.capec_test_download}">test split</a>`;
      }
      q('#capecSummary').innerHTML=renderCapecDistribution(r.distribution||{}) + (q('#mlSummary')?.innerHTML||'');
    }
    await loadMlExperiments();
  }catch(x){q('#capecResult').textContent='Error in CAPEC multiclass training: '+x.message;}
  finally{ setMlBusy(false); }
}


function fmtSeconds(v){
  if(!Number.isFinite(v)||v<0) return '-';
  v=Math.round(v); const h=Math.floor(v/3600), m=Math.floor((v%3600)/60), sec=v%60;
  return `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(sec).padStart(2,'0')}`;
}
function updateCampaignExecutionPanel(list){
  const name=q('#campaignExecName'); if(!name) return;
  const running=(list||[]).find(c=>String(c.status||'').toLowerCase()==='running') || null;
  if(!running){
    q('#campaignExecName').textContent='Campaign: none running';
    q('#campaignExecProgress').textContent='Progress: -';
    q('#campaignExecElapsed').textContent='Elapsed: -';
    q('#campaignExecRemaining').textContent='Estimated remaining: -';
    q('#campaignExecActions').textContent='Actions: -';
    return;
  }
  const started=running.started_at?Date.parse(running.started_at):NaN;
  const elapsed=Number.isFinite(started)?(Date.now()-started)/1000:NaN;
  const pct=Number(running.progress_pct||0);
  const remaining=(pct>0&&Number.isFinite(elapsed))?elapsed*(100-pct)/pct:NaN;
  q('#campaignExecName').textContent=`Campaign: ${running.name||running.id}`;
  q('#campaignExecProgress').textContent=`Progress: ${pct}%`;
  q('#campaignExecElapsed').textContent=`Elapsed: ${fmtSeconds(elapsed)}`;
  q('#campaignExecRemaining').textContent=`Estimated remaining: ${fmtSeconds(remaining)}`;
  q('#campaignExecActions').textContent=`Actions: ${running.actions_finished||0}/${running.actions_total||0}`;
}


document.addEventListener('change',e=>{
  if(e.target?.name==='wizardInfrastructure')updateWizardInfrastructure();
  if(e.target?.id==='wizardDiscoveryProfile')updateWizardDiscoveryProfile();
});
window.addEventListener('keydown',e=>{if(e.key==='Escape')closeReportModal();});
window.addEventListener('click',e=>{const modal=q('#reportModal');if(modal&&!modal.hidden&&e.target===modal)closeReportModal();});


// ---------------------------------------------------------------------------
// CAUSALIS v0.3 Experiment Workspace
// ---------------------------------------------------------------------------
let causalisExperiments=[];
let currentWorkspaceExperiment=null;
let currentWorkflowSteps=[];

function showNewExperimentForm(){ const p=q('#newExperimentPanel'); if(p){p.hidden=false; q('#newExperimentName')?.focus();} }
function hideNewExperimentForm(){ const p=q('#newExperimentPanel'); if(p)p.hidden=true; }
function experimentStatusBadge(status){
  const s=String(status||'draft').toLowerCase();
  return `<span class="workspace-status ${escapeHtml(s)}">${escapeHtml(s)}</span>`;
}
async function loadExperimentWorkspaces(){
  try{
    const r=await api('/api/experiments');
    causalisExperiments=r.experiments||[];
    const currentId=r.current_experiment_id;
    const list=q('#experimentWorkspaceList');
    if(list){
      list.innerHTML=causalisExperiments.map(e=>`<button type="button" class="workspace-item ${e.id===currentId?'selected':''}" onclick="selectExperimentWorkspace('${escapeHtml(e.id)}',this)"><span><b>${escapeHtml(e.name)}</b><small>${escapeHtml(e.objective||'experiment')} · ${escapeHtml(e.updated_at||'')}</small></span>${experimentStatusBadge(e.status)}</button>`).join('')||'<p class="muted">No experiments available.</p>';
    }
    if(currentId) await loadExperimentWorkspace(currentId,false);
  }catch(e){
    const list=q('#experimentWorkspaceList'); if(list)list.innerHTML=`<p class="error">Unable to load experiments: ${escapeHtml(e.message)}</p>`;
  }
}
async function refreshCurrentExperimentSummary(){
  try{
    const e=await api('/api/experiments/current');
    currentWorkspaceExperiment=e;
    updateExperimentContext(e);
  }catch(_){ }
}
function updateExperimentContext(e){
  const name=e?.name||'No experiment selected';
  const status=e?.status||'draft';
  if(q('#sidebarExperimentName'))q('#sidebarExperimentName').textContent=name;
  if(q('#sidebarExperimentStatus'))q('#sidebarExperimentStatus').textContent=status;
  if(q('#headerExperimentButton'))q('#headerExperimentButton').textContent=name;
}
async function selectExperimentWorkspace(id,el){
  try{
    await api(`/api/experiments/${encodeURIComponent(id)}/select`,{method:'POST'});
    document.querySelectorAll('.workspace-item').forEach(x=>x.classList.remove('selected')); if(el)el.classList.add('selected');
    await loadExperimentWorkspace(id,true);
    msg('Experiment workspace selected');
  }catch(e){msg('Unable to select experiment: '+e.message,true)}
}
async function loadExperimentWorkspace(id,refreshList=false){
  const e=await api(`/api/experiments/${encodeURIComponent(id)}`);
  currentWorkspaceExperiment=e;
  currentWorkflowSteps=(e.workflow||[]).slice().sort((a,b)=>Number(a.order||0)-Number(b.order||0));
  updateExperimentContext(e);
  renderExperimentWorkspace(e);
  if(refreshList){
    const idx=causalisExperiments.findIndex(x=>x.id===e.id); if(idx>=0)causalisExperiments[idx]=e;
  }
}
function readinessItem(label,ready,detail){
  return `<div class="readiness-item ${ready?'ready':'pending'}"><i>${ready?'✓':'○'}</i><span><b>${escapeHtml(label)}</b><small>${escapeHtml(detail||'')}</small></span></div>`;
}
function renderExperimentWorkspace(e){
  const r=e.readiness||{};
  const overview=q('#experimentWorkspaceOverview');
  if(overview)overview.innerHTML=`
    <div class="workspace-overview-head"><div><p class="eyebrow">${escapeHtml(e.objective||'experiment')}</p><h2>${escapeHtml(e.name)}</h2><p>${escapeHtml(e.description||'No description provided.')}</p></div><div>${experimentStatusBadge(e.status)}<button type="button" class="secondary-btn" onclick="openStudioTab('trafficTab')">Continue Experiment</button></div></div>
    <div class="kpi-grid workspace-kpis"><div class="metric-card"><span>Campaigns</span><strong>${e.campaigns_total||0}</strong></div><div class="metric-card"><span>Completed</span><strong>${e.campaigns_completed||0}</strong></div><div class="metric-card"><span>Datasets</span><strong>${e.datasets_available||0}</strong></div><div class="metric-card"><span>ML Runs</span><strong>${e.ml_experiments||0}</strong></div><div class="metric-card"><span>Reports</span><strong>${e.reports_available||0}</strong></div></div>
    <div class="workspace-readiness">${readinessItem('Targets',r.targets,'Environment configured')}${readinessItem('Profiles',r.profiles,'Traffic behavior defined')}${readinessItem('Traffic',r.traffic,'Campaign completed')}${readinessItem('Dataset',r.dataset,'Clean data available')}${readinessItem('Machine Learning',r.machine_learning,'Models evaluated')}${readinessItem('Report',r.report,'Experiment documented')}</div>`;
  renderWorkflowEditor();
  loadCurrentArtifacts();
  const timeline=q('#experimentActivityTimeline');
  if(timeline){
    const acts=e.activities||[];
    timeline.innerHTML=acts.map(a=>`<div class="timeline-item"><i class="${escapeHtml(a.status||'info')}"></i><div><b>${escapeHtml(a.summary)}</b><span>${escapeHtml(a.activity_type||'activity')} · ${escapeHtml(a.created_at||'')}</span></div></div>`).join('')||'<p class="muted">No workspace activity recorded yet.</p>';
  }
}
function renderWorkflowEditor(){
  const box=q('#workflowStepList'); if(!box)return;
  box.innerHTML=currentWorkflowSteps.map((s,i)=>`<div class="workflow-step ${s.enabled?'':'disabled'}" data-index="${i}"><span class="step-order">${i+1}</span><div><b>${escapeHtml(s.name)}</b><small>${escapeHtml(s.step_type)}${s.technique_id?' · '+escapeHtml(s.technique_id):''}</small></div><div class="workflow-step-actions"><button type="button" onclick="moveWorkflowStep(${i},-1)" ${i===0?'disabled':''}>↑</button><button type="button" onclick="moveWorkflowStep(${i},1)" ${i===currentWorkflowSteps.length-1?'disabled':''}>↓</button><button type="button" onclick="toggleWorkflowStep(${i})">${s.enabled?'Disable':'Enable'}</button></div></div>`).join('')||'<p class="muted">No workflow steps.</p>';
}
function moveWorkflowStep(index,delta){
  const j=index+delta; if(j<0||j>=currentWorkflowSteps.length)return;
  [currentWorkflowSteps[index],currentWorkflowSteps[j]]=[currentWorkflowSteps[j],currentWorkflowSteps[index]];
  renderWorkflowEditor();
}
function toggleWorkflowStep(index){ currentWorkflowSteps[index].enabled=!currentWorkflowSteps[index].enabled; renderWorkflowEditor(); }
async function saveCurrentWorkflow(){
  if(!currentWorkspaceExperiment){msg('Select an experiment first',true);return;}
  try{
    const steps=currentWorkflowSteps.map((s,i)=>({...s,order:i+1}));
    const r=await api(`/api/experiments/${encodeURIComponent(currentWorkspaceExperiment.id)}/workflow`,{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({steps})});
    currentWorkflowSteps=r.steps||steps; renderWorkflowEditor(); msg('Workflow saved');
    await loadExperimentWorkspace(currentWorkspaceExperiment.id);
  }catch(e){msg('Unable to save workflow: '+e.message,true)}
}
async function createExperimentWorkspace(){
  const name=q('#newExperimentName')?.value?.trim(); if(!name){msg('Experiment name is required',true);return;}
  const tags=(q('#newExperimentTags')?.value||'').split(',').map(x=>x.trim()).filter(Boolean);
  const body={name,description:q('#newExperimentDescription')?.value||'',objective:q('#newExperimentObjective')?.value||'dataset_generation',tags};
  try{
    const e=await api('/api/experiments',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
    hideNewExperimentForm();
    ['#newExperimentName','#newExperimentDescription','#newExperimentTags'].forEach(sel=>{if(q(sel))q(sel).value=''});
    await loadExperimentWorkspaces();
    openStudioTab('experimentsTab');
    msg('Experiment workspace created');
  }catch(e){msg('Unable to create experiment: '+e.message,true)}
}
async function cloneCurrentExperiment(){
  if(!currentWorkspaceExperiment){msg('Select an experiment first',true);return;}
  try{
    const e=await api(`/api/experiments/${encodeURIComponent(currentWorkspaceExperiment.id)}/clone`,{method:'POST'});
    await loadExperimentWorkspaces(); openStudioTab('experimentsTab'); msg('Experiment cloned: '+e.name);
  }catch(e){msg('Unable to clone experiment: '+e.message,true)}
}



// ---------------------------------------------------------------------------
// CAUSALIS v0.4 Guided Experimentation
// ---------------------------------------------------------------------------
let guidedWizardStep=1;

function recommendationIcon(stage){
  return ({environment:'◎',profiles:'◌',traffic:'▶',data:'▦',ml:'◇',report:'▤',complete:'✓'})[stage]||'→';
}
async function loadGuidedHomeContext(){
  try{
    const e=await api('/api/experiments/current');
    currentWorkspaceExperiment=e;
    updateExperimentContext(e);
    const pct=Number(e.progress_pct||0), rec=e.recommendation||{};
    if(q('#homeCurrentExperiment'))q('#homeCurrentExperiment').textContent=e.name||'Current experiment';
    if(q('#homeCurrentObjective'))q('#homeCurrentObjective').textContent=`${String(e.objective||'experiment').replaceAll('_',' ')} · ${e.status||'draft'}`;
    if(q('#homeExperimentProgress'))q('#homeExperimentProgress').innerHTML=`<strong>${pct}%</strong><span>complete</span>`;
    if(q('#homeExperimentProgressBar'))q('#homeExperimentProgressBar').style.width=`${pct}%`;
    const panel=q('#homeRecommendation');
    if(panel){
      panel.innerHTML=`<i>${recommendationIcon(rec.stage)}</i><div><small>Recommended next action</small><b>${escapeHtml(rec.title||'Continue experiment')}</b><span>${escapeHtml(rec.detail||'')}</span></div><button type="button" class="primary-action" onclick="openStudioTab('${escapeHtml(rec.tab||'experimentsTab')}')">${escapeHtml(rec.action||'Continue')}</button>`;
    }
  }catch(e){console.warn('Current experiment context unavailable',e);}
}
function openGuidedWizard(){
  guidedWizardStep=1;
  const modal=q('#guidedWizardModal'); if(!modal)return;
  modal.hidden=false; document.body.classList.add('modal-open');
  updateWizardInfrastructure(); updateWizardView(); setTimeout(()=>q('#wizardName')?.focus(),80);
}
function closeGuidedWizard(){const m=q('#guidedWizardModal');if(m)m.hidden=true;document.body.classList.remove('modal-open');}
function wizardValue(name){return document.querySelector(`input[name="${name}"]:checked`)?.value||'';}
function wizardDiscoveryPortsFor(profile){
  const sets={quick:'80,81,2121,2122,2222,2223,25,2525,587,1587,143,1143,993,1993,445,1445,5433,5434,8000,8001,51821,51823',standard:'21,22,23,25,53,80,81,110,139,143,389,443,445,465,587,636,993,995,1445,1587,1993,2121,2122,2222,2223,3306,3389,5432,5433,5434,8000,8001,8080,8443,9000,51821,51823',extended:'1-1024,1445,1587,1993,2121,2122,2222,2223,2375,2376,3306,3389,5432,5433,5434,5672,5900,5985,5986,6379,8000,8001,8080,8443,9000,9200,27017,51821,51823'};
  return sets[profile]||'';
}
function updateWizardInfrastructure(){
  const mode=wizardValue('wizardInfrastructure')||'existing_lab', box=q('#wizardDiscoveryConfig');
  if(box)box.hidden=mode!=='intelligent_discovery';
}
function updateWizardDiscoveryProfile(){
  const profile=q('#wizardDiscoveryProfile')?.value||'quick', input=q('#wizardDiscoveryPorts');
  if(input && profile!=='custom')input.value=wizardDiscoveryPortsFor(profile);
}
function applyWizardDiscoveryToIntelligentMode(payload){
  const d=payload.discovery||{};
  if(q('#intelligentRange'))q('#intelligentRange').value=d.ip_range||'';
  if(q('#intelligentPorts'))q('#intelligentPorts').value=d.ports||wizardDiscoveryPortsFor(d.scan_profile||'quick');
  if(q('#intelligentTimeout'))q('#intelligentTimeout').value=Number(d.timeout_seconds||0.35);
  if(q('#intelligentDetectionProfile'))q('#intelligentDetectionProfile').value=d.detection_profile||'generic_extended_services';
  if(q('#allowNonPrivateLabRange'))q('#allowNonPrivateLabRange').checked=!!d.allow_non_private;
  document.querySelectorAll('[data-scan-profile]').forEach(x=>x.classList.toggle('active',x.dataset.scanProfile===(d.scan_profile||'quick')));
  if(q('#intelligentProgress'))q('#intelligentProgress').innerHTML='<div class="discovery-step">✓ Scope imported from Guided Experiment</div><div class="discovery-step idle">○ Review the range and ports</div><div class="discovery-step idle">○ Click Analyze Environment to start</div>';
  if(q('#intelligentResult'))q('#intelligentResult').textContent='Intelligent Mode is ready. Review the authorized scope and explicitly start discovery.';
}
function updateWizardView(){
  document.querySelectorAll('.wizard-step').forEach(x=>x.classList.toggle('active',Number(x.dataset.wizardStep)===guidedWizardStep));
  const pct=(guidedWizardStep/6)*100;
  if(q('#wizardProgressBar'))q('#wizardProgressBar').style.width=`${pct}%`;
  if(q('#wizardStepLabel'))q('#wizardStepLabel').textContent=`Step ${guidedWizardStep} of 6`;
  if(q('#wizardBackBtn'))q('#wizardBackBtn').disabled=guidedWizardStep===1;
  if(q('#wizardNextBtn'))q('#wizardNextBtn').hidden=guidedWizardStep===6;
  if(q('#wizardCreateBtn'))q('#wizardCreateBtn').hidden=guidedWizardStep!==6;
  updateWizardInfrastructure();
  if(guidedWizardStep===6)renderWizardReview();
}
function wizardNext(){
  if(guidedWizardStep===1 && !q('#wizardName')?.value.trim()){msg('Experiment name is required',true);q('#wizardName')?.focus();return;}
  if(guidedWizardStep===2 && wizardValue('wizardInfrastructure')==='intelligent_discovery' && !q('#wizardDiscoveryRange')?.value.trim()){msg('Enter the authorized laboratory CIDR range',true);q('#wizardDiscoveryRange')?.focus();return;}
  guidedWizardStep=Math.min(6,guidedWizardStep+1);updateWizardView();
}
function wizardPrevious(){guidedWizardStep=Math.max(1,guidedWizardStep-1);updateWizardView();}
function guidedWizardPayload(){
  const outputs=[]; if(q('#wizardBinary')?.checked)outputs.push('binary'); if(q('#wizardCapec')?.checked)outputs.push('capec');
  const ml=wizardValue('wizardMl')||'fast'; const formats=[]; if(q('#wizardReportHtml')?.checked)formats.push('html'); if(q('#wizardReportPdf')?.checked)formats.push('pdf');
  const infra=wizardValue('wizardInfrastructure')||'existing_lab';
  const discovery=infra==='intelligent_discovery'?{ip_range:q('#wizardDiscoveryRange')?.value.trim()||'',scan_profile:q('#wizardDiscoveryProfile')?.value||'quick',ports:q('#wizardDiscoveryPorts')?.value.trim()||'',timeout_seconds:Number(q('#wizardDiscoveryTimeout')?.value||0.35),detection_profile:q('#wizardDetectionProfile')?.value||'generic_extended_services',allow_non_private:!!q('#wizardAllowNonPrivate')?.checked}:null;
  return {name:q('#wizardName')?.value.trim(),description:q('#wizardDescription')?.value||'',objective:q('#wizardObjective')?.value||'dataset_generation',tags:['guided'],infrastructure_mode:infra,traffic_profile:wizardValue('wizardTraffic')||'quick',dataset_outputs:outputs.length?outputs:['binary'],ml_profile:ml==='none'?'fast':ml,report_formats:formats.length?formats:['html'],include_ml:ml!=='none',include_report:formats.length>0,discovery};
}
function renderWizardReview(){
  const p=guidedWizardPayload(); const goal=p.objective.replaceAll('_',' '), outputs=p.dataset_outputs.join(' + '), reports=p.report_formats.join(' + ').toUpperCase();
  const estimates={quick:['5–10 min','Low'],balanced:['15–30 min','Medium'],extended:['30–90 min','High'],custom:['User-defined','Custom']}[p.traffic_profile]||['User-defined','Custom'];
  if(q('#wizardReview'))q('#wizardReview').innerHTML=`<div class="review-grid"><div><small>Experiment</small><b>${escapeHtml(p.name||'Unnamed')}</b></div><div><small>Objective</small><b>${escapeHtml(goal)}</b></div><div><small>Environment</small><b>${escapeHtml(p.infrastructure_mode.replaceAll('_',' '))}</b></div>${p.discovery?`<div><small>Discovery scope</small><b>${escapeHtml(p.discovery.ip_range)} · ${escapeHtml(p.discovery.scan_profile)}</b></div>`:''}<div><small>Traffic</small><b>${escapeHtml(p.traffic_profile)}</b></div><div><small>Datasets</small><b>${escapeHtml(outputs)}</b></div><div><small>ML profile</small><b>${p.include_ml?escapeHtml(p.ml_profile):'Skipped'}</b></div><div><small>Estimated duration</small><b>${estimates[0]}</b></div><div><small>Execution intensity</small><b>${estimates[1]}</b></div></div><p class="wizard-note">CAUSALIS will create an editable workflow and recommend the next action. No campaign is executed without explicit user confirmation.</p>`;
}
async function createGuidedExperiment(){
  const btn=q('#wizardCreateBtn'), payload=guidedWizardPayload();
  try{
    if(btn){btn.disabled=true;btn.textContent='Creating workspace...';}
    const e=await api('/api/experiments/guided-create',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
    closeGuidedWizard(); await loadExperimentWorkspaces(); await loadGuidedHomeContext();
    if(payload.infrastructure_mode==='intelligent_discovery'){applyWizardDiscoveryToIntelligentMode(payload);openStudioTab('intelligentTab');msg(`Experiment workspace created. Intelligent Mode is ready for ${payload.discovery?.ip_range||'the authorized range'}.`);}else{openStudioTab('experimentsTab');msg(`Guided experiment created: ${e.name}`);}
  }catch(e){msg('Unable to create guided experiment: '+e.message,true)}
  finally{if(btn){btn.disabled=false;btn.textContent='Create Experiment';}}
}
function formatBytes(v){const n=Number(v||0);if(n<1024)return `${n} B`;if(n<1048576)return `${(n/1024).toFixed(1)} KB`;if(n<1073741824)return `${(n/1048576).toFixed(1)} MB`;return `${(n/1073741824).toFixed(1)} GB`;}
function artifactIcon(cat){return ({matched_logs:'⌁',clean_datasets:'▦',dataset_splits:'⇄',ml_datasets:'▥',models:'◇',reports:'▤',uploads:'↑'})[cat]||'•';}
async function loadCurrentArtifacts(){
  const box=q('#artifactExplorer'), summary=q('#artifactSummary'); if(!box||!currentWorkspaceExperiment)return;
  try{
    const r=await api(`/api/experiments/${encodeURIComponent(currentWorkspaceExperiment.id)}/artifacts`), counts=r.counts||{}, items=r.items||[];
    if(summary)summary.innerHTML=Object.entries(counts).map(([k,v])=>`<div><i>${artifactIcon(k)}</i><span><b>${v}</b><small>${escapeHtml(k.replaceAll('_',' '))}</small></span></div>`).join('')||'<p class="muted">No artifacts generated yet.</p>';
    box.innerHTML=items.slice(0,60).map(x=>`<div class="artifact-item"><i>${artifactIcon(x.category)}</i><div><b>${escapeHtml(x.name)}</b><span>${escapeHtml(x.category.replaceAll('_',' '))} · ${formatBytes(x.size_bytes)} · ${escapeHtml(x.modified_at)}</span><small>${escapeHtml(x.relative_path)}</small></div>${x.download?`<a href="${escapeHtml(x.download)}">Download</a>`:''}</div>`).join('')||'<div class="empty-state"><b>No artifacts available</b><span>Run the experiment workflow to generate evidence, datasets, models and reports.</span></div>';
  }catch(e){box.innerHTML=`<p class="error">Unable to load artifacts: ${escapeHtml(e.message)}</p>`;}
}
async function openAboutModal(){
  const modal=q('#aboutModal');if(!modal)return;modal.hidden=false;document.body.classList.add('modal-open');
  try{
    const r=await api('/api/studio/about');
    q('#aboutContent').innerHTML=`<h2>${escapeHtml(r.product)} ${escapeHtml(r.version)}</h2><p>${escapeHtml(r.descriptor)}</p><div class="about-grid"><div><small>Validated core</small><b>${escapeHtml(r.baseline)}</b></div><div><small>Python</small><b>${escapeHtml(r.python)}</b></div><div><small>FastAPI</small><b>${escapeHtml(r.fastapi)}</b></div><div><small>SQLite</small><b>${escapeHtml(r.sqlite)}</b></div><div><small>Platform</small><b>${escapeHtml(r.platform)}</b></div><div><small>Database</small><b>${escapeHtml(r.database)}</b></div></div><div class="diagnostic-note"><b>Development principle</b><span>Every release adds value while preserving the validated experimentation core.</span></div>`;
  }catch(e){q('#aboutContent').innerHTML=`<p class="error">Unable to load diagnostics: ${escapeHtml(e.message)}</p>`;}
}
function closeAboutModal(){const m=q('#aboutModal');if(m)m.hidden=true;document.body.classList.remove('modal-open');}

document.addEventListener('change',e=>{
  if(e.target?.name==='wizardInfrastructure')updateWizardInfrastructure();
  if(e.target?.id==='wizardDiscoveryProfile')updateWizardDiscoveryProfile();
});
window.addEventListener('keydown',e=>{if(e.key==='Escape'){closeGuidedWizard();closeAboutModal();}});
window.addEventListener('click',e=>{if(e.target===q('#guidedWizardModal'))closeGuidedWizard();if(e.target===q('#aboutModal'))closeAboutModal();});


// CAUSALIS v0.6 full-service research accelerator
function researchPayload(launch=false){
  const host=q('#researchHost')?.value.trim()||'100.10.10.3';
  const normalMin=Math.max(1,Number(q('#researchNormalMinutes')?.value||30));
  const anomalyMin=Math.max(1,Number(q('#researchAnomalyMinutes')?.value||20));
  return {name:`Full-Service Thesis Campaign ${new Date().toISOString().slice(0,10)}`,host,normal_duration_seconds:Math.round(normalMin*60),anomaly_duration_seconds:Math.round(anomalyMin*60),normal_rate_per_second:2,anomaly_rate_per_second:2,concurrency:2,repetitions:Math.max(1,Number(q('#researchRepetitions')?.value||2)),launch,require_complete_coverage:true,include_capec_categories:[]};
}
async function checkResearchReadiness(){
  const box=q('#researchReadiness'); if(box)box.innerHTML='<b>Checking all paired endpoints…</b>';
  try{
    const host=encodeURIComponent(q('#researchHost')?.value.trim()||'100.10.10.3');
    const r=await api(`/api/research/readiness?host=${host}`);
    const rows=Object.entries(r.families||{}).map(([name,v])=>`<tr><td>${escapeHtml(name)}</td><td>${v.normal?'✅':'❌'}</td><td>${v.anomaly?'✅':'❌'}</td></tr>`).join('');
    if(box)box.innerHTML=`<b>${r.complete?'Ready for full experiment':'Coverage incomplete'}</b><table><thead><tr><th>Family</th><th>Normal</th><th>Pentesting</th></tr></thead><tbody>${rows}</tbody></table>`;
  }catch(e){if(box)box.textContent='Readiness check failed: '+e.message;}
}
async function prepareResearchCampaign(){
  const box=q('#researchReadiness');
  try{const r=await api('/api/research/full-campaign',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(researchPayload(false))});if(box)box.innerHTML=`<b>Campaign prepared.</b> ${r.actions} actions · estimated ${r.estimated_hours} hours. Review it in Campaign History before launch.`;await refreshAll();}
  catch(e){if(box)box.textContent='Unable to prepare campaign: '+e.message;}
}
async function launchResearchCampaign(){
  if(!confirm('Launch the complete long-running campaign now? It may take several hours.'))return;
  const box=q('#researchReadiness');
  try{const r=await api('/api/research/full-campaign',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(researchPayload(true))});if(box)box.innerHTML=`<b>Campaign launched.</b> ${r.actions} sequential actions · estimated ${r.estimated_hours} hours. CAUSALIS can remain running unattended.`;await refreshAll();}
  catch(e){if(box)box.textContent='Unable to launch campaign: '+e.message;}
}

async function processResearchEvidence(){
  const file=q('#researchEvidenceZip')?.files?.[0], box=q('#researchEvidenceResult');
  if(!file){if(box)box.textContent='Select the ZIP containing the service logs.';return;}
  const fd=new FormData();fd.append('evidence_zip',file);fd.append('window_seconds',q('#researchEvidenceWindow')?.value||'8');fd.append('remove_unmatched','false');fd.append('drop_duplicates','true');
  if(box)box.innerHTML='<b>Processing evidence…</b> Large ZIP files may take several minutes.';
  try{const r=await api('/api/research/evidence-batch',{method:'POST',body:fd});const rows=(r.files||[]).map(x=>`<tr><td>${escapeHtml(x.service)}</td><td>${escapeHtml(x.kind)}</td><td>${x.events}</td><td>${x.matched}</td><td>${x.clean_rows}</td></tr>`).join('');if(box)box.innerHTML=`<b>Evidence batch ${escapeHtml(r.batch_id)} processed.</b><table><thead><tr><th>Service</th><th>Type</th><th>Events</th><th>Matched</th><th>Clean rows</th></tr></thead><tbody>${rows}</tbody></table><p>Next: export processed splits, then select the <b>Full</b> model profile to train every available classifier.</p>`;}
  catch(e){if(box)box.textContent='Evidence processing failed: '+e.message;}
}


// CAUSALIS v0.7 automatic dataset-split discovery.
function splitFileKey(file){
  const name=(file.name||'').toLowerCase();
  const m=name.match(/^(.+)_(normal|anomaly)_(training|test)\.csv$/);
  if(!m)return null;
  return {service:m[1],kind:m[2],split:m[3],file};
}
function discoverSplitFiles(fileList){
  const services={}; const ignored=[];
  Array.from(fileList||[]).forEach(file=>{
    const k=splitFileKey(file);
    if(!k){ignored.push(file.name||'unknown');return;}
    services[k.service]??={service:k.service,normalTrain:null,anomalyTrain:null,normalTest:null,anomalyTest:null};
    const slot=(k.kind==='normal'?'normal':'anomaly')+(k.split==='training'?'Train':'Test');
    services[k.service][slot]=file;
  });
  return {services:Object.values(services).sort((a,b)=>a.service.localeCompare(b.service)),ignored};
}
function validateDiscoveredServices(found){
  return found.services.map(s=>{
    const missing=[];
    if(!s.normalTrain)missing.push('normal training');
    if(!s.anomalyTrain)missing.push('anomaly training');
    if(!s.normalTest)missing.push('normal test');
    if(!s.anomalyTest)missing.push('anomaly test');
    return {...s,missing,ready:missing.length===0};
  });
}
function renderFolderValidation(targetId,validated,ignoredCount=0){
  const box=q(targetId);if(!box)return;
  if(!validated.length){box.innerHTML='<b>No recognizable split CSV files found.</b>';return;}
  const rows=validated.map(x=>`<tr><td>${escapeHtml(x.service)}</td><td>${x.normalTrain?'✓':'—'}</td><td>${x.anomalyTrain?'✓':'—'}</td><td>${x.normalTest?'✓':'—'}</td><td>${x.anomalyTest?'✓':'—'}</td><td>${x.ready?'<b>Ready</b>':`<span class="error">Missing: ${escapeHtml(x.missing.join(', '))}</span>`}</td></tr>`).join('');
  box.innerHTML=`<table><thead><tr><th>Service</th><th>N train</th><th>A train</th><th>N test</th><th>A test</th><th>Status</th></tr></thead><tbody>${rows}</tbody></table>${ignoredCount?`<p class="muted">Ignored non-split files: ${ignoredCount}</p>`:''}`;
}
function bindAutoMlFolders(){
  [['#mlSplitFolder','#mlSplitFolderName'],['#capecSplitFolder','#capecSplitFolderName']].forEach(([inputSel,nameSel])=>{
    const input=q(inputSel),name=q(nameSel);if(!input||!name)return;
    input.addEventListener('change',()=>{
      const files=Array.from(input.files||[]);const total=files.reduce((a,f)=>a+f.size,0);
      name.textContent=files.length?`${files.length} files selected · ${(total/1024/1024).toFixed(2)} MB`:'No folder selected';
      if(inputSel==='#mlSplitFolder')validateMlSplitFolder();else validateCapecSplitFolder();
    });
  });
}
function validateMlSplitFolder(){
  const input=q('#mlSplitFolder');
  const found=discoverSplitFiles(input?.files||[]),validated=validateDiscoveredServices(found);
  renderFolderValidation('#mlFolderValidation',validated,found.ignored.length);
  return validated;
}
function capecAnomalyFilesFromFolder(){
  const files=Array.from(q('#capecSplitFolder')?.files||[]);
  return files.filter(f=>{const k=splitFileKey(f);return k&&k.kind==='anomaly';});
}
function validateCapecSplitFolder(){
  const files=capecAnomalyFilesFromFolder(),box=q('#capecFolderValidation');
  if(!box)return files;
  const services={};files.forEach(f=>{const k=splitFileKey(f);services[k.service]=(services[k.service]||0)+1;});
  const rows=Object.entries(services).sort().map(([svc,n])=>`<tr><td>${escapeHtml(svc)}</td><td>${n}</td><td>${n>=2?'Ready':'Partial'}</td></tr>`).join('');
  box.innerHTML=files.length?`<b>${files.length} anomaly split files detected.</b><table><thead><tr><th>Service</th><th>Files</th><th>Status</th></tr></thead><tbody>${rows}</tbody></table>`:'<b>No anomaly split files found.</b>';
  return files;
}
async function trainBinaryFromFolder(){
  const validated=validateMlSplitFolder(),ready=validated.filter(x=>x.ready);
  if(!ready.length){q('#mlResult').textContent='No complete service datasets were found. Each service needs normal/anomaly training and test CSV files.';return;}
  const incomplete=validated.filter(x=>!x.ready);
  if(incomplete.length&&!confirm(`${incomplete.length} incomplete service set(s) will be skipped. Continue with ${ready.length} ready service(s)?`))return;
  const completed=[],errors=[];
  setMlBusy(true,`Running automatic binary pipeline for ${ready.length} services.`);
  try{
    for(let i=0;i<ready.length;i++){
      const x=ready[i];
      const job={service:x.service,experiment:`${x.service}_binary_auto`,seed:q('#mlRandomSeed')?.value||'42',profile:q('#mlModelProfile')?.value||'fast',models:getSelectedMlModels(),files:x};
      q('#mlFolderValidation').innerHTML+=`<p class="progress-note">${i+1}/${ready.length}: training ${escapeHtml(x.service)}…</p>`;
      try{await submitBinaryMlJob(job,`Automatic ${i+1}/${ready.length}:`);completed.push(x.service);}catch(e){errors.push(`${x.service}: ${e.message}`);}
    }
    q('#mlResult').innerHTML=`<div class="progress-note ok">Automatic binary pipeline completed. Services: ${escapeHtml(completed.join(', ')||'none')}. Errors: ${errors.length}.</div>${errors.length?`<pre>${escapeHtml(errors.join('\n'))}</pre>`:''}`;
  }finally{setMlBusy(false);await loadMlExperiments();}
}
async function trainCapecFromFolder(){
  const files=validateCapecSplitFolder();
  if(!files.length){q('#capecResult').textContent='No anomaly training/test CSV files were detected.';return;}
  await submitCapecFiles(files,'Automatic folder:');
}
async function submitCapecFiles(files,prefix=''){
  setMlBusy(true,'Building CAPEC multiclass dataset and training attribution models.');
  try{
    const fd=new FormData();
    fd.append('experiment_name',sanitizeExperimentNameClient(q('#capecExperimentName').value||'CAPEC_multiclass'));
    fd.append('random_seed',positiveNumber(q('#capecRandomSeed').value||'42','Random seed',0,999999999));
    fd.append('test_size',positiveNumber(q('#capecTestSize').value||'0.25','Test size',0.1,0.5));
    fd.append('target_column',q('#capecTargetColumn').value||'capec_category');
    fd.append('model_profile',q('#capecModelProfile').value||'balanced');
    fd.append('selected_models_json',JSON.stringify(getSelectedCapecModels()));
    Array.from(files).forEach(f=>fd.append('anomaly_files',f));
    q('#capecResult').innerHTML=`<div class="progress-note">${escapeHtml(prefix)} Concatenating anomaly datasets, generating stratified splits and training models…</div>`;
    const created=await api('/api/tasks/ml/capec',{method:'POST',body:fd});
    const t=await monitorPersistentTask(created.task_id,'#capecResult');
    const r=t.result||{};
    if(r.experiment){
      q('#capecResult').innerHTML+=`<p>CAPEC experiment saved: <b>${escapeHtml(r.experiment.name)}</b> · target: <b>${escapeHtml(r.experiment.target_column)}</b> · rows: ${r.experiment.rows_total}</p>`;
      if(r.capec_dataset_download||r.capec_training_download||r.capec_test_download)q('#capecResult').innerHTML+=`<br><a href="${r.capec_dataset_download}">capec_multiclass_dataset</a> · <a href="${r.capec_training_download}">training split</a> · <a href="${r.capec_test_download}">test split</a>`;
      q('#capecSummary').innerHTML=renderCapecDistribution(r.distribution||{})+(q('#mlSummary')?.innerHTML||'');
    }
    await loadMlExperiments();
  }catch(x){q('#capecResult').textContent='Error in CAPEC multiclass training: '+x.message;}
  finally{setMlBusy(false);}
}

// CAUSALIS v0.9.0 resilient experiment monitor
let causalisActiveTaskId=null;
function taskPercent(t){const total=Number(t.progress_total||0),cur=Number(t.progress_current||0);return total?Math.max(0,Math.min(100,Math.round(cur*100/total))):0;}
function metricValue(value,suffix=''){return value===null||value===undefined||value===''||Number.isNaN(Number(value))?'N/A':`${value}${suffix}`;}
function taskStatusLabel(status){return ({pause_requested:'Pause requested',recovered:'Recovered',cancelling:'Cancelling safely'})[status]||String(status||'unknown').replaceAll('_',' ');}
function renderPersistentTask(t,target='#mlResult'){
  const box=q(target); if(!box||!t)return;
  const pct=taskPercent(t),elapsed=fmtSeconds(Number(t.elapsed_seconds||0)),eta=Number.isFinite(Number(t.eta_seconds))?fmtSeconds(Number(t.eta_seconds)):'Recalculating...';
  const canPause=['running','queued'].includes(t.status),canResume=['paused','pause_requested','recovered'].includes(t.status);
  const controls=canPause?`<button onclick="pausePersistentTask('${t.id}')">Pause safely</button><button class="danger" onclick="cancelPersistentTask('${t.id}')">Cancel safely</button>`:canResume?`<button onclick="resumePersistentTask('${t.id}')">Resume</button><button class="danger" onclick="cancelPersistentTask('${t.id}')">Cancel safely</button>`:'';
  const results=t.result?.results||[],done=new Set(results.map(r=>r.model_name));
  const models=(t.config?.models||[]).map(m=>`<li>${done.has(m)?'✔':(String(t.current_unit||'').includes(m)?'▶':'□')} ${escapeHtml(m)}</li>`).join('');
  const timeline=(t.result?.timeline||[]).slice(-8).reverse().map(e=>`<li><small>${escapeHtml(e.at||'')}</small> · ${escapeHtml(e.message||e.type||'event')}</li>`).join('');
  const peaks=t.result?.resource_peaks||{},last=(t.result?.resource_history||[]).at(-1)||{};
  box.innerHTML=`<div class="task-monitor status-${escapeHtml(t.status||'unknown')}"><div class="task-monitor-head"><div><span class="task-kicker">Experiment execution</span><h3>${escapeHtml(t.name||'Operation')}</h3></div><span class="task-status">${escapeHtml(taskStatusLabel(t.status))}</span></div><div class="progress-track"><div class="progress-fill" style="width:${pct}%"></div></div><div class="task-metrics"><div><span>Progress</span><strong>${t.progress_current||0}/${t.progress_total||0} · ${pct}%</strong></div><div><span>Current unit</span><strong>${escapeHtml(t.current_unit||t.message||'Preparing…')}</strong></div><div><span>Active time</span><strong>${elapsed}</strong></div><div><span>ETA</span><strong>${eta}</strong></div><div><span>Resumes</span><strong>${t.resume_count||0}</strong></div><div><span>RSS</span><strong>${metricValue(last.process_rss_mb,' MB')}</strong></div><div><span>Peak RSS</span><strong>${metricValue(peaks.process_rss_mb,' MB')}</strong></div><div><span>Process swap</span><strong>${metricValue(last.process_swap_mb,' MB')}</strong></div><div><span>System swap peak</span><strong>${metricValue(peaks.swap_used_mb,' MB')}</strong></div><div><span>CPU</span><strong>${metricValue(last.cpu_percent,'%')}</strong></div></div>${models?`<details open><summary>Model history</summary><ul class="task-model-history">${models}</ul></details>`:''}<details ${timeline?'':'class="empty-timeline"'}><summary>Execution timeline</summary>${timeline?`<ul class="task-timeline">${timeline}</ul>`:'<p class="timeline-placeholder">Events will appear here as checkpoints are recorded.</p>'}</details><p class="task-message">${escapeHtml(t.message||'')}</p><div class="task-controls">${controls}</div>${t.error?`<pre>${escapeHtml(t.error)}</pre>`:''}</div>`;
}
async function pausePersistentTask(id){await api(`/api/tasks/${id}/pause`,{method:'POST'});}
async function resumePersistentTask(id){await api(`/api/tasks/${id}/resume`,{method:'POST'});monitorPersistentTask(id);}
async function cancelPersistentTask(id){if(confirm('Cancel safely after the current model? Completed artifacts and checkpoints will be preserved.'))await api(`/api/tasks/${id}/cancel`,{method:'POST'});}
async function monitorPersistentTask(id,target='#mlResult'){
  causalisActiveTaskId=id;
  while(true){
    const t=await api(`/api/tasks/${id}`); renderPersistentTask(t,target);
    if(['completed','failed','cancelled'].includes(t.status)){
      setMlBusy(false); causalisActiveTaskId=null;
      if(t.status==='completed'&&t.result){renderMlResults(t.result);await loadMlExperiments();}
      return t;
    }
    await new Promise(r=>setTimeout(r,1500));
  }
}
async function restorePersistentTask(){
  try{
    const tasks=await api('/api/tasks?limit=10');
    const active=(tasks||[]).find(t=>['queued','running','pause_requested','paused','recovered','cancelling'].includes(t.status));
    if(active){setMlBusy(true);monitorPersistentTask(active.id);}
  }catch(e){}
}
document.addEventListener('DOMContentLoaded',()=>setTimeout(restorePersistentTask,1200));
