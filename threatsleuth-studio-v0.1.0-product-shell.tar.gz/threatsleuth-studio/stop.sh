#!/usr/bin/env bash
set -euo pipefail
PORT="${ATG_PORT:-8080}"
sudo fuser -k "${PORT}/tcp" || true
