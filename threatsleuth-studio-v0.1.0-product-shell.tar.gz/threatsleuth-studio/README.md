# ThreatSleuth ATG

**ThreatSleuth ATG** is an automated traffic generator, log-processing pipeline, dataset builder and machine-learning experimentation tool for controlled cybersecurity research laboratories.

The tool was created to support reproducible experiments in which legitimate service activity and malicious/anomalous activity are generated in a controlled honeynet, correlated with service logs, transformed into structured datasets and evaluated with machine-learning models.

This repository contains the final validated **v1.0.0** release. The functionality in this release has been experimentally validated end-to-end and is intentionally frozen. Future changes should be treated as new development branches rather than modifications to this validated baseline.

---

## 1. Purpose

ThreatSleuth ATG was designed for research scenarios where the objective is to generate labeled cybersecurity datasets for machine-learning-based attack detection. It supports a two-phase experimental model:

1. **Binary detection phase**  
   Distinguish normal service activity from attack/anomalous activity.

2. **CAPEC attribution phase**  
   Once an event has been identified as an attack, classify it into a high-level CAPEC attack-pattern category.

This mirrors a practical security-operations workflow:

```text
Observed activity
      ↓
Normality / Attack detection
      ↓
CAPEC attack-pattern attribution
```

The application is intended to be used together with a controlled honeynet or equivalent laboratory environment. It is not a vulnerability scanner, exploitation framework or offensive tool. Its purpose is dataset generation, experimental reproducibility and machine-learning evaluation.

---

## 2. Responsible Use

ThreatSleuth ATG is intended exclusively for:

- cybersecurity research;
- teaching and training;
- honeynet validation;
- dataset generation;
- authorized laboratory testing;
- controlled experiments on systems owned or explicitly authorized by the operator.

Do **not** use this software against public systems, third-party networks, production services or any environment where you do not have explicit authorization.

The tool includes input validation, upload validation, path restrictions and safeguards against common mistakes, but those controls do not replace legal authorization, laboratory isolation or responsible operational procedures.

---

## 3. Main Capabilities

ThreatSleuth ATG provides the following capabilities in a single web application:

- target and profile management;
- one-off traffic execution;
- multi-action campaign execution;
- campaign scheduling;
- Intelligent Mode for authorized laboratory host/service discovery;
- normal traffic generation;
- anomaly/attack-like traffic generation;
- event logging;
- matching between ATG-generated events and service logs;
- temporal window recommendation for log matching;
- dataset quality analysis;
- dataset cleaning;
- train/test split generation;
- binary machine-learning experiments;
- multi-service binary ML batches;
- CAPEC multiclass dataset generation;
- CAPEC multiclass model training;
- HTML/Markdown/TXT/CSV/JSON reports;
- SQLite-based experiment history.

---

## 4. Validated Research Workflow

The validated workflow is:

```text
1. Deploy a controlled honeynet
2. Generate normal and anomaly campaigns with ThreatSleuth ATG
3. Collect service logs
4. Match ATG events against service logs
5. Create cleaned datasets
6. Build binary normality/anomaly datasets
7. Train and evaluate binary classifiers
8. Build CAPEC multiclass datasets from clean anomaly CSV files
9. Train and evaluate CAPEC classifiers
10. Export metrics and reports for scientific analysis
```

The final validated experiment used HTTP, FTP, SSH and SMTP services. The CAPEC multiclass pipeline was validated using 24,203 attack events distributed across seven CAPEC categories.

---

## 5. End-to-End User Guide

This section describes how to use ThreatSleuth ATG from the beginning of an experiment to the final machine-learning reports. It is intended for users who have just deployed the application and need a practical operational sequence.

The recommended workflow is:

```text
Deploy laboratory / honeynet
        ↓
Configure targets
        ↓
Configure traffic profiles
        ↓
Generate normal traffic
        ↓
Generate anomaly traffic
        ↓
Collect logs from services
        ↓
Match ATG events with service logs
        ↓
Clean and export datasets
        ↓
Build binary normality/anomaly datasets
        ↓
Train binary classifiers
        ↓
Build CAPEC multiclass dataset from clean anomaly CSV files
        ↓
Train CAPEC classifiers
        ↓
Export reports and metrics
```

### 5.1 Step 1 — Deploy a controlled honeynet or target laboratory

Before using ATG, deploy the services that will receive the generated traffic. In the validated research environment, ATG was used with a containerized honeynet containing separate normality and pentesting service sets.

The validated services were:

| Service | Normality port | Pentesting/anomaly port |
|---|---:|---:|
| HTTP / DVWA | 80 | 81 |
| FTP | 2121 | 2122 |
| SSH | 2222 | 2223 |
| SMTP | 587 | 1587 |
| IMAP | 143 | 1143 |

You may use a different laboratory, but the targets must be reachable from the machine running ThreatSleuth ATG.

### 5.2 Step 2 — Start ThreatSleuth ATG

From the project root:

```bash
./run.sh
```

Open the UI in a browser:

```text
http://<HOST_IP>:8080
```

Check that the header shows:

```text
ThreatSleuth ATG v1.0.0
```

### 5.3 Step 3 — Create or discover targets

There are two ways to define targets.

#### Manual target creation

Open the traffic generation section and create a target with:

- target name;
- IP address;
- service;
- port;
- optional credentials.

Use this mode when you already know the laboratory topology.

#### Intelligent Mode

Open Intelligent Mode and provide the authorized laboratory CIDR range, for example:

```text
192.168.56.0/24
```

The tool can scan the range, identify active services, create targets, generate profiles and propose campaigns. Use this only in private or explicitly authorized networks.

Recommended objective for research validation:

```text
Research Dataset
```

### 5.4 Step 4 — Create traffic profiles

Profiles define how ATG interacts with each service.

For each service, create at least:

- one normal profile;
- one anomaly profile.

Normal profiles should represent legitimate activity. Anomaly profiles should represent controlled attack-like behavior mapped to CAPEC-oriented categories.

When profile mode is set to `Normal`, CAPEC fields are not required. When mode is set to `Anomaly`, select the attack category that best represents the generated behavior.

### 5.5 Step 5 — Generate normal traffic

Use the normality targets and normal profiles to generate legitimate traffic.

Recommended process:

1. Select the normality target.
2. Select the normal profile.
3. Set duration, rate and concurrency.
4. Run the action or add it to a campaign.
5. Wait until the campaign finishes.
6. Confirm that the corresponding service generated logs.

The purpose of this phase is to create datasets representing legitimate service behavior.

### 5.6 Step 6 — Generate anomaly traffic

Use the pentesting/anomaly targets and anomaly profiles to generate malicious or attack-like traffic.

Recommended process:

1. Select the anomaly target.
2. Select the anomaly profile.
3. Select the CAPEC-oriented attack category.
4. Set duration, rate and concurrency.
5. Run the action or add it to a campaign.
6. Wait until the campaign finishes.
7. Confirm that service logs were generated.

The purpose of this phase is to create labeled attack datasets.

### 5.7 Step 7 — Use campaigns for reproducibility

For research experiments, prefer campaigns over isolated actions.

A campaign groups several traffic actions and records them as a reproducible execution unit. This makes it easier to document:

- services used;
- traffic modes;
- CAPEC categories;
- duration;
- rate;
- concurrency;
- execution time.

For larger experiments, use the scheduler only after verifying that the system clock and timezone are correct.

### 5.8 Step 8 — Collect service logs

After campaign execution, collect logs from the target services or from the honeynet log repository.

In the validated honeynet, logs were produced by the individual services and normalized through the logging layer. HTTP traffic was enriched using Mitmproxy, and service logs were made available for matching.

Keep normality logs and anomaly logs clearly separated.

Recommended naming convention:

```text
http_normal_logs.jsonl
http_anomaly_logs.jsonl
ftp_normal_logs.jsonl
ftp_anomaly_logs.jsonl
ssh_normal_logs.jsonl
ssh_anomaly_logs.jsonl
smtp_normal_logs.jsonl
smtp_anomaly_logs.jsonl
```

### 5.9 Step 9 — Match logs with ATG events

Open the Log Processing / Datasets section.

For each service and mode:

1. Upload the corresponding service log file.
2. Select the relevant ATG event source.
3. Choose the service and mode.
4. Set the temporal matching window.
5. Run matching.
6. Export the matched dataset.

The matching window determines how close in time a service log entry must be to an ATG event to be considered related. The default value may work well in many environments, but large logs or delayed services may require adjustment.

If matching appears to take several seconds, this is normal for large log files. The UI disables unsafe concurrent actions and displays progress/status messages.

### 5.10 Step 10 — Analyze quality and clean datasets

For each matched dataset:

1. Open the dataset quality analysis section.
2. Check missing values, duplicates, constant columns, near-zero-variance columns and outliers.
3. Review the suggested columns.
4. Decide manually which columns to keep or remove.
5. Export the clean dataset.

Important recommendation:

Do not automatically remove all constant or near-constant columns without understanding the experiment. Some fields, such as `service`, may be constant inside a single-service dataset but still useful when datasets are combined later.

Expected clean outputs:

```text
clean_http_normal.csv
clean_http_anomaly.csv
clean_ftp_normal.csv
clean_ftp_anomaly.csv
clean_ssh_normal.csv
clean_ssh_anomaly.csv
clean_smtp_normal.csv
clean_smtp_anomaly.csv
```

### 5.11 Step 11 — Build binary normality/anomaly datasets

Open the Machine Learning section and use the binary workflow.

For each service:

1. Select the clean normality CSV file.
2. Select the clean anomaly CSV file.
3. Select the service name.
4. Choose the test split or external train/test mode.
5. Select model profile: FAST, BALANCED or FULL RESEARCH.
6. Train the binary models.
7. Generate and export reports.

The binary workflow creates datasets using:

```text
target = attack_flag
```

where:

```text
0 = normal
1 = attack/anomaly
```

### 5.12 Step 12 — Interpret binary reports

Binary reports include:

- train/test distribution;
- selected models;
- excluded features;
- engineered features;
- accuracy;
- precision;
- recall;
- Macro-F1;
- Weighted-F1;
- MCC;
- ROC-AUC;
- confusion matrix.

For imbalanced cybersecurity datasets, prefer MCC, Macro-F1, recall and the confusion matrix over accuracy alone.

### 5.13 Step 13 — Build the CAPEC multiclass dataset

The CAPEC workflow uses only clean anomaly datasets.

Open the CAPEC multiclass section and select a variable number of clean anomaly CSV files. In the validated experiment, four files were selected:

```text
clean_http_anomaly_20260607_200019.csv
clean_ftp_anomaly_20260607_200122.csv
clean_ssh_anomaly_20260607_200200.csv
clean_smtp_anomaly_20260607_200246.csv
```

The tool will:

1. concatenate the selected anomaly datasets;
2. validate the selected target column;
3. calculate CAPEC distribution;
4. create `capec_multiclass_dataset_<timestamp>.csv`;
5. create stratified train/test files;
6. train the selected multiclass models;
7. generate reports.

Recommended target:

```text
capec_category
```

This target is preferred for publications because it is easier to interpret than numeric CAPEC identifiers.

### 5.14 Step 14 — Interpret CAPEC reports

CAPEC reports include:

- total rows;
- class distribution;
- distribution by service;
- training/test distribution;
- model ranking;
- Macro-F1;
- MCC;
- Balanced Accuracy;
- multiclass confusion matrix;
- feature importance when supported.

The confusion matrix is especially important because it shows which attack categories are well separated and which categories tend to be confused.

### 5.15 Step 15 — Archive experiment artifacts

For a complete research experiment, save:

```text
raw logs
matched datasets
clean datasets
binary datasets
CAPEC multiclass dataset
training/test splits
HTML/MD/TXT reports
CSV/JSON metrics
campaign configuration
ThreatSleuth ATG version
random seed
model profile
```

These artifacts are essential for reproducibility and for writing the results section of a scientific paper.

---

## 6. Public Research Artifacts: Datasets and Reports

The GitHub repository may include the source code and README directly, while larger datasets and reports can be published as compressed release artifacts.

Recommended compressed files:

```text
threatsleuth-atg-v1.0.0-final.tar.gz
threatsleuth-atg-datasets-v1.0.0.zip
threatsleuth-atg-reports-v1.0.0.zip
```

### 6.1 Dataset archive contents

Recommended archive:

```text
threatsleuth-atg-datasets-v1.0.0.zip
```

Suggested internal structure:

```text
datasets/
├── clean_anomaly/
│   ├── clean_http_anomaly_20260607_200019.csv
│   ├── clean_ftp_anomaly_20260607_200122.csv
│   ├── clean_ssh_anomaly_20260607_200200.csv
│   └── clean_smtp_anomaly_20260607_200246.csv
│
├── capec_multiclass/
│   ├── capec_multiclass_dataset_20260608_153043.csv
│   ├── capec_multiclass_training_20260608_153043.csv
│   └── capec_multiclass_test_20260608_153043.csv
│
├── distributions/
│   └── capec_distribution.csv
│
└── dataset_description.md
```

Minimum recommended files to publish:

| File | Purpose |
|---|---|
| `clean_http_anomaly_20260607_200019.csv` | Clean HTTP attack dataset used as CAPEC input |
| `clean_ftp_anomaly_20260607_200122.csv` | Clean FTP attack dataset used as CAPEC input |
| `clean_ssh_anomaly_20260607_200200.csv` | Clean SSH attack dataset used as CAPEC input |
| `clean_smtp_anomaly_20260607_200246.csv` | Clean SMTP attack dataset used as CAPEC input |
| `capec_multiclass_dataset_20260608_153043.csv` | Final unified CAPEC multiclass dataset |
| `capec_multiclass_training_20260608_153043.csv` | Stratified training split used in the validated experiment |
| `capec_multiclass_test_20260608_153043.csv` | Stratified test split used in the validated experiment |
| `capec_distribution.csv` | Category distribution table for quick inspection |
| `dataset_description.md` | Dataset documentation and column description |

The clean anomaly files are included because they allow researchers to rebuild the CAPEC multiclass dataset from the same inputs. The unified CAPEC dataset is included because it is the main dataset used in the article. The train/test files are included because they allow exact reproduction of the reported multiclass experiment.

### 6.2 Optional binary classification datasets

If binary datasets are published, use a separate folder:

```text
datasets/binary/
├── binary_http_dataset.csv
├── binary_ftp_dataset.csv
├── binary_ssh_dataset.csv
└── binary_smtp_dataset.csv
```

These files should contain both normal and anomaly records and use:

```text
attack_flag
```

as the binary target column.

If the binary datasets are large or if they can be regenerated from clean normal/anomaly files, they may be omitted from the first public release and published later as an extended artifact.

### 6.3 Report archive contents

Recommended archive:

```text
threatsleuth-atg-reports-v1.0.0.zip
```

Suggested internal structure:

```text
reports/
├── binary/
│   ├── ml_report_http_training_eval_08062026_20260608_123024.html
│   ├── ml_report_ftp_training_eval_08062026_20260608_123022.html
│   ├── ml_report_ssh_training_eval_08062026_20260608_123021.html
│   └── ml_report_smtp_training_eval_08062026_20260608_123020.html
│
├── independent_validation/
│   ├── ml_report_ftp_training_extra_20260608_150057.html
│   └── ml_report_ssh_training_extra_20260608_150059.html
│
└── capec_multiclass/
    └── ml_report_capec_multiclass_20260608_213038.html
```

Minimum recommended reports to publish:

| File | Purpose |
|---|---|
| `ml_report_http_training_eval_08062026_20260608_123024.html` | Binary HTTP experiment report |
| `ml_report_ftp_training_eval_08062026_20260608_123022.html` | Binary FTP experiment report |
| `ml_report_ssh_training_eval_08062026_20260608_123021.html` | Binary SSH experiment report |
| `ml_report_smtp_training_eval_08062026_20260608_123020.html` | Binary SMTP experiment report |
| `ml_report_ftp_training_extra_20260608_150057.html` | Independent FTP validation report |
| `ml_report_ssh_training_extra_20260608_150059.html` | Independent SSH validation report |
| `ml_report_capec_multiclass_20260608_213038.html` | CAPEC multiclass experiment report |

If available, include the Markdown, TXT, CSV and JSON exports generated together with each HTML report. They are useful for reproducibility, tables and paper writing.

### 6.4 Dataset description file

The dataset archive should include `dataset_description.md` with at least:

- dataset title;
- ThreatSleuth ATG version;
- honeynet version or repository URL;
- generation date;
- services included;
- number of rows per service;
- CAPEC categories;
- target columns;
- column descriptions;
- train/test split strategy;
- random seed;
- known limitations;
- citation instructions.

### 6.5 CAPEC distribution file

The file `capec_distribution.csv` should contain:

```csv
capec_category,count
resource depletion,12388
probabilistic techniques,2585
data leakage,2213
abuse of functionality,1985
subverting authentication,1824
time and state,1738
injection,1470
```

This makes it easy for external researchers to inspect class balance without opening the full dataset.

---

## 7. Application Architecture

ThreatSleuth ATG is a Python/FastAPI web application with a browser-based user interface.

```text
threatsleuth-atg/
├── app/
│   ├── main.py              # FastAPI backend and experiment logic
│   ├── templates/
│   │   └── index.html       # Web UI
│   └── static/
│       ├── app.js           # UI behavior and API calls
│       └── style.css        # UI styling
├── data/
│   ├── config/              # Targets, profiles and campaign configuration
│   ├── exports/             # Generated datasets, reports and ZIP exports
│   ├── logs/                # ATG event logs
│   ├── models/              # Serialized trained models
│   └── uploads/             # Temporarily uploaded CSV/log files
├── deploy.sh                # Installation helper
├── run.sh                   # Application launcher
├── stop.sh                  # Port-based stop helper
├── requirements.txt         # Python dependencies
├── VERSION                  # Release identifier
└── README.md                # This document
```

### Backend

The backend is implemented in `app/main.py` using FastAPI. It provides endpoints for campaigns, targets, profiles, log matching, dataset processing, machine-learning training and report download.

### Frontend

The UI is implemented using plain HTML, CSS and JavaScript. It intentionally avoids a complex frontend framework so the application remains easy to deploy and inspect in isolated laboratory machines.

### Storage

The application uses SQLite for persistent local state, including targets, profiles, campaign history, events and ML experiment metadata. The database is created automatically under `data/atg.db` at first run.

### Reports and exports

Generated outputs are stored under `data/exports/`, with specialized subfolders for matched logs, clean datasets, ML datasets and ML reports.

---

## 8. Installation

### 8.1 Requirements

Recommended operating system:

- Ubuntu 24.04 LTS or compatible Debian-based distribution.

Minimum requirements:

- Python 3.11 or later recommended;
- Python virtual environment support;
- Internet access during the first dependency installation;
- isolated laboratory network for traffic generation.

Recommended hardware:

| Module | Minimum RAM | Notes |
|---|---:|---|
| Traffic generation | 2 GB | Validated for normal and anomaly campaigns |
| Log processing and matching | 2 GB | Depends on log file size |
| Dataset cleaning | 2 GB | Depends on CSV size |
| ML Fast profile | 8 GB | Recommended minimum for ML experiments |
| ML Full Research profile | 12 GB+ | Recommended for all models and large datasets |

### 8.2 Deploy with helper script

From the project root:

```bash
chmod +x deploy.sh
sudo ./deploy.sh
```

The deployment script:

1. installs required system packages;
2. creates a local Python virtual environment;
3. installs Python dependencies inside `.venv`;
4. creates the required `data/` directories;
5. prepares `run.sh`.

After deployment, start the application:

```bash
./run.sh
```

By default, the UI is available at:

```text
http://<HOST_IP>:8080
```

You can override the port with:

```bash
ATG_PORT=9090 ./run.sh
```

### 8.3 Stop the application

```bash
./stop.sh
```

or, if using a custom port:

```bash
ATG_PORT=9090 ./stop.sh
```

---

## 9. Configuration

### 9.1 Environment variables

The `.env` file may be used to define laboratory-specific settings. The most relevant variable is:

```bash
ATG_ALLOWED_NETWORKS=0.0.0.0/0
```

For stricter laboratories, replace this with explicit private ranges, for example:

```bash
ATG_ALLOWED_NETWORKS=10.0.0.0/8,192.168.0.0/16,172.16.0.0/12
```

Intelligent Mode is intended for private or explicitly authorized networks. Keep discovery restricted to your lab whenever possible.

### 9.2 Data directories

ThreatSleuth ATG creates and uses the following directories:

```text
data/logs
data/config
data/uploads
data/models
data/exports
data/exports/matched_logs
data/exports/clean_datasets
data/exports/dataset_splits
data/exports/ml_datasets
data/exports/ml_reports
```

Do not commit runtime datasets, logs or SQLite databases to Git unless intentionally publishing reproducible experiment artifacts.

---

## 10. User Interface Overview

The UI is organized into four main tabs.

### 10.1 Traffic Generation

This tab is used to:

- define targets;
- save/load reusable target profiles;
- configure one-off traffic actions;
- generate normal traffic;
- generate anomaly traffic;
- create multi-action campaigns;
- schedule campaigns;
- monitor campaign progress.

Important campaign parameters:

- **service**: protocol or service type;
- **mode**: normal or anomaly;
- **attack category**: CAPEC-oriented category for anomaly traffic;
- **duration**: campaign duration;
- **rate**: approximate action rate;
- **concurrency**: number of concurrent workers;
- **path/username/password/payload**: protocol-specific inputs.

### 10.2 Intelligent Mode

Intelligent Mode supports authorized laboratory discovery and campaign drafting.

It can:

- scan a controlled IP range;
- identify open ports;
- map ports to likely services;
- generate targets;
- generate profiles;
- build a proposed campaign.

Available objectives include:

- Quick Validation;
- Research Dataset;
- Large Balanced Dataset.

The validated honeynet profile includes non-standard ports used to separate normality and pentesting services, such as HTTP 80/81, FTP 2121/2122, SSH 2222/2223, SMTP 587/1587 and IMAP 143/1143.

### 10.3 Log Processing / Datasets

This tab supports the dataset construction pipeline.

It provides:

- log upload;
- temporal matching between ATG events and service logs;
- matching window advisor;
- matched dataset export;
- dataset quality analysis;
- zero-variance and near-zero-variance analysis;
- outlier analysis;
- duplicate detection;
- column selection;
- cleaned dataset export.

The matching workflow is central to traceability. It links generated ATG actions to observed service logs using timestamp windows and service metadata.

### 10.4 Machine Learning

This tab contains two validated ML workflows.

#### Binary Normality/Attack Detection

The binary workflow trains models with:

```text
target = attack_flag
```

It expects normal and anomaly datasets and creates binary train/test datasets. It excludes target-like and CAPEC-related fields from predictors to prevent data leakage.

#### CAPEC Multiclass Classification

The CAPEC workflow uses only clean anomaly datasets. The user may select any number of clean anomaly CSV files. This allows the pipeline to scale beyond the four services used in the validated experiment.

The pipeline:

1. concatenates the selected clean anomaly CSV files;
2. creates `capec_multiclass_dataset_<timestamp>.csv`;
3. builds stratified training and test splits;
4. trains selected multiclass classifiers;
5. generates metrics and reports.

Supported CAPEC targets:

- `capec_category`;
- `capec_id`;
- `attack_category_key`.

For publication-oriented experiments, `capec_category` is recommended because it is easier to interpret in tables, reports and confusion matrices.

---

## 11. CAPEC Taxonomy Used by the Tool

The validated release uses a reduced high-level CAPEC taxonomy suitable for practical multiclass learning:

| Internal key | CAPEC ID | Category |
|---|---|---|
| abuse_of_functionality | CAPEC-117 | Abuse of Functionality |
| resource_depletion | CAPEC-130 | Resource Depletion |
| data_leakage | CAPEC-118 | Data Leakage |
| subverting_authentication | CAPEC-115 | Subverting Authentication |
| probabilistic_techniques | CAPEC-49 | Probabilistic Techniques |
| injection | CAPEC-66 | Injection |
| time_and_state | CAPEC-29 | Time and State |
| spoofing | CAPEC-111 | Spoofing |
| benign | - | Normal Traffic |

The reduced taxonomy avoids the dimensionality problems associated with training on hundreds of fine-grained CAPEC entries while still preserving meaningful attack-pattern attribution.

---

## 12. Machine-Learning Models

The validated model suite includes:

- Decision Tree;
- Random Forest;
- Extra Trees;
- Logistic Regression;
- Naive Bayes;
- KNN;
- Gradient Boosting;
- AdaBoost;
- Hist Gradient Boosting;
- SVM;
- MLP.

The UI provides FAST, BALANCED and FULL RESEARCH profiles. FULL RESEARCH is computationally heavier and should be used only when enough memory is available.

---

## 13. Data Leakage Protection

ThreatSleuth ATG explicitly excludes target-like fields from predictor matrices.

For binary classification, excluded fields include:

```text
timestamp
timestamp_epoch
campaign_id
mode
label
attack_category_key
capec_id
capec_category
attack_flag
```

For CAPEC multiclass classification, the selected CAPEC target and alternate CAPEC label fields are excluded from predictors, including:

```text
capec_category
capec_id
attack_category_key
```

This ensures the model learns from behavioral/log-derived evidence rather than from metadata that directly encodes the answer.

---

## 14. Feature Engineering

The ML pipeline automatically derives features from textual fields such as `detail` and `matched_log_line`.

Examples include:

- string length;
- word count;
- digit count;
- special-character count;
- uppercase-character count;
- IP indicator;
- path indicator;
- HTTP method indicators;
- status-code indicators;
- authentication indicators;
- FTP command indicators;
- SSH-related indicators;
- SMTP command indicators;
- SQL injection indicators;
- combined semantic indicators.

This feature engineering layer significantly improves the ability of conventional ML models to exploit semi-structured logs without requiring deep learning.

---

## 15. Reports

Each ML experiment generates reproducible reports and metric exports under:

```text
data/exports/ml_reports
```

Typical outputs include:

- HTML report;
- Markdown report;
- TXT report;
- CSV metrics;
- JSON metrics.

Reports include:

- experiment metadata;
- dataset configuration;
- training/test distribution;
- selected models;
- excluded features;
- raw features;
- engineered features;
- performance metrics;
- model ranking;
- feature importance when supported;
- confusion matrix for the best model;
- automatic conclusion.

Recommended metrics for imbalanced cybersecurity datasets:

- MCC;
- Macro-F1;
- Weighted-F1;
- Balanced Accuracy;
- Recall;
- confusion matrix.

Accuracy is included but should not be interpreted alone.

---

## 16. Validated Experimental Results

The validated v1.0.0 baseline was used to complete an end-to-end experiment with:

- normal and anomaly traffic generation;
- log matching;
- dataset cleaning;
- binary ML training;
- independent validation for selected services;
- CAPEC multiclass dataset construction;
- CAPEC multiclass training and reporting.

The CAPEC multiclass experiment used:

- 24,203 attack events;
- 18,152 training rows;
- 6,051 test rows;
- 7 CAPEC categories;
- 4 anomaly source datasets.

The best CAPEC multiclass model achieved approximately:

| Metric | Value |
|---|---:|
| Accuracy | 0.935 |
| Macro-F1 | 0.906 |
| MCC | 0.911 |
| Balanced Accuracy | 0.908 |

These results validate the two-phase architecture implemented by the tool.

---

## 17. Security Controls

ThreatSleuth ATG includes several defensive controls at the application boundary:

- frontend input validation;
- backend input validation;
- dangerous pattern rejection;
- conservative name sanitization;
- numeric bounds for ports, rates, durations and concurrency;
- file name validation;
- file extension validation;
- rejection of remote URL schemes in file uploads;
- path traversal protection;
- export directory restrictions;
- SQLite parameterized queries;
- ML job lock to prevent concurrent training/report jobs.

These controls reduce accidental misuse and protect the application from common user-input problems. They are not a substitute for deploying the tool only inside controlled and authorized environments.

---

## 18. Reproducibility Notes

For reproducible experiments:

1. Use a clean honeynet deployment.
2. Record the exact ThreatSleuth ATG release.
3. Save the campaign configuration.
4. Save raw logs.
5. Save matched logs.
6. Save clean datasets.
7. Save binary train/test datasets.
8. Save CAPEC multiclass train/test datasets.
9. Save ML reports.
10. Record random seed and model profile.

The tool stores experiment metadata in SQLite and exports human-readable reports to support scientific writing.

---

## 19. GitHub Publication Recommendations

For a clean public repository, do not commit generated runtime data by default.

Recommended files to commit:

- source code;
- templates;
- static assets;
- scripts;
- requirements;
- README;
- VERSION;
- `.gitignore`;
- empty runtime directories with `.gitkeep` if desired.

Avoid committing:

- `data/atg.db`;
- uploaded CSV files;
- raw logs;
- generated datasets;
- generated ML reports;
- trained model pickle files;
- `.venv/`;
- `__pycache__/`.

Generated datasets and reports may be published separately as research artifacts if required.

---

## 20. Troubleshooting

### Virtual environment not found

Run:

```bash
sudo ./deploy.sh
```

then:

```bash
./run.sh
```

### Port already in use

Stop the process using:

```bash
./stop.sh
```

or run on a different port:

```bash
ATG_PORT=9090 ./run.sh
```

### Large ML jobs are slow

Use the FAST or BALANCED model profile first. FULL RESEARCH trains all available models and may require 12 GB or more RAM depending on dataset size.

### The UI appears inactive during training

During ML jobs, action buttons are intentionally disabled to prevent concurrent execution. Status text indicates the current stage of the workflow.

### CSV upload rejected

Check that the file:

- has a `.csv` extension;
- is a local file, not a URL;
- has no path traversal sequence in its name;
- contains the expected columns for the selected workflow.

---

## 21. Relationship with the Honeynet Infrastructure

ThreatSleuth ATG was designed to work with a containerized Generation IV honeynet architecture that separates normality and pentesting services. The honeynet infrastructure can be deployed independently and used as the data source for ATG experiments.

The recommended architecture is:

```text
ThreatSleuth ATG
      ↓
Controlled traffic generation
      ↓
Normality / Pentesting honeynet services
      ↓
Fluentd / Mitmproxy / service logs
      ↓
Log matching and dataset generation
      ↓
Binary detection and CAPEC attribution
```

---

## 22. Citation and Research Use

When using ThreatSleuth ATG in research, cite the associated article, dataset and honeynet repository once published. At minimum, report:

- ThreatSleuth ATG version;
- honeynet version;
- services used;
- campaign profiles;
- dataset sizes;
- selected target column;
- train/test split;
- random seed;
- model profile;
- evaluation metrics.

---

## 23. License

Add the final license selected for the GitHub repository before public release.

Suggested options:

- MIT License for maximum reuse;
- Apache License 2.0 for explicit patent language;
- GPLv3 if derivative works must remain open source.

---

## 24. Final Release Status

This is the final validated baseline:

```text
ThreatSleuth ATG v1.0.0
```

The functionality has been experimentally validated and should be treated as frozen for publication and GitHub release.

