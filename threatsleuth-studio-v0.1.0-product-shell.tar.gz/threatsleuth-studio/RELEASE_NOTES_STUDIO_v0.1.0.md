# ThreatSleuth Studio v0.1.0-product-shell

First product-oriented shell built on the validated ThreatSleuth ATG v1.0.0 core.

## Added

- New provisional product identity: ThreatSleuth Studio.
- New product-oriented application shell and visual identity elements.
- New Home dashboard with read-only system, workflow and experiment readiness indicators.
- New integrated Results dashboard for ML experiments.
- GUI model ranking based on persisted `ml_experiments` and `ml_results` data.
- GUI confusion matrix rendering for stored ML experiment results.
- New read-only Studio API endpoints:
  - `GET /api/studio/home`
  - `GET /api/studio/ml-dashboard`
  - `GET /api/studio/ml-experiments/{experiment_id}`

## Preserved

The validated ATG 1.0.0 execution core remains unchanged:

- Traffic generation.
- Campaign execution.
- Scheduler.
- Intelligent Mode.
- SQLite persistence.
- Log correlation.
- Dataset analysis and cleaning.
- Binary ML training.
- CAPEC multiclass ML training.
- Existing HTML report endpoint.

## Design rule

DO NOT BREAK WHAT ALREADY WORKS.

This release intentionally introduces read-only dashboards first, consuming existing persisted data instead of modifying the validated training or traffic-generation pipelines.
