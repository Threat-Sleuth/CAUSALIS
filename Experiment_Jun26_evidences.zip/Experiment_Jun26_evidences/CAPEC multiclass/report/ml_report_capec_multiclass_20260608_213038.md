# ATG ML Experiment Report: CAPEC_multiclass

## Experiment Metadata
- ID: 7ab317e0-64be-42cb-bd27-371112287a4e
- Created at: 2026-06-08T21:14:25+02:00
- Target column: capec_category
- Random seed: 42
- Best model: Naive Bayes
- Rows: 24203
- Columns: 14
- Model profile: full

## Leakage-safe Feature Selection
Excluded features:
- timestamp
- timestamp_epoch
- campaign_id
- mode
- label
- attack_category_key
- capec_id
- capec_category

Used features:
- service
- action
- status
- detail
- matched
- matched_log_line
- detail_length
- detail_word_count
- detail_digit_count
- detail_special_count
- detail_upper_count
- detail_contains_ip
- detail_contains_path
- detail_contains_get
- detail_contains_post
- detail_contains_head
- detail_contains_put
- detail_contains_delete
- detail_contains_404
- detail_contains_500
- detail_contains_admin
- detail_contains_login
- detail_contains_user
- detail_contains_pass
- detail_contains_list
- detail_contains_retr
- detail_contains_stor
- detail_contains_failed
- detail_contains_failure
- detail_contains_auth
- detail_contains_root
- detail_contains_sudo
- detail_contains_command
- detail_contains_shell
- detail_contains_helo
- detail_contains_ehlo
- detail_contains_mail_from
- detail_contains_rcpt_to
- detail_contains_vrfy
- detail_contains_expn
- detail_contains_select
- detail_contains_union
- detail_contains_drop
- detail_contains_sleep
- detail_contains_script
- logline_length
- logline_word_count
- logline_digit_count
- logline_special_count
- logline_upper_count
- logline_contains_ip
- logline_contains_path
- logline_contains_get
- logline_contains_post
- logline_contains_head
- logline_contains_put
- logline_contains_delete
- logline_contains_404
- logline_contains_500
- logline_contains_admin
- logline_contains_login
- logline_contains_user
- logline_contains_pass
- logline_contains_list
- logline_contains_retr
- logline_contains_stor
- logline_contains_failed
- logline_contains_failure
- logline_contains_auth
- logline_contains_root
- logline_contains_sudo
- logline_contains_command
- logline_contains_shell
- logline_contains_helo
- logline_contains_ehlo
- logline_contains_mail_from
- logline_contains_rcpt_to
- logline_contains_vrfy
- logline_contains_expn
- logline_contains_select
- logline_contains_union
- logline_contains_drop
- logline_contains_sleep
- logline_contains_script
- combined_contains_error
- combined_contains_auth
- combined_contains_scan
- combined_contains_injection

## Metrics
| Service | Model | Accuracy | F1 macro | MCC | Balanced Acc. | ROC-AUC |
|---|---|---:|---:|---:|---:|---:|
| CAPEC | Naive Bayes | 0.935052 | 0.905506 | 0.910789 | 0.908115 | 0.991057 |
| CAPEC | MLP | 0.935052 | 0.900051 | 0.908343 | 0.904896 | 0.995781 |
| CAPEC | Decision Tree | 0.935052 | 0.908941 | 0.906611 | 0.905091 | 0.946475 |
| CAPEC | Extra Trees | 0.935052 | 0.909342 | 0.906354 | 0.899637 | 0.995453 |
| CAPEC | Random Forest | 0.932904 | 0.906146 | 0.903299 | 0.898694 | 0.995617 |
| CAPEC | KNN | 0.849942 | 0.794633 | 0.784298 | 0.797377 | 0.972376 |
| CAPEC | Gradient Boosting | 0.838043 | 0.755497 | 0.767285 | 0.745961 | 0.975935 |
| CAPEC | Hist Gradient Boosting | 0.814907 | 0.753011 | 0.730808 | 0.756739 | 0.966059 |
| CAPEC | Logistic Regression | 0.67179 | 0.667785 | 0.602017 | 0.745302 | 0.949245 |
| CAPEC | AdaBoost | 0.56156 | 0.358242 | 0.337464 | 0.388529 | 0.854107 |
| CAPEC | SVM | 0.332342 | 0.296658 | 0.287452 | 0.406436 | 0.860857 |