# ATG ML Experiment Report: SMTP_training_eval_08062026

## Experiment Metadata
- ID: 5205f1c7-fda9-459c-85b5-5b8cc1eff244
- Created at: 2026-06-08T12:22:11+02:00
- Target column: attack_flag
- Random seed: 42
- Best model: Decision Tree
- Rows: 8153
- Columns: 15
- Model profile: full

## Leakage-safe Feature Selection
Excluded features:
- timestamp
- timestamp_epoch
- campaign_id
- mode
- label
- attack_category_key
- capec_id
- capec_category
- attack_flag

Used features:
- service
- action
- status
- detail
- matched
- matched_log_line
- detail_length
- detail_word_count
- detail_digit_count
- detail_special_count
- detail_upper_count
- detail_contains_ip
- detail_contains_path
- detail_contains_get
- detail_contains_post
- detail_contains_head
- detail_contains_put
- detail_contains_delete
- detail_contains_404
- detail_contains_500
- detail_contains_admin
- detail_contains_login
- detail_contains_user
- detail_contains_pass
- detail_contains_list
- detail_contains_retr
- detail_contains_stor
- detail_contains_failed
- detail_contains_failure
- detail_contains_auth
- detail_contains_root
- detail_contains_sudo
- detail_contains_command
- detail_contains_shell
- detail_contains_helo
- detail_contains_ehlo
- detail_contains_mail_from
- detail_contains_rcpt_to
- detail_contains_vrfy
- detail_contains_expn
- detail_contains_select
- detail_contains_union
- detail_contains_drop
- detail_contains_sleep
- detail_contains_script
- logline_length
- logline_word_count
- logline_digit_count
- logline_special_count
- logline_upper_count
- logline_contains_ip
- logline_contains_path
- logline_contains_get
- logline_contains_post
- logline_contains_head
- logline_contains_put
- logline_contains_delete
- logline_contains_404
- logline_contains_500
- logline_contains_admin
- logline_contains_login
- logline_contains_user
- logline_contains_pass
- logline_contains_list
- logline_contains_retr
- logline_contains_stor
- logline_contains_failed
- logline_contains_failure
- logline_contains_auth
- logline_contains_root
- logline_contains_sudo
- logline_contains_command
- logline_contains_shell
- logline_contains_helo
- logline_contains_ehlo
- logline_contains_mail_from
- logline_contains_rcpt_to
- logline_contains_vrfy
- logline_contains_expn
- logline_contains_select
- logline_contains_union
- logline_contains_drop
- logline_contains_sleep
- logline_contains_script
- combined_contains_error
- combined_contains_auth
- combined_contains_scan
- combined_contains_injection

## Metrics
| Service | Model | Accuracy | F1 macro | MCC | ROC-AUC |
|---|---|---:|---:|---:|---:|
| smtp | Decision Tree | 1.0 | 1.0 | 1.0 | 1.0 |
| smtp | Random Forest | 1.0 | 1.0 | 1.0 | 1.0 |
| smtp | Extra Trees | 1.0 | 1.0 | 1.0 | 1.0 |
| smtp | Logistic Regression | 1.0 | 1.0 | 1.0 | 1.0 |
| smtp | Naive Bayes | 1.0 | 1.0 | 1.0 | 1.0 |
| smtp | KNN | 1.0 | 1.0 | 1.0 | 1.0 |
| smtp | Gradient Boosting | 1.0 | 1.0 | 1.0 | 1.0 |
| smtp | AdaBoost | 1.0 | 1.0 | 1.0 | 1.0 |
| smtp | Hist Gradient Boosting | 1.0 | 1.0 | 1.0 | 1.0 |
| smtp | SVM | 1.0 | 1.0 | 1.0 | 1.0 |
| smtp | MLP | 1.0 | 1.0 | 1.0 | 1.0 |